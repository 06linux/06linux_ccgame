"use strict";
cc._RF.push(module, '990b58sfnFJ/rVmbcWuLOIx', 'StatZjsdk');
// resources/script/platform/StatZjsdk.js

"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.StatZjsdk = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _BaseHttp = require("../base/BaseHttp");

var _BaseUtil = require("../base/BaseUtil");

var _BaseConfig = require("../base/BaseConfig");

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

/**
 * ZJKJ 统计接口
 */
var StatZjsdk = exports.StatZjsdk = function () {

    /**
     * 初始化
     */
    function StatZjsdk() {
        _classCallCheck(this, StatZjsdk);

        // console.log("StatZjsdk constructor");

        // 请求地址格式： 'https://xxxx.com/zjserver/tgsdk/tgsdk/protocol/1000x.php'
        this.m_url = _BaseConfig.BaseConfig.Global.NetRoot + '/zjserver/tgsdk/tgsdk/protocol/';
    }

    /**
     * 新增用户统计
     * @param {string} _game_id  游戏id ，由服务器后台管理员分配
     * @param {string} _tg_code  推广码，服务器后台管理员分配
     * @param {string} _uid  用户uuid ，由客户端自己生成，上传到服务器，作为用户的唯一标识
     * 
     */


    //使用严格模式


    _createClass(StatZjsdk, [{
        key: "NewUser",
        value: function NewUser(_game_id, _tg_code, _uid) {

            if (_BaseUtil.BaseUtil.IsNull(_game_id)) {
                console.log("Error, StatZjsdk.NewUser _game_id is null");
                return;
            }

            if (_BaseUtil.BaseUtil.IsNull(_tg_code)) {
                console.log("Error, StatZjsdk.NewUser _tg_code is null");
                return;
            }

            if (_BaseUtil.BaseUtil.IsNull(_uid)) {
                console.log("Error, StatZjsdk.NewUser _uid is null");
                return;
            }

            var http = new _BaseHttp.BaseHttp();
            http.AddParam("pid", "10006");
            http.AddParam("game_id", _game_id);
            http.AddParam("tg_code", _tg_code);
            http.AddParam("uid", _uid);

            http.SendRequest(this.m_url + "10006.php", function (data) {
                console.log(data);
            }, function (err) {
                console.error(err);
            });
        }

        /**
         * 授权用户统计
         * @param {string} _game_id  游戏id ，由服务器后台管理员分配
         * @param {string} _tg_code  推广码，服务器后台管理员分配
         * @param {string} _uid  用户uuid ，由客户端自己生成，上传到服务器，作为用户的唯一标识
         * 
         */

    }, {
        key: "AuthUser",
        value: function AuthUser(_game_id, _tg_code, _uid) {

            if (_BaseUtil.BaseUtil.IsNull(_game_id)) {
                console.log("Error, StatZjsdk.AuthUser _game_id is null");
                return;
            }

            if (_BaseUtil.BaseUtil.IsNull(_tg_code)) {
                console.log("Error, StatZjsdk.AuthUser _tg_code is null");
                return;
            }

            if (_BaseUtil.BaseUtil.IsNull(_uid)) {
                console.log("Error, StatZjsdk.AuthUser _uid is null");
                return;
            }

            var http = new _BaseHttp.BaseHttp();
            http.AddParam("pid", "10007");
            http.AddParam("game_id", _game_id);
            http.AddParam("tg_code", _tg_code);
            http.AddParam("uid", _uid);

            http.SendRequest(this.m_url + "10006.php", function (data) {
                console.log(data);
            }, function (err) {
                console.error(err);
            });
        }

        /**
         * 返回当前实例
         */

    }], [{
        key: "Instance",
        value: function Instance() {
            if (this.m_Instance == null) {
                this.m_Instance = new StatZjsdk();
            }
            return this.m_Instance;
        }
    }]);

    return StatZjsdk;
}();

cc._RF.pop();