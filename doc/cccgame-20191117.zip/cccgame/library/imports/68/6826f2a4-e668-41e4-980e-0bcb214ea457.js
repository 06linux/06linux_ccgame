"use strict";
cc._RF.push(module, '6826fKk5mhB5JgOC8shTqRX', 'BaseJson');
// resources/script/base/BaseJson.js

"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.BaseJson = exports.BaseJson_NetPath = exports.BaseJson_LocalPath = exports.BaseJson_List = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _BaseConfig = require("./BaseConfig");

var _BaseHttp = require("./BaseHttp");

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

/**
* 本地的配置文件列表
* 备注：本地资源文件不需要文件后缀名称
*/
var BaseJson_List = exports.BaseJson_List = {
    Test1: "test1",
    Test2: "test2"

    // 本地件存放的路径
};var BaseJson_LocalPath = exports.BaseJson_LocalPath = '/data/json/';

// 网络存放路径
var BaseJson_NetPath = exports.BaseJson_NetPath = _BaseConfig.BaseConfig.Global.NetRoot + _BaseConfig.BaseConfig.Global.NetRes + '/json/';

/**
 *  配置表格加载封装
 *  备注：所有的数据表配置统一使用 json 格式
 */

var BaseJson = exports.BaseJson = function () {

    /**
     * 初始化
     */
    function BaseJson() {
        _classCallCheck(this, BaseJson);

        // console.log("BaseJson constructor");
        this.m_JsonData = new Map();
    }

    /**
     * 加载json文件
     * @param {Function} _callFun 回调函数 _callFun(res)
     * @param {string} _name  json 文件名称
     * @param {string} _path  文件路径
     * 
     * 使用举例：
     * BaseJson.Instance().Load(BaseJson_List.Test1,(res)=>{
                console.log('load json', res);
            });
     */


    //使用严格模式


    _createClass(BaseJson, [{
        key: "Load",
        value: function Load(_name, _callFun) {
            var _this = this;

            var _path = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : BaseJson_LocalPath;

            // 加载本地资源
            cc.loader.loadRes(_path + _name, function (err, res) {
                if (err) {
                    console.error(err);
                    return;
                }
                _this.m_JsonData.set(_name, res.json);

                if (_callFun) {
                    _callFun(res.json);
                }
            });
        }

        /**
         * 加载json文件
         * @param {Function} _callFun 回调函数 _callFun()
         * @param {Array} _nameArr  json 文件名称
         * @param {string} _path  文件路径
         * 
         * 使用说明：
         * BaseJson.Instance().LoadMore(['test1','test2'],()=>{
                    console.log('load more succ..');
                    }
                );
         */

    }, {
        key: "LoadMore",
        value: function LoadMore(_nameArr, _callFun) {
            var _path = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : BaseJson_LocalPath;

            var fileCount = _nameArr.length;
            var loadSucc = 0;

            for (var i = 0; i < fileCount; i++) {

                this.Load(_nameArr[i], function (res) {

                    loadSucc += 1;
                    // 所有文件都加载成功
                    if (fileCount == loadSucc) {
                        _callFun();
                    }
                }, _path);
            }
        }

        /**
         * 加载json文件 （网络文件）
         * @param {Function} _callFun 回调函数 _callFun(res)
         * @param {string} _name  json 文件名称
         * @param {string} _path  文件路径
         * 
         * 使用说明：
         * BaseJson.Instance().LoadNet('test1001.json', (res)=>{
                    console.log('LoadNet succ..',res);
                });
         */

    }, {
        key: "LoadNet",
        value: function LoadNet(_name, _callFun) {
            var _this2 = this;

            var _path = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : BaseJson_NetPath;

            var http = new _BaseHttp.BaseHttp();
            var url = _path + _name;
            http.m_method = 'GET';
            http.Request(url, function (data) {
                // console.log(data)
                _this2.m_JsonData.set(_name, data);
                _callFun(data);
            }, function (err) {
                console.error(err);
            });
        }

        /**
         * 加载json文件
         * @param {Function} _callFun 回调函数 _callFun()
         * @param {Array} _nameArr  json 文件名称
         * @param {string} _path  文件路径
         * 
         * BaseJson.Instance().LoadNetMore(['test1001.json','test1002.json'],()=>{
                    console.log('load more succ..');
                    }
                );
         */

    }, {
        key: "LoadNetMore",
        value: function LoadNetMore(_nameArr, _callFun) {
            var _path = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : BaseJson_NetPath;

            var fileCount = _nameArr.length;
            var loadSucc = 0;

            for (var i = 0; i < fileCount; i++) {

                this.LoadNet(_nameArr[i], function (res) {

                    loadSucc += 1;
                    // 所有文件都加载成功
                    if (fileCount == loadSucc) {
                        _callFun();
                    }
                }, _path);
            }
        }

        /**
         * 得到一个配置数据 (必须先加载成功才可以获取到)
         * @param {string} _name 
         */

    }, {
        key: "Get",
        value: function Get(_name) {
            return this.m_JsonData.get(_name);
        }

        /**
         * 打印所有一件加载的文件
         */

    }, {
        key: "DebugPrint",
        value: function DebugPrint() {
            console.log('----------------------------------');
            console.log('BaseJson.DebugPrint:');
            this.m_JsonData.forEach(function (value, key) {
                console.log(key, ':', value);
            });
        }

        /**
         * 返回当前实例
         */

    }], [{
        key: "Instance",
        value: function Instance() {
            if (this.m_Instance == null) {
                this.m_Instance = new BaseJson();
            }
            return this.m_Instance;
        }
    }]);

    return BaseJson;
}();

cc._RF.pop();