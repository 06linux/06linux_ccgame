"use strict";
cc._RF.push(module, '532c83BQrRIrLmedllYqH//', 'MainMenu');
// resources/script/menus/MainMenu.js

'use strict';

var _BaseMusic = require('../base/BaseMusic');

var _BaseMenu = require('../base/BaseMenu');

cc.Class({
    extends: cc.Component,

    properties: {},

    // LIFE-CYCLE CALLBACKS:

    onLoad: function onLoad() {
        this.node.on(cc.Node.EventType.TOUCH_START, this.TouchesBegin, this);
        this.node.on(cc.Node.EventType.TOUCH_MOVE, this.TouchesMoved, this);
        this.node.on(cc.Node.EventType.TOUCH_END, this.TouchesEnded, this);
        this.node.on(cc.Node.EventType.TOUCH_CANCEL, this.TouchesCancel, this);
    },
    start: function start() {},


    // update (dt) {},

    /**
     * 按钮点击事件
     * @param {cc.Touch} touch 
     */
    OnClick: function OnClick(touch) {
        //实现方法 示例
        console.log("MainMenu.OnClick:", touch.target.name, touch);

        if (touch.target.name == 'btn_start') {

            _BaseMenu.BaseMenu.Instance().PrefabLoad(this.node, _BaseMenu.BaseMenu_List.DemoMenu, function (objMenu) {
                console.log("load success ", _BaseMenu.BaseMenu_List.DemoMenu);
            });
        } else if (touch.target.name == 'btn_test') {
            console.log("test .....");

            _BaseMenu.BaseMenu.Instance().PrefabLoad(this.node, _BaseMenu.BaseMenu_List.TestMenuMain, function (objMenu) {
                console.log("load success ", _BaseMenu.BaseMenu_List.TestMenuMain);
            });
        }
    },


    /**
     * 触摸按下
     * @param {cc.touch} touch 
     */
    TouchesBegin: function TouchesBegin(touch) {},


    /**
     * 触摸移动
     * @param {cc.touch} touch
     */
    TouchesMoved: function TouchesMoved(touch) {},


    /**
     * 触摸抬起
     * @param {cc.touch} touch 
     */
    TouchesEnded: function TouchesEnded(touch) {
        // BaseUtil.CCLogGroupEnd();
    },


    /**
     * 触摸取消
     * @param {cc.touch} touch 
     */
    TouchesCancel: function TouchesCancel(touch) {}
});

cc._RF.pop();