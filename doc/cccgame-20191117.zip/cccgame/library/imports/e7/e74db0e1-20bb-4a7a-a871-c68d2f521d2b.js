"use strict";
cc._RF.push(module, 'e74dbDhILtKeqhxxo0vUh0r', 'GameMain');
// resources/script/scenes/GameMain.js

'use strict';

var _BaseConfig = require('../base/BaseConfig');

var _BaseMenu = require('../base/BaseMenu');

cc.Class({
    extends: cc.Component,

    properties: {},

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {

        console.log('GameMain start');
        _BaseMenu.BaseMenu.Instance().PrefabLoad(this.node, _BaseMenu.BaseMenu_List.MainMenu, function () {
            console.log('GameMain load menu success', _BaseMenu.BaseMenu_List.MainMenu);
        });
    }
}

// update (dt) {},


);

cc._RF.pop();