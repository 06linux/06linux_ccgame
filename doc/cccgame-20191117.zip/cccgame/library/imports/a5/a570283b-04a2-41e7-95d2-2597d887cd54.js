"use strict";
cc._RF.push(module, 'a5702g7BKJB55XSJZfYh81U', 'GamePlay');
// resources/script/gameplay/GamePlay.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {},

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {},


    // update (dt) {},

    /**
     * 按钮点击事件
     * @param {cc.Touch} touch 
     * if (touch.target.name == 'StartGame') {
     * }
     */
    OnClick: function OnClick(touch) {
        //实现方法 示例
        console.log("GamePlay click event:", touch);
        if (touch.target.name == 'Btn_Back') {}
    }
});

cc._RF.pop();