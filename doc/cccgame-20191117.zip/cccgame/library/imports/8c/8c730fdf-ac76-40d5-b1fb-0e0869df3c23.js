"use strict";
cc._RF.push(module, '8c730/frHZA1bH7Dghp3zwj', 'TestMenuMain');
// resources/script/menus/test/TestMenuMain.js

'use strict';

var _BaseMenu = require('../../base/BaseMenu');

var _BaseAction = require('../../base/BaseAction');

cc.Class({
    extends: cc.Component,

    properties: {},

    // LIFE-CYCLE CALLBACKS:

    onLoad: function onLoad() {
        this.node.on(cc.Node.EventType.TOUCH_START, this.TouchesBegin, this);
        this.node.on(cc.Node.EventType.TOUCH_MOVE, this.TouchesMoved, this);
        this.node.on(cc.Node.EventType.TOUCH_END, this.TouchesEnded, this);
        this.node.on(cc.Node.EventType.TOUCH_CANCEL, this.TouchesCancel, this);

        // 缩放进入
        this.node.scale = 0.1;
        _BaseAction.BaseAction.ScaleTo(this.node, 0.2, 1.0, 1.0);
    },
    start: function start() {},


    // update (dt) {},

    /**
     * 按钮点击事件
     * @param {cc.Touch} touch 
     */
    OnClick: function OnClick(touch) {
        var _this = this;

        //实现方法 示例
        console.log("TestMenuMain.OnClick:", touch.target.name, touch);

        if (touch.target.name == 'btn_close') {

            // 缩放退出
            _BaseAction.BaseAction.ScaleTo(this.node, 0.2, 0.1, 0.1, function () {
                _BaseMenu.BaseMenu.Instance().PrefebFree(_this.node);
            });
        } else if (touch.target.name == 'btn_test_menu') {
            _BaseMenu.BaseMenu.Instance().PrefabLoad(this.node, _BaseMenu.BaseMenu_List.TestMnu, function () {
                console.log("load success ", _BaseMenu.BaseMenu_List.TestMnu);
            });
        } else if (touch.target.name == 'btn_test_music') {
            _BaseMenu.BaseMenu.Instance().PrefabLoad(this.node, _BaseMenu.BaseMenu_List.TestMusic, function () {
                console.log("load success ", _BaseMenu.BaseMenu_List.TestMusic);
            });
        } else if (touch.target.name == 'btn_test_action') {
            _BaseMenu.BaseMenu.Instance().PrefabLoad(this.node, _BaseMenu.BaseMenu_List.TestAction, function () {
                console.log("load success ", _BaseMenu.BaseMenu_List.TestAction);
            });
        } else if (touch.target.name == 'btn_test_http') {
            _BaseMenu.BaseMenu.Instance().PrefabLoad(this.node, _BaseMenu.BaseMenu_List.TestHttp, function () {
                console.log("load success ", _BaseMenu.BaseMenu_List.TestHttp);
            });
        } else if (touch.target.name == 'btn_test_sav') {
            _BaseMenu.BaseMenu.Instance().PrefabLoad(this.node, _BaseMenu.BaseMenu_List.TestSave, function () {
                console.log("load success ", _BaseMenu.BaseMenu_List.TestSave);
            });
        } else if (touch.target.name == 'btn_test_json') {
            _BaseMenu.BaseMenu.Instance().PrefabLoad(this.node, _BaseMenu.BaseMenu_List.TestJson, function () {
                console.log("load success ", _BaseMenu.BaseMenu_List.TestJson);
            });
        } else if (touch.target.name == 'btn_test_util') {
            _BaseMenu.BaseMenu.Instance().PrefabLoad(this.node, _BaseMenu.BaseMenu_List.TestUtil, function () {
                console.log("load success ", _BaseMenu.BaseMenu_List.TestUtil);
            });
        } else if (touch.target.name == 'btn_test_npc') {
            _BaseMenu.BaseMenu.Instance().PrefabLoad(this.node, _BaseMenu.BaseMenu_List.TestNpc, function () {
                console.log("load success ", _BaseMenu.BaseMenu_List.TestNpc);
            });
        }
    },


    /**
     * 触摸按下
     * @param {cc.touch} touch 
     */
    TouchesBegin: function TouchesBegin(touch) {},


    /**
     * 触摸移动
     * @param {cc.touch} touch
     */
    TouchesMoved: function TouchesMoved(touch) {},


    /**
     * 触摸抬起
     * @param {cc.touch} touch 
     */
    TouchesEnded: function TouchesEnded(touch) {
        // BaseUtil.CCLogGroupEnd();
    },


    /**
     * 触摸取消
     * @param {cc.touch} touch 
     */
    TouchesCancel: function TouchesCancel(touch) {}
});

cc._RF.pop();