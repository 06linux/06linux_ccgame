"use strict";
cc._RF.push(module, '92324H73MZHGpZSt4ScYXJS', 'TestAction');
// resources/script/menus/test/TestAction.js

"use strict";

var _BaseAction = require("../../base/BaseAction");

var _BaseMenu = require("../../base/BaseMenu");

cc.Class({
    extends: cc.Component,

    properties: {
        m_Npc: cc.Node
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad: function onLoad() {

        this.node.on(cc.Node.EventType.TOUCH_START, this.TouchesBegin, this);
        this.node.on(cc.Node.EventType.TOUCH_MOVE, this.TouchesMoved, this);
        this.node.on(cc.Node.EventType.TOUCH_END, this.TouchesEnded, this);
        this.node.on(cc.Node.EventType.TOUCH_CANCEL, this.TouchesCancel, this);

        // 缩放进入
        this.node.scale = 0.1;
        _BaseAction.BaseAction.ScaleTo(this.node, 0.2, 1.0, 1.0);
    },
    start: function start() {},


    // update (dt) {
    //     console.log('update', dt);
    // },


    /**
     * 按钮点击事件
     * @param {cc.Touch} touch 
     */
    OnClick: function OnClick(touch) {
        var _this = this;

        console.log("TestAction OnClick:", touch.target.name, touch);
        if (touch.target.name == 'btn_close') {
            // 缩放退出
            _BaseAction.BaseAction.ScaleTo(this.node, 0.2, 0.1, 0.1, function () {
                _BaseMenu.BaseMenu.Instance().PrefebFree(_this.node);
            });
        }

        if (touch.target.name == 'btn_test1') {
            //    BaseAction.MoveTo(this.m_Npc, 0.5, cc.v2(200,200), ()=>{
            //         console.log('move to succ');
            //    });

            //    BaseAction.MoveBy(this.m_Npc, 0.5, cc.v2(50,50), ()=>{
            //     console.log('move by succ');
            //   });

            _BaseAction.BaseAction.MoveToLoop(this.m_Npc, 1, cc.v2(this.m_Npc.x, this.m_Npc.y + 200), function () {
                console.log('move to loop succ');
            });

            //    BaseAction.MoveByLoop(this.m_Npc, 1, cc.v2(100,100), ()=>{
            //     console.log('move by loop succ');
            //    });
        } else if (touch.target.name == 'btn_test2') {
            _BaseAction.BaseAction.MoveBy(this.m_Npc, 0.5, cc.v2(20, 20), function () {
                console.log('move by succ');
            });
        } else if (touch.target.name == 'btn_test3') {

            _BaseAction.BaseAction.Delay(this.m_Npc, 1, function () {
                console.log('delay succ');
            });

            _BaseAction.BaseAction.ScaleLoop(this.m_Npc, 0.5, 1.3, 1, function () {
                console.log('ScaleLoop call....');
            });
        } else if (touch.target.name == 'btn_test4') {
            // BaseAction.ScaleBy(this.m_Npc, 0.5, 0.3, 0.3, ()=>{
            //     console.log('scale by success');
            // });

            // BaseAction.RouteTo(this.m_Npc,1, 90, ()=>{
            //     console.log(' route to success');
            // });

            // BaseAction.RouteBy(this.m_Npc,1, 60, ()=>{
            //     console.log(' route by success');
            // });

            _BaseAction.BaseAction.RouteLoop2(this.m_Npc, 1, function () {
                console.log(' route by success');
            });
        }
    },


    /**
     * 触摸按下
     * @param {cc.touch} touch 
     */
    TouchesBegin: function TouchesBegin(touch) {
        // console.log("DemoMenu TouchesBegin:", touch.target.name, touch );
    },


    /**
     * 触摸移动
     * @param {cc.touch} touch
     */
    TouchesMoved: function TouchesMoved(touch) {
        // console.log("DemoMenu TouchesMoved:", touch.target.name, touch );
    },


    /**
     * 触摸抬起
     * @param {cc.touch} touch 
     */
    TouchesEnded: function TouchesEnded(touch) {
        // console.log("DemoMenu TouchesEnded:", touch.target.name, touch );
    },


    /**
     * 触摸取消
     * @param {cc.touch} touch 
     */
    TouchesCancel: function TouchesCancel(touch) {}
});

cc._RF.pop();