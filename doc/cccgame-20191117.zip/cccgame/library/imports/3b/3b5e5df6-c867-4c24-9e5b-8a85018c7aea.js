"use strict";
cc._RF.push(module, '3b5e532yGdMJJ5bioUBjHrq', 'Platform');
// resources/script/platform/Platform.js

"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.Platform = exports.PlatformType = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _class, _temp;

var _NativeAndroid = require("./NativeAndroid");

var _NativeIos = require("./NativeIos");

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

/**
 * 游戏运行平台相关的函数，代码，判定逻辑等等
 */

// 自定义平台类型，主要自定义的类型
// 如果系统底层已经存在类型判定，在 IsXXXChanelName() 函数中直接使用系统底层的类型判定
var PlatformType = exports.PlatformType = {

    NULL: 10000,

    // 小游戏渠道
    YXY_ChannelName1: 20001,
    YXY_ChannelName2: 20002,

    // h5 渠道(web)
    WEB_ChannelName1: 30001,
    WEB_ChannelName2: 30002,

    // 原生 android 渠道
    ANDROID: 40001,
    ANDROID_233: 40002,
    ANDROID_Test1: 40003,
    ANDROID_Test2: 40004,

    // 原生 Ios 渠道
    IOS: 50001,
    IOS_AppStore: 50002,
    IOS_ChannelName1: 50003

    /**
     * 平台判定，平台函数的封装
     */
};var Platform = exports.Platform = (_temp = _class = function () {
    function Platform() {
        _classCallCheck(this, Platform);
    }

    _createClass(Platform, null, [{
        key: "_Init_",


        // 初始化(初始化调用平台相关代码)


        //使用严格模式
        value: function _Init_() {

            if (this.IsWeiChat()) {
                WeChat.Instance().OnShow();
                WeChat.Instance().OnHide();
                WeChat.Instance().InitWxShare();
            } else if (this.IsAndroid()) {
                //调用Android的回调绑定
                _NativeAndroid.NativeAndrid.Instance().NativeCallBack();
            } else if (this.IsIPhone()) {
                _NativeIos.NativeIos.Instance().NativeCallBack();
            } else {}
        }

        /**
         * 当前运行环境判定
         * 微信小游戏
         */


        /**
         * 自定义当前游戏的打包渠道
         */

    }, {
        key: "IsWeiChat",
        value: function IsWeiChat() {
            if (cc.sys.platform == cc.sys.WECHAT_GAME) {
                return true;
            }
            return false;
        }

        /**
         * 当前运行环境判定
         * QQ小游戏
         */

    }, {
        key: "IsQQ",
        value: function IsQQ() {
            if (cc.sys.platform == cc.sys.QQ_PLAY) {
                return true;
            }
            return false;
        }

        /**
         * 当前运行环境判定
         * 原生 android 环境
         */

    }, {
        key: "IsAndroid",
        value: function IsAndroid() {
            if (cc.sys.platform == cc.sys.ANDROID) {
                return true;
            }
            return false;
        }

        /**
         * 当前运行环境判定
         * 自定义渠道判定
         */

    }, {
        key: "IsAndroid233",
        value: function IsAndroid233() {
            if (PlatformType.ANDROID_233 == this.TYPE) {
                return true;
            }
            return false;
        }

        /**
         * 当前运行环境判定
         * 原生 android 环境
         */

    }, {
        key: "IsIPhone",
        value: function IsIPhone() {
            if (cc.sys.platform == cc.sys.IPHONE) {
                return true;
            }
            return false;
        }
    }]);

    return Platform;
}(), _class.TYPE = PlatformType.NULL, _temp);

// 初始化

Platform._Init_();

cc._RF.pop();