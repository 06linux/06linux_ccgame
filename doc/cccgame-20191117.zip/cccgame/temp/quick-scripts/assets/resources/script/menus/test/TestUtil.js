(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/resources/script/menus/test/TestUtil.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '2c87eQF/T1GmaytihVTHDNv', 'TestUtil', __filename);
// resources/script/menus/test/TestUtil.js

"use strict";

var _BaseMenu = require("../../base/BaseMenu");

var _BaseAction = require("../../base/BaseAction");

cc.Class({
    extends: cc.Component,

    properties: {},

    // LIFE-CYCLE CALLBACKS:

    onLoad: function onLoad() {

        this.node.on(cc.Node.EventType.TOUCH_START, this.TouchesBegin, this);
        this.node.on(cc.Node.EventType.TOUCH_MOVE, this.TouchesMoved, this);
        this.node.on(cc.Node.EventType.TOUCH_END, this.TouchesEnded, this);
        this.node.on(cc.Node.EventType.TOUCH_CANCEL, this.TouchesCancel, this);

        // 缩放进入
        this.node.scale = 0.1;
        _BaseAction.BaseAction.ScaleTo(this.node, 0.2, 1.0, 1.0);
    },
    start: function start() {},


    // update (dt) {
    //     console.log('update', dt);
    // },


    /**
     * 按钮点击事件
     * @param {cc.Touch} touch 
     */
    OnClick: function OnClick(touch) {
        var _this = this;

        console.log("DemoMenu OnClick:", touch.target.name, touch);
        if (touch.target.name == 'btn_close') {
            // 缩放退出
            _BaseAction.BaseAction.ScaleTo(this.node, 0.2, 0.1, 0.1, function () {
                _BaseMenu.BaseMenu.Instance().PrefebFree(_this.node);
            });
        }

        if (touch.target.name == 'btn_ok') {
            _BaseMenu.BaseMenu.Instance().PrefebFreeByUrl(this.node.parent, _BaseMenu.BaseMenu_List.DemoMenu);
        }

        if (touch.target.name == 'btn_test') {
            console.log('this', this);
            console.log('this.node', this.node);

            var obj = _BaseMenu.BaseMenu.Instance().PrefabGet(this.node.parent, _BaseMenu.BaseMenu_List.DemoMenu);
            console.log('obj', obj);

            // 测试界面叠加
            _BaseMenu.BaseMenu.Instance().PrefabLoad(this.node, _BaseMenu.BaseMenu_List.DemoMenu, function () {
                console.log("load menu succ", _BaseMenu.BaseMenu_List.DemoMenu);
            });
        }
    },


    /**
     * 触摸按下
     * @param {cc.touch} touch 
     */
    TouchesBegin: function TouchesBegin(touch) {
        // console.log("DemoMenu TouchesBegin:", touch.target.name, touch );
    },


    /**
     * 触摸移动
     * @param {cc.touch} touch
     */
    TouchesMoved: function TouchesMoved(touch) {
        // console.log("DemoMenu TouchesMoved:", touch.target.name, touch );
    },


    /**
     * 触摸抬起
     * @param {cc.touch} touch 
     */
    TouchesEnded: function TouchesEnded(touch) {
        // console.log("DemoMenu TouchesEnded:", touch.target.name, touch );
    },


    /**
     * 触摸取消
     * @param {cc.touch} touch 
     */
    TouchesCancel: function TouchesCancel(touch) {}
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=TestUtil.js.map
        