(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/resources/script/platform/NativeAndroid.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'dc481OlvhFEYK/Q+EuDls2Q', 'NativeAndroid', __filename);
// resources/script/platform/NativeAndroid.js

"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

/**
 * 安卓原生平台
 */
var NativeAndrid = exports.NativeAndrid = function () {

    /**
     * 初始化
     */
    function NativeAndrid() {
        _classCallCheck(this, NativeAndrid);

        this.JsbMethod = {
            //()V 无参数 无返回值
            //(Ljava/lang/String;)V 参数为string 无返回值
            //()Ljava/lang/String;  无参数 返回string
            //(Ljava/lang/String;)Ljava/lang/String;  
            //org.cocos2dx.javascript/AppActivity
            classPath: "org/cocos2dx/javascript/AppActivity",

            //java 调用无参数无返回值的函数
            CALL_JAVA_Arg0_RetVoid: function CALL_JAVA_Arg0_RetVoid(functionname) {
                jsb.reflection.callStaticMethod(this.classPath, functionname, "()V");
            },


            //java 调用一个参数无返回值的函数
            CALL_JAVA_Arg1_RetVoid: function CALL_JAVA_Arg1_RetVoid(functionname, param1) {
                jsb.reflection.callStaticMethod(this.classPath, functionname, "(Ljava/lang/String;)V", param1);
            },


            //java 调用两个参数无返回值的函数
            CALL_JAVA_Arg2_RetVoid: function CALL_JAVA_Arg2_RetVoid(functionname, param1, param2) {
                jsb.reflection.callStaticMethod(this.classPath, functionname, "(Ljava/lang/String;Ljava/lang/String;)V", param1, param2);
            },


            //java 调用三个参数无返回值的函数
            CALL_JAVA_Arg3_RetVoid: function CALL_JAVA_Arg3_RetVoid(functionname, param1, param2, param3) {
                jsb.reflection.callStaticMethod(this.classPath, functionname, "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V", param1, param2, param3);
            },


            //java 调用四个参数无返回值的函数
            CALL_JAVA_Arg4_RetVoid: function CALL_JAVA_Arg4_RetVoid(functionname, param1, param2, param3, param4) {
                jsb.reflection.callStaticMethod(this.classPath, functionname, "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V", param1, param2, param3, param4);
            },


            //java 调用无参数有返回值的函数
            CALL_JAVA_Arg0_RetArg: function CALL_JAVA_Arg0_RetArg(functionname) {
                var result = jsb.reflection.callStaticMethod(this.classPath, functionname, "()Ljava/lang/String;");
                return result;
            },


            //java 调用一个参数有返回值的函数
            CALL_JAVA_Arg1_RetArg: function CALL_JAVA_Arg1_RetArg(functionname, param1) {
                var result = jsb.reflection.callStaticMethod(this.classPath, functionname, "(Ljava/lang/String;)Ljava/lang/String;", param1);
                return result;
            },


            //java 调用两个参数有返回值的函数
            CALL_JAVA_Arg2_RetArg: function CALL_JAVA_Arg2_RetArg(functionname, param1, param2) {
                var result = jsb.reflection.callStaticMethod(this.classPath, functionname, "(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;", param1, param2);
                return result;
            }
        };

        console.log("NativeAndrid constructor");
    }

    /**
     * jsb 调用函数
     */


    //使用严格模式


    _createClass(NativeAndrid, [{
        key: "NativeCallBack",


        /**
         * Android apk 交互相关函数
         * Java 函数调用 JavaScript 函数的封装
         *
         * 备注：回调函数必须绑定在 window 对象上，作为全局函数使用 
         */
        value: function NativeCallBack() {
            /**
             * 视频奖励发放
             */
            window.RewardVideoADonReward = function (state) {
                console.log("RewardVideoADonReward state:", state);
                if (state == 1) {
                    //视频播放成功
                    NativeAndrid.Instance()._onRewardSuccess();
                } else {
                    //视频播放失败
                    NativeAndrid.Instance()._onRewardFail();
                }
            };
        }

        /*
        * 显示激励视频视频广告
        */

    }, {
        key: "GstRewardVideoAD",
        value: function GstRewardVideoAD() {
            var _onSuccess = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : null;

            var _onFail = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;

            console.log("调用java GstRewardVideoAD");
            this._onRewardSuccess = _onSuccess;
            this._onRewardFail = _onFail;

            this.JsbMethod.CALL_JAVA_Arg0_RetVoid('GstRewardVideoAD');
        }

        /**
         * 返回当前实例
         */

    }], [{
        key: "Instance",
        value: function Instance() {
            if (this.m_Instance == null) {
                this.m_Instance = new NativeAndrid();
            }
            return this.m_Instance;
        }
    }]);

    return NativeAndrid;
}();

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=NativeAndroid.js.map
        