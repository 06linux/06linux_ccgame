(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/resources/script/base/Base.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '720bf2KJv5I0of+CsfVwucL', 'Base', __filename);
// resources/script/base/Base.js

"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

/**
 * Base 模块初始化设置
 */
var Base = exports.Base = function () {
    function Base() {
        _classCallCheck(this, Base);
    }

    _createClass(Base, null, [{
        key: "Init",
        value: function Init() {
            console.log("Base.Init ...");
        }

        //使用严格模式

    }, {
        key: "Destory",
        value: function Destory() {
            console.log("Base.Destory ...");
        }
    }, {
        key: "OnShow",
        value: function OnShow() {
            console.log("Base.OnShow ...");
        }
    }, {
        key: "OnHidden",
        value: function OnHidden() {
            console.log("Base.OnHidden ...");
        }
    }]);

    return Base;
}();

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=Base.js.map
        