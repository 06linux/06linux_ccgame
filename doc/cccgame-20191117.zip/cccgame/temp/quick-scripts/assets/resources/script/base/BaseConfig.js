(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/resources/script/base/BaseConfig.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'ee618vMnW9Bno1ydhN87C4M', 'BaseConfig', __filename);
// resources/script/base/BaseConfig.js

"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _class, _temp;

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

/**
 * 配置类
 * 各种全局配置参数
 */
var BaseConfig = exports.BaseConfig = (_temp = _class = function BaseConfig() {
  _classCallCheck(this, BaseConfig);
}, _class.IsLoading = false, _class.Debug = false, _class.Global = {

  NetRoot: "https://cathome8.com",
  NetRes: "/zjkj_h5/demo/res_1001",

  BoxMenuNetRes: "/zjkj_boxmenu/",
  BoxMenuVersion: "zy_game_ml/res_tcsdjz_1002/",

  Game_Is_Review: true, //审核开关

  Game_Bind_App_List: [], //绑定游戏列表（微信小游戏用到）
  Game_Query: {},
  Game_Name: "贪吃蛇大激战222"

  /**
  * 微信 平台信息
  */
}, _class.WeChatGlobal = {
  WxAppId: "wx4f585094799e2ce4", //
  WxAppType: "zy",

  BannerAdUnitId: "adunit-5b75f5566c6d3990", //baner 广告id adunit-
  RewardedVideoAdUnitId: "adunit-5b75f5566c6d3990", //视频激励广告id adunit-
  InterstitialAdUnitId: "adunit-a3c388a689286227" //插屏广告id  adunit-
  // interstitialAd


  /**
   * wx分包名字
   */
}, _class.WxSubPackageName = 'subpackage', _class.ShareTextData = {
  ShareText1: "震惊，世界上最长的蛇竟然是…",
  ShareText2: "贪吃蛇经典玩法升级，不来看看？",
  ShareText3: "开局一条鲲，变长全靠吞…",
  ShareText4: "我就是我，是颜色不一样的大蛇！",
  ShareText5: "不想当女娲的贪吃蛇不是好蛇蛇！"

  /**
   * 分享图片
   * 
   */
}, _class.ShareImgData = {
  ShareImg1: "wx_share_img_1.png",
  ShareImg2: "wx_share_img_2.png",
  ShareImg3: "wx_share_img_3.png"

  /**------------------------------------------------------------------------------------------------------------- 
   ****************************************开放域数据*************************************************************
  ----------------------------------------------------------------------------------------------------------------/
  
  /**
   * 向开放域发送的消息类型
   * 需要在开放域里处理对应逻辑
   */
}, _class.OpenDataMessageType = {
  GetCloudStorage: 'getcloudstorage',
  ShowEndlessRank: 'showendlessrank',
  ShowLimitTimeRank: 'showLimittimerank',
  ShowGoodTimeRank: 'showgoodtimerank'

  /**
   * 向开放域发送的消息数据格式
   * 需要在开放域里读取对应数据
   */
}, _class.OpenDataMessageData = {
  MessageType: '',
  KVDataList: [],
  Data: '',
  DataKey: ''

  /**
   * 限时模式数据key值
   */
}, _class.LimitTimeCloudDataKey = 'limittimedata', _class.EndlessCloudDataKey = 'endlessdata', _class.GoodTimeCloudDataKey = 'goodtimedata', _class.CloudData = {
  UUID: '',
  Score: 0,
  UpdateTime: 0
}, _temp);

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=BaseConfig.js.map
        