(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/resources/script/base/BaseSav.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '058c22W1wtLKa6xWox9wk25', 'BaseSav', __filename);
// resources/script/base/BaseSav.js

"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.BaseSav = exports.BaseSav_Data = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _class, _temp;

var _BaseUtil = require("./BaseUtil");

var _Platform = require("../platform/Platform");

var _WeiChat = require("../platform/WeiChat");

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

/**
 * 用户存档数据读取 
 * (根据实际游戏需求自己定义存档内容)
 */
var BaseSav_Data = exports.BaseSav_Data = {

    name: 'zhangsan',
    age: 111,
    desc: 'i am zhangsan'

};

var BaseSav = exports.BaseSav = (_temp = _class = function () {

    /**
     * 初始化
     */


    //使用严格模式
    function BaseSav() {
        _classCallCheck(this, BaseSav);

        // console.log("BaseSav constructor");

        // 用户唯一的 uuid
        this.m_uuid = '';

        // 初始化用户 uuid 
        this.m_uuid = this.Read(BaseSav.SavKey);
        if (_BaseUtil.BaseUtil.IsNull(this.m_uuid)) {
            this.m_uuid = _BaseUtil.BaseUtil.GetUUID();
            this.Write(BaseSav.SavKey, this.m_uuid);
            this.WriteData();
        }

        // 读取用户数据
        this.ReadData();
    }

    /**
     * 读用户存档 （默认的存档数据）
     */


    // 用户存档的 key （默认不用改变）


    _createClass(BaseSav, [{
        key: "ReadData",
        value: function ReadData() {
            exports.BaseSav_Data = BaseSav_Data = JSON.parse(this.Read(this.m_uuid));
        }

        /**
         * 写用户存档 （默认的存档数据）
         */

    }, {
        key: "WriteData",
        value: function WriteData() {
            this.Write(this.m_uuid, JSON.stringify(BaseSav_Data));
        }

        /**
         * 读取存档
         * @param {string} _savName 存档名称
         * @returns 存档记录（string 格式）
         */

    }, {
        key: "Read",
        value: function Read(_savName) {

            if (_Platform.Platform.IsWeiChat()) {
                return _WeiChat.WeiChat.Instance().Read(_savName);
            } else {
                return cc.sys.localStorage.getItem(_savName);
            }
        }

        /**
         * 写存档
         * @param {string} _savName 存档名称
         * @param {string} _str 存档内容
         */

    }, {
        key: "Write",
        value: function Write(_savName, _str) {

            if (_Platform.Platform.IsWeiChat()) {
                _WeiChat.WeiChat.Instance().Write(_savName, _str);
            } else {
                cc.sys.localStorage.setItem(_savName, _str);
            }
        }

        /**
         * 获取用户的 uuid
         */

    }, {
        key: "GetUUID",
        value: function GetUUID() {
            return this.m_uuid;
        }

        /**
         * 返回当前实例
         */

    }], [{
        key: "Instance",
        value: function Instance() {
            if (this.m_Instance == null) {
                this.m_Instance = new BaseSav();
            }
            return this.m_Instance;
        }
    }]);

    return BaseSav;
}(), _class.SavKey = 'sav_key_cccgame', _temp);

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=BaseSav.js.map
        