(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/resources/script/platform/StatAld.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'aae14hWPyBCFZDOUytTxaJ6', 'StatAld', __filename);
// resources/script/platform/StatAld.js

"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.StatAld = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _Platform = require("./Platform");

var _BaseSav = require("../base/BaseSav");

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

/**
 * 阿拉丁统计 (微信小游戏使用)
 */
var StatAld = exports.StatAld = function () {

    /**
     * 初始化
     */
    function StatAld() {
        _classCallCheck(this, StatAld);

        console.log("TgSDKServer constructor");
    }

    /**
     * 自定义事件统计：游戏盒子 
     * @param {object} _appdata
     */


    //使用严格模式


    _createClass(StatAld, [{
        key: "EventGameBox",
        value: function EventGameBox(_appdata) {
            var _menuname = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;

            console.log('EventGameBox:', _appdata);
            // var data_name = data.name_skip?data.name_skip:_appdata.name;
            // 统计所有游戏
            wx.aldSendEvent('自研盒子v201905-点击统计', {
                "自研游戏名称": BaseConfig.Global.Game_Name,
                "推广游戏名称": _appdata.name_skip ? _appdata.name_skip : _appdata.name,
                "位置统计": _menuname ? _menuname : _appdata.tjwz
            });

            // 统计当前游戏
            wx.aldSendEvent('自研盒子v201905-游戏统计', {
                "贪吃蛇大激战": _appdata.name_skip ? _appdata.name_skip : _appdata.name,
                "贪吃蛇大激战_位置": _menuname ? _menuname + '_' + BaseConfig.Global.Game_Name : _appdata.tjwz + '_' + BaseConfig.Global.Game_Name
            });
        }

        /**
         * 自定义事件统计：界面打点统计
         * @param {string} _menuname
         */

    }, {
        key: "EventMenu",
        value: function EventMenu(_menuname) {
            // 统计所有游戏
            wx.aldSendEvent('界面统计', {
                "自研游戏名称": BaseConfig.Global.Game_Name,
                "界面名字": _menuname
            });
        }

        /**
         * 自定义事件统计：皮肤打点
         * @param {string} _skinname
         */

    }, {
        key: "EventSkin",
        value: function EventSkin(_skinname) {

            // 统计所有游戏
            wx.aldSendEvent('皮肤统计', {
                "自研游戏名称": BaseConfig.Global.Game_Name,
                "皮肤名字": _skinname
            });
        }

        /**
         * 关卡统计 关卡开始
         * @param {string} _stageId     关卡ID      该字段只能是 1 , 2 , 3 , 1.1 , 1.2 , 1.3 格式 最多支持 32 个字符 
         * @param {string} _stageName   关卡名字     最多支持 32 个字符
         * 
         */

    }, {
        key: "Stage_OnStart",
        value: function Stage_OnStart() {
            var _stageId = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "1";

            var _stageName = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : "第一关";

            console.log('Stage_OnStart _stageId:', _stageId, "_stageName:", _stageName);
            //关卡开始
            wx.aldStage.onStart({
                stageId: _stageId, //关卡ID 该字段必传
                stageName: _stageName, //关卡名称  该字段必传
                userId: _BaseSav.BaseSav.Instance().GetUUID //用户ID 可选
            });
        }

        /**
         * 关卡统计 关卡中使用道具
         * @param {string} _stageId     关卡ID      该字段只能是 1 , 2 , 3 , 1.1 , 1.2 , 1.3 格式 最多支持 32 个字符 
         * @param {string} _stageName   关卡名字     最多支持 32 个字符 
         * @param {string} _event       事件类型     payStart:发起支付 paySuccess:支付成功 payFail:支付失败 tools:使用道具 revive:复活 award:奖励
         * @param {string} _itemName    物品名字     
         * @param {string} _itemId      物品id     
         * @param {number} _itemCount   物品数量         
         * @param {string} _itemdesc    物品描述     
         * @param {number} _itemMoney   物品价格     
         * 
         */

    }, {
        key: "Stage_OnRunning",
        value: function Stage_OnRunning() {
            var _stageId = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "1";

            var _stageName = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : "第一关";

            var _event = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : "tools";

            var _itemName = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : "物品名字";

            var _itemId = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : "110";

            var _itemCount = arguments.length > 5 && arguments[5] !== undefined ? arguments[5] : 1;

            var _itemdesc = arguments.length > 6 && arguments[6] !== undefined ? arguments[6] : "描述";

            var _itemMoney = arguments.length > 7 && arguments[7] !== undefined ? arguments[7] : 100;

            console.log('Stage_OnRunning _stageId:', _stageId, "_stageName:", _stageName);
            //关卡中
            wx.aldStage.onRunning({
                stageId: _stageId,
                stageName: _stageName,
                userId: _BaseSav.BaseSav.Instance().GetUUID,
                event: _event,
                params: {
                    itemName: _itemName,
                    itemId: _itemId,
                    itemCount: _itemCount,
                    desc: _itemdesc,
                    itemMoney: _itemMoney

                }
            });
        }

        /**
         * 关卡统计 关卡结束
         * @param {string} _stageId     关卡ID      该字段只能是 1 , 2 , 3 , 1.1 , 1.2 , 1.3 格式 最多支持 32 个字符 
         * @param {string} _stageName   关卡名字     最多支持 32 个字符 
         * @param {string} _event       事件类型     complete:成功 fail:失败 
         * @param {string} _stageDesc   原因描述     
         * 
         */

    }, {
        key: "Stage_OnEnd",
        value: function Stage_OnEnd() {
            var _stageId = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "1";

            var _stageName = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : "第一关";

            var _event = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : "complete";

            var _stageDesc = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : "关卡完成";

            console.log('Stage_OnEnd _stageId:', _stageId, "_stageName:", _stageName);
            //关卡完成
            wx.aldStage.onEnd({
                stageId: _stageId, //关卡ID 该字段必传
                stageName: _stageName, //关卡名称  该字段必传
                userId: _BaseSav.BaseSav.Instance().GetUUID, //用户ID 可选
                event: _event, //关卡完成  关卡进行中，用户触发的操作    该字段必传
                params: {
                    desc: _stageDesc //描述
                }
            });
        }

        /**
         * 返回当前实例
         */

    }], [{
        key: "Instance",
        value: function Instance() {
            if (this.m_Instance == null) {
                this.m_Instance = new StatAld();
            }
            return this.m_Instance;
        }
    }]);

    return StatAld;
}();

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=StatAld.js.map
        