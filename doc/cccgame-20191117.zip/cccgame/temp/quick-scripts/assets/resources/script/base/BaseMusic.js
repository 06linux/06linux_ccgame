(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/resources/script/base/BaseMusic.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '5fdd69Scu1HKYg/aIImyZET', 'BaseMusic', __filename);
// resources/script/base/BaseMusic.js

"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.BaseMusic = exports.BaseMusic_List = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _class, _temp;

var _BaseConfig = require("./BaseConfig");

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

/**
 * 本地音乐资源 
 * 
 * 备注：本地音乐资源名称不用加后缀名
 * 
 */
var BaseMusic_List = exports.BaseMusic_List = {
    Music_1: "music_1",
    Music_2: "music_2",
    Music_3: "music_3",

    Sound_Touch: "sound_touch",
    Sound_ReadyGo: "sound_ready_go"

    // 本地音乐文件存放的路径
};var BaseMuisc_LocalPath = '/data/music/';

// 网络音乐存放路径
var BaseMuisc_NetPath = _BaseConfig.BaseConfig.Global.NetRoot + _BaseConfig.BaseConfig.Global.NetRes + '/music/';

/**
 * 游戏音乐音效函数封装
 * 
 * 背景音乐： 可以循环播放
 * 游戏音效：只能播放一次
 */
var BaseMusic = exports.BaseMusic = (_temp = _class = function () {

    /**
     * 初始化
     */
    function BaseMusic() {
        _classCallCheck(this, BaseMusic);

        // console.log("BaseMusic constructor");

        //  存储当前已经成功加载的音乐资源
        this.m_audio_data = new Map();

        // 存档当前正在播放的背景音乐 id
        this.m_music_id = 0;

        // 存档当前正在播放的音效id
        this.m_sound_id = 0;
    }

    /**
     * 初始化，加载音乐列表中配置的音乐 （本地音乐列表加载）
     * @param {Function} _callFun  
     */


    //使用严格模式


    _createClass(BaseMusic, [{
        key: "LoadMuiscList",
        value: function LoadMuiscList(_callFun) {

            //加载音乐
            var temp_array = [];
            var load_num = 0;
            for (var key in BaseMusic_List) {
                //往数组中放值
                temp_array.push(BaseMusic_List[key]);
            }
            // console.log('temp_array', temp_array);

            for (var index = 0; index < temp_array.length; index++) {

                this.Load(temp_array[index], function () {
                    load_num++;
                    //资源加载完毕
                    if (temp_array.length == load_num) {
                        if (_callFun) {
                            _callFun();
                        }
                    }
                });
            }
        }

        /**
         * 加载本地音乐
         * @param {string} _name, 音乐资源文件名称， 例如： 'music_1.mp3'
         * @param {string} _path, 音乐资源的路径， 例如： '/data/muisc/'
         * @param {Function} _callFun, 加载成功后回掉函数
         */

    }, {
        key: "Load",
        value: function Load(_name) {
            var _this = this;

            var _callFun = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;

            var _path = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : BaseMuisc_LocalPath;

            // 加载本地资源
            cc.loader.loadRes(_path + _name, function (err, audio) {
                if (err) {
                    console.error(err);
                    return;
                }

                _this.m_audio_data.set(_name, audio);
                if (_callFun) {
                    _callFun(audio);
                }
            });
        }

        /**
         * 加载网络音乐资源
         * @param {string} _name, 音乐资源文件名称， 例如： 'music_1.mp3'
         * @param {string} _path, 音乐资源的路径， 例如： 'http://xxxx.com/demo/res_1001/music/'
         * @param {Function} _callFun, 加载成功后回掉函数
         */

    }, {
        key: "LoadNet",
        value: function LoadNet(_name) {
            var _this2 = this;

            var _callFun = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;

            var _path = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : BaseMuisc_NetPath;

            cc.loader.load(_path + _name, function (err, audio) {
                if (err) {
                    console.error(err);
                    return;
                }
                _this2.m_audio_data.set(_name, audio);
                if (_callFun) {
                    _callFun(audio);
                }
            });
        }

        /**
         * 播放背景音乐
         * @param {string} _name  音乐文件名称 
         */

    }, {
        key: "MusicPlay",
        value: function MusicPlay(_name) {

            if (!BaseMusic.IsOpenMusic) {
                return;
            }

            var audio = this.m_audio_data.get(_name);
            if (audio) {
                this.MusicStop();
                this.m_music_id = cc.audioEngine.playMusic(audio, true);
            } else {
                console.log('MusicPlay not load _musicname', _name);
            }
        }

        /**
         * 停止背景音乐
         */

    }, {
        key: "MusicStop",
        value: function MusicStop() {
            cc.audioEngine.stopMusic();
        }

        /**
         * 暂停背景音乐
         */

    }, {
        key: "MusicPause",
        value: function MusicPause() {
            cc.audioEngine.pauseMusic();
        }

        /**
         * 恢复背景音乐
         */

    }, {
        key: "MusicResume",
        value: function MusicResume() {
            cc.audioEngine.resumeMusic();
        }

        /**
         * 播放音效
         * @param {string} _name  音乐文件名称 
         */

    }, {
        key: "SoundPlay",
        value: function SoundPlay(_name) {

            if (!BaseMusic.IsOpenSound) {
                return;
            }

            var audio = this.m_audio_data.get(_name);
            if (audio) {
                this.m_sound_id = cc.audioEngine.playEffect(audio, false);
            } else {
                console.log('SoundPlay not load _soundname', _name);
            }
        }

        /**
         * 停止音效
         */

    }, {
        key: "SoundStop",
        value: function SoundStop() {
            cc.audioEngine.stopEffect(this.m_sound_id);
        }

        /**
         * 停止音效
         */

    }, {
        key: "SoundStopAll",
        value: function SoundStopAll() {
            cc.audioEngine.stopAllEffects();
        }

        /**
         * 暂停音效
         */

    }, {
        key: "SoundPause",
        value: function SoundPause() {
            cc.audioEngine.pauseEffect(this.m_sound_id);
        }

        /**
         * 暂停音效
         */

    }, {
        key: "SoundPauseAll",
        value: function SoundPauseAll() {
            cc.audioEngine.pauseAllEffects();
        }

        /**
         * 恢复音效
         */

    }, {
        key: "SoundResume",
        value: function SoundResume() {
            cc.audioEngine.resumeEffect(this.m_sound_id);
        }

        /**
         * 恢复音效
         */

    }, {
        key: "SoundResumeAll",
        value: function SoundResumeAll() {
            cc.audioEngine.resumeAllEffects();
        }

        /**
         * 音乐控制 (声音开关控制)
         * 
         * 使用举例：
         * 
            BaseMusic.IsOpenSound = !BaseMusic.IsOpenSound;
            BaseMusic.IsOpenMusic = !BaseMusic.IsOpenMusic;
            BaseMusic.Instance().MusicControl();
         */

    }, {
        key: "MusicControl",
        value: function MusicControl() {

            if (BaseMusic.IsOpenMusic) {
                this.MusicResume();
            } else {
                this.MusicPause();
            }

            if (!BaseMusic.IsOpenSound) {
                this.SoundStopAll();
            }
        }

        /**
         * 返回当前实例
         */

    }], [{
        key: "Instance",
        value: function Instance() {
            if (this.m_Instance == null) {
                this.m_Instance = new BaseMusic();
            }
            return this.m_Instance;
        }
    }]);

    return BaseMusic;
}(), _class.IsOpenMusic = true, _class.IsOpenSound = true, _temp);

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=BaseMusic.js.map
        