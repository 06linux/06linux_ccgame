(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/resources/script/scenes/GameMain.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'e74dbDhILtKeqhxxo0vUh0r', 'GameMain', __filename);
// resources/script/scenes/GameMain.js

'use strict';

var _BaseConfig = require('../base/BaseConfig');

var _BaseMenu = require('../base/BaseMenu');

cc.Class({
    extends: cc.Component,

    properties: {},

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {

        console.log('GameMain start');
        _BaseMenu.BaseMenu.Instance().PrefabLoad(this.node, _BaseMenu.BaseMenu_List.MainMenu, function () {
            console.log('GameMain load menu success', _BaseMenu.BaseMenu_List.MainMenu);
        });
    }
}

// update (dt) {},


);

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=GameMain.js.map
        