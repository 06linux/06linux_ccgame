(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/resources/script/base/BaseAction.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '549edNqwCRMWKP16G2lA9RS', 'BaseAction', __filename);
// resources/script/base/BaseAction.js

"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

/**
 * 常用的动作，简单的封装
 */
var BaseAction = exports.BaseAction = function () {
    function BaseAction() {
        _classCallCheck(this, BaseAction);
    }

    _createClass(BaseAction, null, [{
        key: "MoveTo",


        /**
         * 移动到目标位置
         * @param {cc.Node} _node node 对象
         * @param {number} _time  时间，单位：秒
         * @param {cc.Vec2} _pos   _pos
         * @param {Function} _callFun 回调函数
         * 
         * 使用举例：
         * BaseAction.MoveTo(this.m_Npc, 0.5, cc.v2(200,200), ()=>{
                    console.log('move to succ');
               });
         */
        value: function MoveTo(_node, _time, _pos, _callFun) {
            if (_node) {
                if (_callFun) {
                    cc.tween(_node).to(_time, { position: _pos }).call(_callFun).start();
                } else {
                    cc.tween(_node).to(_time, { position: _pos }).start();
                }
            }
        }

        /**
         * 移动 (向前移动)
         * @param {cc.Node} _node 要移动的node
         * @param {number} _time    移动的时间，单位：秒
         * @param {cc.Vec2} _pos   _pos
         * @param {Function} _callFun 回调函数
         * 
         * 使用举例：
         * BaseAction.MoveBy(this.m_Npc, 0.5, cc.v2(50,50), ()=>{
                console.log('move by succ');
              });
         */


        //使用严格模式

    }, {
        key: "MoveBy",
        value: function MoveBy(_node, _time, _pos, _callFun) {

            if (_node) {
                if (_callFun) {
                    cc.tween(_node).by(_time, { position: _pos }).call(_callFun).start();
                } else {
                    cc.tween(_node).by(_time, { position: _pos }).start();
                }
            }
        }

        /**
         * 循环移动 （从当前位置到 pos 位置，AB两点位置循环移动）
         * @param {cc.Node} _node  node 对象
         * @param {number} _time   时间，单位：秒
         * @param {cc.Vec2} _pos   _pos
         * @param {Function} _callFun 回调函数
         * 
         * 备注：
         * cc.tween 中的 repeatForever 函数有bug ，所以使用 cc.action 函数实现
         * 
         * 使用举例：
         * BaseAction.MoveToLoop(this.m_Npc, 1, cc.v2(200,200), ()=>{
                console.log('move to loop succ');
            });
         */

    }, {
        key: "MoveToLoop",
        value: function MoveToLoop(_node, _time, _pos) {
            var _callFun = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : null;

            if (_node) {

                if (_callFun) {
                    var act = cc.sequence(cc.moveTo(_time / 2, _pos), cc.moveTo(_time / 2, _node.getPosition()), cc.callFunc(_callFun));
                    _node.runAction(cc.repeatForever(act));
                } else {
                    var _act = cc.sequence(cc.moveTo(_time / 2, _pos), cc.moveTo(_time / 2, _node.getPosition()));
                    _node.runAction(cc.repeatForever(_act));
                }
            }
        }

        /**
         * 循环移动, 一直向前移动， 每次位置增加 _pos 
         * @param {cc.Node} _node  node 对象
         * @param {number} _time   时间，单位：秒
         * @param {cc.Vec2} _pos   _pos
         * @param {Function} _callFun 回调函数
         * 
         * 备注：
         * cc.tween 中的 repeatForever 函数有bug ，所以使用 cc.action 函数实现
         * 
         * 使用举例：
            BaseAction.MoveByLoop(this.m_Npc, 1, cc.v2(100,100), ()=>{
                console.log('move by loop succ');
            });
         */

    }, {
        key: "MoveByLoop",
        value: function MoveByLoop(_node, _time, _pos) {
            var _callFun = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : null;

            if (_node) {

                if (_callFun) {
                    var act = cc.sequence(cc.moveBy(_time, _pos), cc.callFunc(_callFun));
                    _node.runAction(cc.repeatForever(act));
                } else {
                    var _act2 = cc.sequence(cc.moveBy(_time, _pos));
                    _node.runAction(cc.repeatForever(_act2));
                }
            }
        }

        /**
         * 缩放
         * @param {cc.Node} _node  node 对象
         * @param {number} _time   时间，单位：秒
         * @param {number} _scaleX    x 轴缩放
         * @param {number} _scaleY    x 轴缩放
         * @param {Function} _callFun 回调函数
         */

    }, {
        key: "ScaleTo",
        value: function ScaleTo(_node, _time, _scaleX, _scaleY, _callFun) {
            if (_node) {
                if (_callFun) {
                    cc.tween(_node).to(_time, { scaleX: _scaleX, scaleY: _scaleY }).call(_callFun).start();
                } else {
                    cc.tween(_node).to(_time, { scaleX: _scaleX, scaleY: _scaleY }).start();
                }
            }
        }

        /**
         * 缩放 
         * @param {cc.Node} _node  node 对象
         * @param {number} _time   时间，单位：秒
         * @param {number} _scaleX    x 轴缩放
         * @param {number} _scaleY    x 轴缩放
         * @param {Function} _callFun 回调函数
         */

    }, {
        key: "ScaleBy",
        value: function ScaleBy(_node, _time, _scaleX, _scaleY, _callFun) {
            if (_node) {
                if (_callFun) {
                    cc.tween(_node).by(_time, { scaleX: _scaleX, scaleY: _scaleY }).call(_callFun).start();
                } else {
                    cc.tween(_node).by(_time, { scaleX: _scaleX, scaleY: _scaleY }).start();
                }
            }
        }

        /**
         * 循环缩放 
         * @param {cc.Node} _node  node 对象
         * @param {number} _time   时间，单位：秒
         * @param {number} _scale1   缩放1
         * @param {number} _scale2   缩放1
         * @param {Function} _callFun 回调函数
         * 
         * 备注：
         * cc.tween 中的 repeatForever 函数有bug ，所以使用 cc.action 函数实现
         */

    }, {
        key: "ScaleLoop",
        value: function ScaleLoop(_node, _time, _scale1, _scale2) {
            var _callFun = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : null;

            if (_node) {

                if (_callFun) {
                    var act = cc.sequence(cc.scaleTo(_time / 2, _scale1), cc.scaleTo(_time / 2, _scale2), cc.callFunc(_callFun));
                    _node.runAction(cc.repeatForever(act));
                } else {
                    var _act3 = cc.sequence(cc.scaleTo(_time / 2, _scale1), cc.scaleTo(_time / 2, _scale2));
                    _node.runAction(cc.repeatForever(_act3));
                }
            }
        }

        /**
         * 旋转
         * @param {cc.Node} _node  node 对象
         * @param {number} _time   时间，单位：秒
         * @param {number} _angle  角度, [0,360], 整数微顺时针方向， 负数微逆时针方向
         * @param {Function} _callFun 回调函数
         */

    }, {
        key: "RouteTo",
        value: function RouteTo(_node, _time, _angle, _callFun) {
            if (_node) {
                if (_callFun) {
                    var act = cc.sequence(cc.rotateTo(_time, _angle), cc.callFunc(_callFun));
                    _node.runAction(act);
                } else {
                    var _act4 = cc.rotateTo(_time, _angle);
                    _node.runAction(_act4);
                }
            }
        }

        /**
         * 旋转
         * @param {cc.Node} _node  node 对象
         * @param {number} _time   时间，单位：秒
         * @param {number} _angle  角度, [0,360], 整数微顺时针方向， 负数微逆时针方向
         * @param {Function} _callFun 回调函数
         */

    }, {
        key: "RouteBy",
        value: function RouteBy(_node, _time, _angle, _callFun) {
            if (_node) {
                if (_callFun) {
                    var act = cc.sequence(cc.rotateBy(_time, _angle), cc.callFunc(_callFun));
                    _node.runAction(act);
                } else {
                    var _act5 = cc.rotateBy(_time, _angle);
                    _node.runAction(_act5);
                }
            }
        }

        /**
         * 顺时针循环旋转（转圈圈）
         * @param {cc.Node} _node  node 对象
         * @param {number} _time   时间，单位：秒
         * @param {number} _angle  角度, [0,360], 整数微顺时针方向， 负数微逆时针方向
         * @param {Function} _callFun 回调函数
         * 
         * 使用举例：
         * BaseAction.RouteLoop(this.m_Npc,1,()=>{
                    console.log(' route by success');
                });
         */

    }, {
        key: "RouteLoop",
        value: function RouteLoop(_node, _time, _callFun) {
            if (_node) {
                if (_callFun) {
                    var act = cc.sequence(cc.rotateBy(_time / 2, 180), cc.rotateBy(_time / 2, 180), cc.callFunc(_callFun));
                    _node.runAction(cc.repeatForever(act));
                } else {
                    var _act6 = cc.sequence(cc.rotateBy(_time / 2, 180), cc.rotateBy(_time / 2, 180));
                    _node.runAction(cc.repeatForever(_act6));
                }
            }
        }

        /**
         * 逆时针循环旋转（转圈圈）
         * @param {cc.Node} _node  node 对象
         * @param {number} _time   时间，单位：秒
         * @param {number} _angle  角度, [0,360], 整数微顺时针方向， 负数微逆时针方向
         * @param {Function} _callFun 回调函数
         */

    }, {
        key: "RouteLoop2",
        value: function RouteLoop2(_node, _time, _callFun) {
            if (_node) {
                if (_callFun) {
                    var act = cc.sequence(cc.rotateBy(_time / 2, -180), cc.rotateBy(_time / 2, -180), cc.callFunc(_callFun));
                    _node.runAction(cc.repeatForever(act));
                } else {
                    var _act7 = cc.sequence(cc.rotateBy(_time / 2, 180), cc.rotateBy(_time / 2, 180));
                    _node.runAction(cc.repeatForever(_act7));
                }
            }
        }

        /**
         * 等待 
         * @param {cc.Node} _node  node对象
         * @param {number} _time    时间，单位：秒
         * @param {Function} _callFun 回调函数 
         */

    }, {
        key: "Delay",
        value: function Delay(_node, _time, _callFun) {

            if (_node) {
                if (_callFun) {
                    cc.tween(_node).delay(_time).call(_callFun).start();
                } else {
                    // cc.tween(_node).delay(_time).start();
                    console.log("Error, BaseAction.Delay, _callFun is null");
                }
            }
        }
    }]);

    return BaseAction;
}();

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=BaseAction.js.map
        