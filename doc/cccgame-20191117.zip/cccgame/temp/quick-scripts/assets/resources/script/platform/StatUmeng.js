(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/resources/script/platform/StatUmeng.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'ea711TJKkBJrINzOpUdcF8Q', 'StatUmeng', __filename);
// resources/script/platform/StatUmeng.js

'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

/**
 * 友盟统计接口
 */
var StatUmeng = exports.StatUmeng = function () {

    /**
     * 初始化
     */
    function StatUmeng() {
        _classCallCheck(this, StatUmeng);
    }
    // console.log("StatUmeng constructor");


    /**
     * 返回当前实例
     */


    //使用严格模式


    _createClass(StatUmeng, null, [{
        key: 'Instance',
        value: function Instance() {
            if (this.m_Instance == null) {
                this.m_Instance = new StatUmeng();
            }
            return this.m_Instance;
        }
    }]);

    return StatUmeng;
}();

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=StatUmeng.js.map
        