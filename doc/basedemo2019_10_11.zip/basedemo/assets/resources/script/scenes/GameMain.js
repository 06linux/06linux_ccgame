
import {BaseLayer} from '../base/BaseLayer'
import {BaseConfig} from '../base/BaseConfig'
import {BasePlatform} from '../base/BasePlatform'
import { Utils, MenuManage, MenuType, DataManage, NodePoolManage } from '../base/BaseUtils'

cc.Class({
    extends: BaseLayer,

    properties: {
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start () {
        
        Utils.CCLog('GameMain start');
        MenuManage.getInstance().ShowMenu(BaseConfig.MenuRes.MainMenu);
    },

    // update (dt) {},



});
