import {BaseLayer} from '../base/BaseLayer'
import {BaseConfig} from '../base/BaseConfig'
import {BasePlatform} from '../base/BasePlatform'
import { Utils, MenuManage, MenuType, DataManage, NodePoolManage } from '../base/BaseUtils'

cc.Class({
    extends: BaseLayer,

    properties: {
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start () {

    },

    // update (dt) {},

    /**
     * 按钮点击事件
     * @param {cc.Touch} touch 
     * if (touch.target.name == 'StartGame') {
     * }
     */
    OnClick(touch) {
        //实现方法 示例
        console.log("BaseLayer click event:", touch);
        if (touch.target.name == 'Btn_Back') {
            //移除自己
            MenuManage.getInstance().RmoveMenu(BaseConfig.MenuRes.GamePlay);
            //显示主界面
            MenuManage.getInstance().ShowMenu(BaseConfig.MenuRes.MainMenu);
        }
        
    }
});
