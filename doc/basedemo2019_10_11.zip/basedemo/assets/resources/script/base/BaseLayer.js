/**
 * 基础类
 */
export class BaseLayer extends cc.Component {
    //使用严格模式
    'use strict'

    /**
     * 初始化
     */
    constructor() {
        super();
        // Utils.CCLog("BaseLayer constructor");
    }

    //     // onLoad () {},

    // start() {
    // },

    // update (dt) {},

    /**
     * 设置图片
     * @param {cc.Node} _node 
     * @param {Number} _url        //资源地址
     * @param {Number} _urlType    //资源类型 0 为本地资源 1：网络资源
     * @param {function} _callFun  //资源加载回调
     */
    SetSprite(_node, _url, _urlType = 0, _callFun = null) {

        if (!_node) {
            console.error("SetSprite node is null")
            return;
        }

        //网络资源
        if (_urlType) {
            this.LoadNetImg(_url, (texture) => {
                let spriteFrame = new cc.SpriteFrame(texture);
                var sprite = _node.getComponent(cc.Sprite);
                if (sprite) {
                    sprite.spriteFrame = spriteFrame;
                }
                else {
                    _node.addComponent(cc.Sprite).spriteFrame = spriteFrame;
                }
                if (_callFun) {
                    _callFun();
                }
            })
        }
        else { //本地资源
            this.LoadResImg(_url, (spriteFrame) => {
                var sprite = _node.getComponent(cc.Sprite);
                if (sprite) {
                    sprite.spriteFrame = spriteFrame;
                }
                else {
                    _node.addComponent(cc.Sprite).spriteFrame = spriteFrame;
                }
                if (_callFun) {
                    _callFun();
                }
            })
        }
    }

    /**
     * 加载本地图片
     * @param {Number} _url        //资源地址
     * @param {function} _callFun  //资源加载回调
     */
    LoadResImg(_resUrl, _callFun = null) {
        cc.loader.loadRes(_resUrl, cc.SpriteFrame, (err, spriteFrame) => {
            if (err) {
                console.error(err);
            }
            if (_callFun) {
                _callFun(spriteFrame);
            }
        });
    }

    /**
     * 加载网络图片
     * @param {Number} _url        //资源地址
     * @param {function} _callFun  //资源加载回调
     */
    LoadNetImg(_netUrl, _callFun = null) {

        cc.loader.load({ url: _netUrl, type: 'png' }, (err, texture) => {
            if (err) {
                console.error(err)
            }

            if (_callFun) {
                _callFun(texture);
            }
        });
    }

    /**
     * 加载预制体
     * @param {cc.Node} _parent
     * @param {string} _prefabUrl
     * @param {fun} _callFun
     * 
     */
    LoadPrefab(_parent, _prefabUrl, _customeData = null, _callFun = null) {

        if (!_parent) {
            return;
        }

        cc.loader.loadRes(_prefabUrl, cc.prefab, (err, assets) => {
            if (err) {
                console.error(err)
                return;
            }
            if (!_parent) {
                return;
            }

            let obj = cc.instantiate(assets);
            obj.getComponent(BaseLayer).Init(_customeData)

            _parent.addChild(obj);

            if (_callFun) {
                _callFun(obj);
            }
        });
    }

    /**
     * 移动一段距离
     * @param {cc.Node} _node 
     * @param {number} _time 
     * @param {number} _actTag 
     * @param {fun} _actCallFun 
     */
    ActMoveBy(_node, _time, _x, _y, _actTag = 0, _actCallFun = this.ActCallFun) {
        if (_actTag > 0) {
            var finished = cc.callFunc(_actCallFun, this, _actTag);
            var action = cc.moveBy(_time, cc.v2(_x, _y));
            action.setTag(_actTag);
            _node.runAction(cc.sequence(action, finished));
        }
        else {
            _node.runAction(cc.moveBy(_time, cc.v2(_x, _y)));
        }
    }

    /**
     * 移动到指定位置
     * @param {cc.Node} _node 
     * @param {number} _time 
     * @param {number} _actTag 
     * @param {fun} _actCallFun 
     */
    ActMoveTo(_node, _time, _x, _y, _actTag = 0, _actCallFun = this.ActCallFun) {
        if (_actTag > 0) {
            var finished = cc.callFunc(_actCallFun, this, _actTag);
            var action = cc.moveTo(_time, cc.v2(_x, _y));
            action.setTag(_actTag);
            _node.runAction(cc.sequence(action, finished));
        }
        else {
            _node.runAction(cc.moveTo(_time, cc.v2(_x, _y)));
        }
    }

    /**
     * 等待一段时间
     * @param {cc.Node} _node 
     * @param {number} _time 
     * @param {number} _actTag 
     * @param {fun} _actCallFun 
     */
    ActDelayTime(_node, _time, _actTag = 0, _actCallFun = this.ActCallFun) {
        if (_actTag > 0) {
            var finished = cc.callFunc(_actCallFun, this, _actTag);
            var action = cc.delayTime(_time);
            action.setTag(_actTag);
            _node.runAction(cc.sequence(action, finished));
        }
        else {
            _node.runAction(cc.delayTime(_time));
        }
    }

    /**
     * 动作回调函数
     * @param {cc.Node} _node 
     * @param {number} _actTag 
     */
    ActCallFun(_node, _actTag) {
        //子类实现
    }

    /**
     * 播放anim动画
     */
    PlayAnimtion(_node, _animName = null, _onPlayCallFun = null, _onStopCallFun = null, _onPauseCallFun = null, _onResumeCallFun = null, _onLastframeCallFun = null, _onFinishedCallFun = null) {
        let animationcompoent = _node.getComponent(cc.Animation);
        if (animationcompoent) {
            if (_animName) {
                animationcompoent.play(_animName);
            }
            else {
                animationcompoent.play();
            }
            //播放事件
            if (_onPlayCallFun) { animationcompoent.on('play', _onPlayCallFun, this); }
            //最后一帧事件
            if (_onLastframeCallFun) { animationcompoent.on('lastframe', _onLastframeCallFun, this); }
            //播放成功事件
            if (_onFinishedCallFun) { animationcompoent.on('finished', _onFinishedCallFun, this); }
            //播放暂停事件
            if (_onPauseCallFun) { animationcompoent.on('pause', _onPauseCallFun, this); }
            //播放恢复事件
            if (_onResumeCallFun) { animationcompoent.on('resume', _onResumeCallFun, this); }
        }
        else {
            console.log("PlayAnimtion nodename:" + _node.name + 'PlayAnimtion not Animation');
        }
    }


    /**
     * 界面初始化
     * @param {Object} _customeData
     *  
     */
    Init(_customeData) {
        // console.log("BaseLayer Init customeData:", _customeData);
    }

    /**
     * 界面释放
     * @param {Object} _customeData 
     * 
     */
    Free(_customeData) {
        // console.log("BaseLayer Free customeData:", _customeData);
    }

    /**
     * 按钮点击事件
     * @param {cc.Touch} touch 
     * if (touch.target.name == 'StartGame') {
     * }
     */
    OnClick(touch) {
        //实现方法 示例
        // console.log("BaseLayer click event:", touch);
    }

    /**
     * 复选按钮回调
     * @param {cc.Touch} toggle 
     * if (toggle.node.name == 'StartGame') {
     * }
     */
    OnToggle(toggle) {
    }

}

