## 项目概要
项目名称： xxxx

引擎环境: cocos creator 2.1.3

仓库地址: 
    git clone ssh://git@192.168.1.10/GitHome/zjkj/xxxx

域名地址: zhijianfengleigame.com

立项时间: xxxx

开发人员:
	程序 xxx
	策划 xxx
	美术 xxx

分支版本： 微信小游戏平台工程
分支状态： 开发中

开发微信号：
微信appid：

统计sdk：
    阿拉丁：

备注信息：
    测试推广路径:
    测试wxappid: wx4f585094799e2ce4 六角萌萌消
    测试域名: zhijianfengleigame.com
    插屏广告: adunit-a3c388a689286227
    banner: adunit-5b75f5566c6d3990
    视频广告: adunit-5b75f5566c6d3990

## 开发日志

注意事项
    1:需要解决移动抖动的问题
    <!-- 2:地图创建可有优化，减少节点数量 -->

2019-09-26
	<1> 基础场景搭建

2019-09-27
    <1> 关卡配置
	<2> 加载关卡地图
	<3> 生成关卡地图


