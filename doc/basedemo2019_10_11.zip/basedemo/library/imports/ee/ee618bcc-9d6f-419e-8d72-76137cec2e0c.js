"use strict";
cc._RF.push(module, 'ee618vMnW9Bno1ydhN87C4M', 'BaseConfig');
// resources/script/base/BaseConfig.js

"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _class, _temp;

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

/**
*
*                 _oo0oo_
                 o8888888o
                 88" . "88
                 (| -_- |)
                 0\  =  /0
               ___/`—'\___
             .' \\|     |— '.
            / \\|||  :  |||— \
           / _||||| -:- |||||- \
          |   | \\\  -  —/ |   |
          | \_|  ''\—/''  |_/ |
          \  .-\__  '-'  ___/-. /
        ___'. .'  /—.—\  `. .'___
     ."" '<  `.___\_<|>_/___.' >' "".
    | | :  `- \`.;`\ _ /`;.`/ - ` : | |
    \  \ `_.   \_ __\ /__ _/   .-` /  /
=====`-.____`.___ \_____/___.-`___.-'=====
                  `=—='

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

             佛祖保佑    永无BUG
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
*
**/
var BaseConfig = exports.BaseConfig = (_temp = _class = function BaseConfig() {
  _classCallCheck(this, BaseConfig);
}, _class.IsLoading = false, _class.Debug = false, _class.Global = {
  // NetRoot: "https://beikecafe.com",
  NetRoot: "https://zhijianfengleigame.com",
  // NetRoot: "http://101.37.33.113/",
  NetRes: "/h5/wx_fkn/res_1001/",

  BoxMenuNetRes: "/zjkj_boxmenu/",
  BoxMenuVersion: "zy_game_ml/res_tcsdjz_1002/",

  TgSDK_ServerUrl: '/zjserver/tgsdk/tgsdk/protocol/', //统计请求网址

  Game_Is_Review: true, //审核开关

  Game_Main_TgBar: false, //主界面显示tgbar
  Game_Main_TgDialog: false, //主界面显示右边tgbar
  Game_Main_RightTopBar: false, //主界面显示右上角推广
  Game_Main_TgLeftBar: false, //主界面显示左边tgbar

  Game_SigIn_Video: false, //签到界面视频
  Game_SigIn_TgBar: false, //签到界面显示tgbar
  Game_SigIn_TgLeftBar: false, //签到界面显示左边tgbar
  Game_SigIn_TgRightBar: false, //签到界面显示右边tgbar

  Game_TurnTable_TgBar: false, //转盘界面显示tgbar
  Game_TurnTable_TgLeftBar: false, //转盘界面显示左边tgbar
  Game_TurnTable_TgRightBar: false, //转盘界面显示右边tgbar

  Game_Rank_TgRightBar: false, //排行界面显示tgbar

  Game_SkinShop_TgRightBar: false, //皮肤商城界面显示tgbar

  Game_ScoreTask_Video: false, //分数任务界面视频

  Game_Result_TgBar: false, //结算界面显示tgbar
  Game_Result_TgLeftBar: false, //结算界面显示左边tgbar
  Game_Result_TgRightBar: false, //结算界面显示右边tgbar

  Game_Bind_App_List: [], //绑定游戏列表
  Game_Query: {},
  Game_Name: "贪吃蛇大激战"

  /**
  * 微信 平台信息
  */
}, _class.WeChatGlobal = {
  WxAppId: "wx4f585094799e2ce4", //
  WxAppType: "zy",

  BannerAdUnitId: "adunit-5b75f5566c6d3990", //baner 广告id adunit-
  RewardedVideoAdUnitId: "adunit-5b75f5566c6d3990", //视频激励广告id adunit-
  InterstitialAdUnitId: "adunit-a3c388a689286227" //插屏广告id  adunit-
  // interstitialAd


  /**
   * wx分包名字
   */
}, _class.WxSubPackageName = 'subpackage', _class.GlobalJson = {
  Game_Level_Json: "game_level.json",
  Game_Skin_Json: "game_skin.json",

  Game_Global_Json: "m1001_global.json",
  Game_TgBar_Json: "m1001_tgbar.json",
  Game_Left_RightBar_Json: "m1001_left_right.json"

  /**
   * 本地音乐资源
   * 文件目录 music
   */
}, _class.GameResMusics = {
  Music_Bg1: "music_play_1",

  Sound_Touch: "sound_touch",
  Sound_Dead: "sound_dead",
  Sound_Eat: "sound_eat"

  /**
   * 分享语
   */
}, _class.ShareTextData = {
  ShareText1: "震惊，世界上最长的蛇竟然是…",
  ShareText2: "贪吃蛇经典玩法升级，不来看看？",
  ShareText3: "开局一条鲲，变长全靠吞…",
  ShareText4: "我就是我，是颜色不一样的大蛇！",
  ShareText5: "不想当女娲的贪吃蛇不是好蛇蛇！"

  /**
   * 分享图片
   * 
   */
}, _class.ShareImgData = {
  ShareImg1: "wx_share_img_1.png",
  ShareImg2: "wx_share_img_2.png",
  ShareImg3: "wx_share_img_3.png"

  /**
   * 界面预制体
   */
}, _class.MenuRes = {
  LoadingMenu: 'script/menus/LoadingMenu',
  GamePlay: 'script/gameplay/GamePlay',
  MainMenu: 'script/menus/MainMenu',
  ResultMenu: 'script/menus/ResultMenu',
  FaildMenu: 'script/menus/FaildMenu'

  //tg预制体
  // TgBarMenu: 'script/menus/TgBarMenu',
  // TgLeftMenu: 'script/menus/TgLeftMenu',
  // TgRightMenu: 'script/menus/TgRightMenu',
  // TgRightTopMenu: 'script/menus/TgRightTopMenu',


  /**
   * 场景名
   */
}, _class.SceneRes = {
  GameMain: "GameMain"

  /**
   * 对象池
   */
}, _class.NodePoolKey = {
  Npc: 'cccnpc'

  /**
   * 角色数据key
   * 通过key 来读取存档
   * cccsnak20190614
   */
}, _class.UserDataKey = "snaketest20190919", _class.UserUUIDKey = "cccuuid2019062700", _class.UserUUID = "", _class.UserData = {

  // UserUUID:"",                     //用户uuid
  Name: "游客", //用户名字
  UserHandIcon: "", //用户头像地址
  Gold: 0, //金币

  CurLevel: 1, //当前关卡数

  SkinId: 1, //当前皮肤
  SkinBig: [], //皮肤背包

  Teaching: false //教学标记


  /**------------------------------------------------------------------------------------------------------------- 
   ****************************************开放域数据*************************************************************
  ----------------------------------------------------------------------------------------------------------------/
  
  /**
   * 向开放域发送的消息类型
   * 需要在开放域里处理对应逻辑
   */
}, _class.OpenDataMessageType = {
  GetCloudStorage: 'getcloudstorage',
  ShowEndlessRank: 'showendlessrank',
  ShowLimitTimeRank: 'showLimittimerank',
  ShowGoodTimeRank: 'showgoodtimerank'

  /**
   * 向开放域发送的消息数据格式
   * 需要在开放域里读取对应数据
   */
}, _class.OpenDataMessageData = {
  MessageType: '',
  KVDataList: [],
  Data: '',
  DataKey: ''

  /**
   * 限时模式数据key值
   */
}, _class.LimitTimeCloudDataKey = 'limittimedata', _class.EndlessCloudDataKey = 'endlessdata', _class.GoodTimeCloudDataKey = 'goodtimedata', _class.CloudData = {
  UUID: '',
  Score: 0,
  UpdateTime: 0
}, _temp);

cc._RF.pop();