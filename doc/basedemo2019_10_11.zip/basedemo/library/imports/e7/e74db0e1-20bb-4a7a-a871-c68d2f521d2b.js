"use strict";
cc._RF.push(module, 'e74dbDhILtKeqhxxo0vUh0r', 'GameMain');
// resources/script/scenes/GameMain.js

'use strict';

var _BaseLayer = require('../base/BaseLayer');

var _BaseConfig = require('../base/BaseConfig');

var _BasePlatform = require('../base/BasePlatform');

var _BaseUtils = require('../base/BaseUtils');

cc.Class({
    extends: _BaseLayer.BaseLayer,

    properties: {},

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {

        _BaseUtils.Utils.CCLog('GameMain start');
        _BaseUtils.MenuManage.getInstance().ShowMenu(_BaseConfig.BaseConfig.MenuRes.MainMenu);
    }
}

// update (dt) {},


);

cc._RF.pop();