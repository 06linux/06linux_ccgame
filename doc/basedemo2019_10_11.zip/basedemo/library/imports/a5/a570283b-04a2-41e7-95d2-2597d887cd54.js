"use strict";
cc._RF.push(module, 'a5702g7BKJB55XSJZfYh81U', 'GamePlay');
// resources/script/gameplay/GamePlay.js

'use strict';

var _BaseLayer = require('../base/BaseLayer');

var _BaseConfig = require('../base/BaseConfig');

var _BasePlatform = require('../base/BasePlatform');

var _BaseUtils = require('../base/BaseUtils');

cc.Class({
    extends: _BaseLayer.BaseLayer,

    properties: {},

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {},


    // update (dt) {},

    /**
     * 按钮点击事件
     * @param {cc.Touch} touch 
     * if (touch.target.name == 'StartGame') {
     * }
     */
    OnClick: function OnClick(touch) {
        //实现方法 示例
        console.log("BaseLayer click event:", touch);
        if (touch.target.name == 'Btn_Back') {
            //移除自己
            _BaseUtils.MenuManage.getInstance().RmoveMenu(_BaseConfig.BaseConfig.MenuRes.GamePlay);
            //显示主界面
            _BaseUtils.MenuManage.getInstance().ShowMenu(_BaseConfig.BaseConfig.MenuRes.MainMenu);
        }
    }
});

cc._RF.pop();