"use strict";
cc._RF.push(module, '532c83BQrRIrLmedllYqH//', 'MainMenu');
// resources/script/menus/MainMenu.js

'use strict';

var _BaseLayer = require('../base/BaseLayer');

var _BaseConfig = require('../base/BaseConfig');

var _BasePlatform = require('../base/BasePlatform');

var _BaseUtils = require('../base/BaseUtils');

cc.Class({
    extends: _BaseLayer.BaseLayer,

    properties: {},

    // LIFE-CYCLE CALLBACKS:

    onLoad: function onLoad() {
        this.node.on(cc.Node.EventType.TOUCH_START, this.TouchesBegin, this);
        this.node.on(cc.Node.EventType.TOUCH_MOVE, this.TouchesMoved, this);
        this.node.on(cc.Node.EventType.TOUCH_END, this.TouchesEnded, this);
        this.node.on(cc.Node.EventType.TOUCH_CANCEL, this.TouchesCancel, this);
    },
    start: function start() {},


    // update (dt) {},

    /**
     * 按钮点击事件
     * @param {cc.Touch} touch 
     * if (touch.target.name == 'StartGame') {
     * }
     */
    OnClick: function OnClick(touch) {
        //实现方法 示例
        console.log("BaseLayer click event:", touch);
        if (touch.target.name == 'Btn_Start') {
            //移除自己
            _BaseUtils.MenuManage.getInstance().RmoveMenu(_BaseConfig.BaseConfig.MenuRes.MainMenu);
            //显示游戏界面
            _BaseUtils.MenuManage.getInstance().ShowMenu(_BaseConfig.BaseConfig.MenuRes.GamePlay);
        } else if (touch.target.name == 'Btn_Share') {
            _BasePlatform.BasePlatform.getInstance().InitShare();
            _BasePlatform.BasePlatform.getInstance().ShareMessage();
        } else if (touch.target.name == 'Btn_InitBannerAd') {
            _BasePlatform.BasePlatform.getInstance().InitBannerAd();
        } else if (touch.target.name == 'Btn_ShowBannerAd') {
            _BasePlatform.BasePlatform.getInstance().ShowBannerAd();
        } else if (touch.target.name == 'Btn_HideBannerAd') {
            _BasePlatform.BasePlatform.getInstance().HideBannerAd();
        }
    },


    /**
     * 触摸按下
     * @param {cc.touch} touch 
     */
    TouchesBegin: function TouchesBegin(touch) {},


    /**
     * 触摸移动
     * @param {cc.touch} touch
     */
    TouchesMoved: function TouchesMoved(touch) {},


    /**
     * 触摸抬起
     * @param {cc.touch} touch 
     */
    TouchesEnded: function TouchesEnded(touch) {
        _BaseUtils.Utils.CCLogGroupEnd();
    },


    /**
     * 触摸取消
     * @param {cc.touch} touch 
     */
    TouchesCancel: function TouchesCancel(touch) {}
});

cc._RF.pop();