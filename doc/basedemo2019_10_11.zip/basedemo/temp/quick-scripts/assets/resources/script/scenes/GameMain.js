(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/resources/script/scenes/GameMain.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'e74dbDhILtKeqhxxo0vUh0r', 'GameMain', __filename);
// resources/script/scenes/GameMain.js

'use strict';

var _BaseLayer = require('../base/BaseLayer');

var _BaseConfig = require('../base/BaseConfig');

var _BasePlatform = require('../base/BasePlatform');

var _BaseUtils = require('../base/BaseUtils');

cc.Class({
    extends: _BaseLayer.BaseLayer,

    properties: {},

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {

        _BaseUtils.Utils.CCLog('GameMain start');
        _BaseUtils.MenuManage.getInstance().ShowMenu(_BaseConfig.BaseConfig.MenuRes.MainMenu);
    }
}

// update (dt) {},


);

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=GameMain.js.map
        