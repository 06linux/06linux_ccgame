(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/resources/script/base/BasePlatform.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'cdefaP4GkNAEb8HUhdzaII9', 'BasePlatform', __filename);
// resources/script/base/BasePlatform.js

'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.BasePlatform = exports.AldServer = exports.StatisticsServer = exports.NativeIos = exports.NativeAndrid = exports.WeChat = exports.PlatformType = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _BaseLayer = require('./BaseLayer');

var _BaseConfig = require('./BaseConfig');

var _BaseUtils = require('../base/BaseUtils');

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

/**
 * 平台类型
 *  Zjkj_Default: 10000,   默认平台
 *  Zjkj_WECHAT: 10001,    微信平台
 *  Zjkj_QQ: 10002,        手机qq平台
    Zjkj_OPPO: 10003,      OPPO平台
    Zjkj_VIVO: 10004,      VIVO平台
    Zjkj_UC: 10005,        UC平台
    Zjkj_Android_233: 10006,   APK 233平台
    Zjkj_Android_MOBGI: 10007, APK 乐逗平台
 */
var PlatformType = exports.PlatformType = {
    Zjkj_Default: 10000,
    Zjkj_WECHAT: 10001,
    Zjkj_QQ: 10002,
    Zjkj_OPPO: 10003,
    Zjkj_VIVO: 10004,
    Zjkj_UC: 10005,
    Zjkj_Android_233: 10006,
    Zjkj_Android_MOBGI: 10007
    // Zjkj_APK_FREE: 10010,


    /**
     * 微信平台
     */
};
var WeChat = exports.WeChat = function () {

    /**
     * 初始化
     */
    function WeChat() {
        _classCallCheck(this, WeChat);

        console.log("TgSDKServer constructor");
    }

    /**
     * 监听微信的显示函数
     */


    //使用严格模式


    _createClass(WeChat, [{
        key: 'OnShow',
        value: function OnShow() {

            wx.onShow(function (res) {
                //配置详情页
                _BaseUtils.Utils.CCLog(" wx.onShow res", res);
                _BaseConfig.BaseConfig.Global.Game_Query = res.query;
            });
        }

        /**
         * 监听微信的隐藏函数
         */

    }, {
        key: 'OnHide',
        value: function OnHide() {

            wx.onHide(function (res) {
                console.log('weixin onhide res', res);
            });
        }

        /**
         * 获取设备信息同步接口
         */

    }, {
        key: 'GetSystemInfoSync',
        value: function GetSystemInfoSync() {
            return wx.getSystemInfoSync();
        }

        /**
         * 获取菜单按钮（右上角胶囊按钮）的布局位置信息。坐标信息以屏幕左上角为原点。
         */

    }, {
        key: 'GetMenuButtonBoundingClientRect',
        value: function GetMenuButtonBoundingClientRect() {
            return wx.getMenuButtonBoundingClientRect();
        }

        /**
         * 加载分包
         */

    }, {
        key: 'LoadSubpackage',
        value: function LoadSubpackage(_subPackageName, _callFun) {
            //加载子包
            cc.loader.downloader.loadSubpackage(_subPackageName, function (err) {
                if (err) {
                    return console.error(err);
                }
                _BaseUtils.Utils.CCLog('load subpackage successfully.');
                _callFun(err);
            });
        }

        /**
         * 在用户授权的情况下获取用户信息
         * @param {function} _onSuccess    成功返回函数
         * @param {function} _onFail       失败返回函数
         */

    }, {
        key: 'GetUserInfo',
        value: function GetUserInfo(_onSuccess, _onFail) {

            wx.getUserInfo({
                success: function success(res) {
                    _onSuccess(res.userInfo);
                },
                fail: function fail(err) {
                    _onFail(err);
                }
            });
        }

        /**
         * 请求授权接口
         * @param {function} _onSuccess    成功返回函数
         * @param {function} _onFail       失败返回函数
         */

    }, {
        key: 'Authorize',
        value: function Authorize(_onSuccess, _onFail) {
            // 可以通过 qq.getSetting 先查询一下用户是否授权了 "scope.userInfo" 这个 scope
            wx.getSetting({
                success: function success(res) {
                    // Utils.CCLog("qq.getSetting success res.authSetting", res.authSetting);
                    if (res.authSetting['scope.userInfo']) {
                        _onSuccess();
                    } else {
                        _onFail();
                    }
                },
                fail: function fail(err) {
                    _onFail(err);
                }
            });
        }

        /**
         * 创建授权按钮
         * @param {function} _onSuccess    成功返回函数
         * @param {function} _onFail       失败返回函数
         */

    }, {
        key: 'CreateUserInfoButton',
        value: function CreateUserInfoButton(_onSuccess, _onFail) {

            cc.loader.loadRes("data/img_authorize/game_btn_authorize.png", function (err, texture) {
                if (err) {
                    _onFail("授权按钮创建失败");
                    return;
                }
                //设计宽
                var viewwidth = cc.visibleRect.width;
                //设计高
                var viewheight = cc.visibleRect.height;
                //实际视图
                var size = cc.view.getFrameSize();

                var width = texture.width / (viewwidth / cc.view.getFrameSize().width);
                var height = texture.height / (viewheight / cc.view.getFrameSize().height);

                var button = wx.createUserInfoButton({
                    type: 'image',
                    image: texture.url,
                    style: {
                        left: cc.view.getFrameSize().width / 2 - width / 2,
                        top: cc.view.getFrameSize().height / 2,
                        width: width,
                        height: height
                    }
                });

                button.show();
                button.onTap(function (res) {
                    _BaseUtils.Utils.CCLog(res);
                    button.destroy();
                    if (res.userInfo) {
                        _onSuccess(res.userInfo);
                    } else {
                        _onFail("拒绝授权");
                    }
                });
            });
        }

        /**
         * 微信分享转发监听
         */

    }, {
        key: 'InitWxShare',
        value: function InitWxShare() {

            //显示当前转发按钮
            wx.showShareMenu({
                withShareTicket: true,
                success: function success() {
                    // Utils.CCLog("wei xin showShareMenu success....");
                },
                fail: function fail() {
                    // Utils.CCLog("wei xin showShareMenu fail....");
                },
                complete: function complete() {
                    // Utils.CCLog("wei xin showShareMenu complete....");
                }
            });

            //被动转发的设置
            wx.onShareAppMessage(function () {
                return {
                    title: _BaseConfig.BaseConfig.ShareTextData.ShareText2,
                    imageUrl: _BaseConfig.BaseConfig.Global.NetRoot + _BaseConfig.BaseConfig.Global.NetRes + 'wx_share/' + _BaseConfig.BaseConfig.ShareImgData.ShareImg1 // 图片 URL
                };
            });
        }

        /**
         * 分享 
         * @param {string} _title
         * @param {string} _imageUrl
         * 
         */

    }, {
        key: 'ShareAppMessage',
        value: function ShareAppMessage(_title, _imageUrl) {

            wx.shareAppMessage({
                title: _title,
                // imageUrlId: '转发标题',
                imageUrl: _imageUrl // 图片 URL
            });
        }

        /**
         *  截图功能
         * 
         *  @param {number} x 	 	0 	否 	截取 canvas 的左上角横坐标
         *  @param {number} y 	 	0 	否 	截取 canvas 的左上角纵坐标
         *  @param {number} width 	 	canvas 的宽度 	否 	截取 canvas 的宽度
         *  @param {number} height 	 	canvas 的高度 	否 	截取 canvas 的高度
         *  @param {number} destWidth 	canvas 的宽度 	否 	目标文件的宽度，会将截取的部分拉伸或压缩至该数值
         *  @param {number} destHeight  canvas 的高度 	否 	目标文件的高度，会将截取的部分拉伸或压缩至该数值
         *  @param {string} fileType 	png 	否 	目标文件的类型
         *  @param {number} quality 	1.0 	否 	jpg图片的质量，仅当 fileType 为 jpg 时有效。取值范围为 0.0（最低）- 1.0（最高），不含 0。不在范围内时当作 1.0
         */

    }, {
        key: 'RenderTexture',
        value: function RenderTexture() {
            var _x = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 0;

            var _y = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;

            var _width = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 200;

            var _height = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : 150;

            var _destWidth = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : 500;

            var _destHeight = arguments.length > 5 && arguments[5] !== undefined ? arguments[5] : 400;

            var _fileType = arguments.length > 6 && arguments[6] !== undefined ? arguments[6] : "png";

            var _quality = arguments.length > 7 && arguments[7] !== undefined ? arguments[7] : 1.0;

            // Utils.CCLog("_x", _x, "_y", _y, "_width", _width, "_height", _height, "_destWidth", _destWidth, "_destHeight", _destHeight);
            var tempFilePath = canvas.toTempFilePathSync({
                x: _x,
                y: _y,
                width: _width,
                height: _height,
                destWidth: _destWidth,
                destHeight: _destHeight,
                fileType: _fileType,
                quality: _quality
            });
            return tempFilePath;
        }

        /**
         * 加快触发 JavaScriptCore 垃圾回收（Garbage Collection）
         * GC 时机是由 JavaScriptCore 来控制的，并不能保证调用后马上触发 GC。
         * wx.triggerGC()
         */

    }, {
        key: 'TriggerGC',
        value: function TriggerGC() {
            wx.triggerGC();
        }

        /**
         * 向子域发送消息
         * @param {BaseConfig.OpenDataMessageData} _messagedata
         */

    }, {
        key: 'OpenDataContextPostMessage',
        value: function OpenDataContextPostMessage(_messagedata) {
            wx.getOpenDataContext().postMessage(_messagedata);
        }

        /**
         * 对用户托管数据进行写数据操作。允许同时写多组 KV 数据
         * @param {JSON} _kvDataList
         */

    }, {
        key: 'UploadUserCloudData',
        value: function UploadUserCloudData(_kvDataList) {

            var userdata = {
                KVDataList: _kvDataList,
                success: function success(res) {
                    _BaseUtils.Utils.CCLog("success：res", res);
                },
                fail: function fail(res) {
                    _BaseUtils.Utils.CCLog("fail：res", res);
                },
                complete: function complete(res) {
                    _BaseUtils.Utils.CCLog("complete：res", res);
                }
            };

            wx.setUserCloudStorage(userdata);
        }

        /**
         * 创建一个banner广告
         * @param {string} _adUnitId
         * @param {number} _left
         * @param {number} _top
         * @param {number} _width
         * @param {number} _height
         * 
         * 
         */

    }, {
        key: 'CreateBannerAd',
        value: function CreateBannerAd(_adUnitId, _left, _top, _width, _height) {
            var _this = this;

            if (this.m_BannerADUnitId == _adUnitId) {
                return;
            }

            this.m_BannerADUnitId = _adUnitId;

            if (this.m_BannerAD) {
                this.m_BannerAD.destroy();
            }

            this.m_BannerAD = wx.createBannerAd({
                adUnitId: _adUnitId,
                style: {
                    left: _left,
                    top: _top,
                    width: _width,
                    height: _height
                }
            });

            this.m_BannerAD.onLoad(function () {
                _BaseUtils.Utils.CCLog('banner 广告加载成功');
            });

            this.m_BannerAD.onError(function (err) {
                _BaseUtils.Utils.CCLog(err);
            });

            this.m_BannerAD.onResize(function (res) {
                // BaseConfig.Global.BannerHeight = res.height;
                // Uitls.ZjKjServer.ResizeTgBar();
                // Utils.CCLog("WeChat.getInstance().GetSystemInfoSync().screenHeight - res.height", WeChat.getInstance().GetSystemInfoSync().screenHeight, "res.height", res.height)

                // this.m_BannerAD.style.width = res.width;
                // this.m_BannerAD.style.height = res.height;
                _this.m_BannerWidth = res.width;
                _this.m_BannerHeight = res.height;

                _this.m_BannerAD.style.top = _this.GetSystemInfoSync().screenHeight - res.height;

                // Utils.CCLog(res.width, res.height)
                // Utils.CCLog(this.m_BannerAD.style.realWidth, this.m_BannerAD.style.realHeight)
            });
        }

        /**
         * 显示广告
         * 
         */

    }, {
        key: 'ShowBannerAd',
        value: function ShowBannerAd() {

            if (this.m_BannerAD) {
                this.m_BannerAD.show().catch(function (err) {
                    return _BaseUtils.Utils.CCLog(err);
                });
            }
        }

        /**
         * 隐藏广告
         * 
         */

    }, {
        key: 'HideBannerAd',
        value: function HideBannerAd() {
            if (this.m_BannerAD) {
                this.m_BannerAD.hide().catch(function (err) {
                    return _BaseUtils.Utils.CCLog(err);
                });
            }
        }

        /**
         * 创建视频广告
         * @param {string} _adUnitId
         * @param {function} _onSuccess    成功返回函数
         * @param {function} _onFail       失败返回函数
         */

    }, {
        key: 'CreateRewardedVideoAd',
        value: function CreateRewardedVideoAd(_adUnitId, _onSuccess, _onFail) {

            if (this.m_RewardedVideoAdUnitId == _adUnitId) {
                return;
            }

            if (this.m_RewardedVideoAd) {
                this.m_RewardedVideoAd.destroy();
            }

            this.m_RewardedVideoAdUnitId = _adUnitId;
            this.m_RewardedVideoAd = wx.createRewardedVideoAd({
                adUnitId: _adUnitId
            });

            this.m_RewardedVideoAd.onLoad(function () {
                _BaseUtils.Utils.CCLog('激励视频 广告加载成功');
                _onSuccess();
            });

            this.m_RewardedVideoAd.onError(function (err) {
                _BaseUtils.Utils.CCLog("m_RewardedVideoAd onError", err);
                _onFail(err);
                //没有适合的广告
                // if (err.errCode == 1004) {
                // }
            });
        }

        /**
         * 显示视频广告
         * @param {function} _onSuccess    成功返回函数
         * @param {function} _onFail       失败返回函数
         */

    }, {
        key: 'ShowRewardedVideoAd',
        value: function ShowRewardedVideoAd(_onSuccess, _onFail) {
            var _this2 = this;

            if (!this.m_RewardedVideoAd) {
                _onFail("this.m_RewardedVideoAd is null");
                return;
            }

            //广告显示
            this.m_RewardedVideoAd.show().then(function () {
                // Utils.CCLog("m_RewardedVideoAd.show()",res)
            }).catch(function (err) {
                _BaseUtils.Utils.CCLog("m_RewardedVideoAd.show()", err);
                _this2.m_RewardedVideoAd.load().then(function () {
                    return _this2.m_RewardedVideoAd.show();
                }).catch(function (err) {
                    _onFail(err);
                    _BaseUtils.Utils.CCLog('激励视频 广告显示失败');
                });
            });

            if (this.onCloseCallFun) {
                _BaseUtils.Utils.CCLog("注销 监听");
                this.m_RewardedVideoAd.offClose(this.onCloseCallFun);
            }
            //广告关闭监听
            this.m_RewardedVideoAd.onClose(this.onCloseCallFun = function (res) {

                // 用户点击了【关闭广告】按钮
                // 小于 2.1.0 的基础库版本，res 是一个 undefined
                if (res && res.isEnded || res === undefined) {
                    // 正常播放结束，可以下发游戏奖励
                    _onSuccess();
                } else {
                    // 播放中途退出，不下发游戏奖励
                    _onFail();
                }
            });
        }

        /**
         * 创建插屏广告
         * @param {string} _adUnitId
         * @param {function} _onSuccess    成功返回函数
         * @param {function} _onFail       失败返回函数
         */

    }, {
        key: 'CreateInterstitialAd',
        value: function CreateInterstitialAd(_adUnitId, _onSuccess, _onFail) {

            if (this.m_InterstitialAdUnitId == _adUnitId) {
                return;
            }

            if (this.m_InterstitialAd) {
                this.m_InterstitialAd.destroy();
            }

            this.m_InterstitialAdUnitId = _adUnitId;
            this.m_InterstitialAd = wx.createInterstitialAd({
                adUnitId: _adUnitId
            });

            this.m_InterstitialAd.onLoad(function () {
                _BaseUtils.Utils.CCLog('插屏 广告加载成功');
                _onSuccess();
            });

            this.m_InterstitialAd.onError(function (err) {
                _BaseUtils.Utils.CCLog("m_InterstitialAd onError", err);
                _onFail(err);
                //没有适合的广告
                // if (err.errCode == 1004) {
                // }
            });
        }

        /**
         * 显示插屏广告
         * @param {function} _onSuccess    成功返回函数
         * @param {function} _onFail       失败返回函数
         */

    }, {
        key: 'ShowInterstitialAd',
        value: function ShowInterstitialAd(_onSuccess, _onFail) {
            var _this3 = this;

            if (!this.m_InterstitialAd) {
                _onFail("this.m_InterstitialAd is null");
                return;
            }

            //广告显示
            this.m_InterstitialAd.show().then(function () {
                // Utils.CCLog("m_RewardedVideoAd.show()",res)
            }).catch(function (err) {
                _BaseUtils.Utils.CCLog("m_RewardedVideoAd.show()", err);
                _this3.m_InterstitialAd.load().then(function () {
                    return _this3.m_InterstitialAd.show();
                }).catch(function (err) {
                    _onFail(err);
                    _BaseUtils.Utils.CCLog('插屏 广告显示失败');
                });
            });

            if (this.onInterstitiaCloseCallFun) {
                _BaseUtils.Utils.CCLog("注销 监听");
                this.m_InterstitialAd.offClose(this.onInterstitiaCloseCallFun);
            }
            //广告关闭监听
            this.m_InterstitialAd.onClose(this.onInterstitiaCloseCallFun = function (res) {

                _BaseUtils.Utils.CCLog('插屏 广告关闭');
                _onSuccess();
            });
        }

        /**
         * 分享 
         * @param {string} _imageUrl
         */

    }, {
        key: 'PreviewImage',
        value: function PreviewImage(_imageUrl) {

            return new Promise(function (resolve, reject) {
                wx.previewImage({
                    urls: [_imageUrl],
                    success: function success() {
                        _BaseUtils.Utils.CCLog("wei xin previewImage success....");
                        resolve("success");
                    },
                    fail: function fail() {
                        reject("fail");
                    }
                });
            });
        }

        /**
         * 跳转到其他小游戏
         * 小游戏的appid一定要在game.json 的配置列表里
         * @param {string} _appid
         * @param {string} _path
         * @param {string} _extData
         * @param {string} _envVersion
         * @param {function} _onSuccess    成功返回函数
         * @param {function} _onFail       失败返回函数
         */

    }, {
        key: 'JumpToMiniProgram',
        value: function JumpToMiniProgram(_appid, _path) {
            var _extData = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : "";

            var _envVersion = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : 'release';

            var _onSuccess = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : null;

            var _onFail = arguments.length > 5 && arguments[5] !== undefined ? arguments[5] : null;

            wx.navigateToMiniProgram({
                appId: _appid,
                path: _path,
                extraData: _extData,
                envVersion: _envVersion,
                success: function success(data) {
                    _BaseUtils.Utils.CCLog("navigateToMiniProgram success", data);
                    if (_onSuccess) {
                        _onSuccess();
                    }
                },
                fail: function fail(err) {
                    _BaseUtils.Utils.CCLog("navigateToMiniProgram fail", err);

                    if (_onFail) {
                        _onFail();
                    }
                }
            });
        }

        /**
         * 返回当前实例
         */

    }], [{
        key: 'getInstance',
        value: function getInstance() {
            if (this.m_Instance == null) {
                this.m_Instance = new WeChat();
            }
            return this.m_Instance;
        }
    }]);

    return WeChat;
}();

/**
 * 本地安卓
 */


var NativeAndrid = exports.NativeAndrid = function () {

    /**
     * 初始化
     */
    function NativeAndrid() {
        _classCallCheck(this, NativeAndrid);

        this.JsbMethod = {
            //()V 无参数 无返回值
            //(Ljava/lang/String;)V 参数为string 无返回值
            //()Ljava/lang/String;  无参数 返回string
            //(Ljava/lang/String;)Ljava/lang/String;  
            //org.cocos2dx.javascript/AppActivity
            classPath: "org/cocos2dx/javascript/AppActivity",

            //java 调用无参数无返回值的函数
            CALL_JAVA_Arg0_RetVoid: function CALL_JAVA_Arg0_RetVoid(functionname) {
                jsb.reflection.callStaticMethod(this.classPath, functionname, "()V");
            },


            //java 调用一个参数无返回值的函数
            CALL_JAVA_Arg1_RetVoid: function CALL_JAVA_Arg1_RetVoid(functionname, param1) {
                jsb.reflection.callStaticMethod(this.classPath, functionname, "(Ljava/lang/String;)V", param1);
            },


            //java 调用两个参数无返回值的函数
            CALL_JAVA_Arg2_RetVoid: function CALL_JAVA_Arg2_RetVoid(functionname, param1, param2) {
                jsb.reflection.callStaticMethod(this.classPath, functionname, "(Ljava/lang/String;Ljava/lang/String;)V", param1, param2);
            },


            //java 调用三个参数无返回值的函数
            CALL_JAVA_Arg3_RetVoid: function CALL_JAVA_Arg3_RetVoid(functionname, param1, param2, param3) {
                jsb.reflection.callStaticMethod(this.classPath, functionname, "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V", param1, param2, param3);
            },


            //java 调用四个参数无返回值的函数
            CALL_JAVA_Arg4_RetVoid: function CALL_JAVA_Arg4_RetVoid(functionname, param1, param2, param3, param4) {
                jsb.reflection.callStaticMethod(this.classPath, functionname, "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V", param1, param2, param3, param4);
            },


            //java 调用无参数有返回值的函数
            CALL_JAVA_Arg0_RetArg: function CALL_JAVA_Arg0_RetArg(functionname) {
                var result = jsb.reflection.callStaticMethod(this.classPath, functionname, "()Ljava/lang/String;");
                return result;
            },


            //java 调用一个参数有返回值的函数
            CALL_JAVA_Arg1_RetArg: function CALL_JAVA_Arg1_RetArg(functionname, param1) {
                var result = jsb.reflection.callStaticMethod(this.classPath, functionname, "(Ljava/lang/String;)Ljava/lang/String;", param1);
                return result;
            },


            //java 调用两个参数有返回值的函数
            CALL_JAVA_Arg2_RetArg: function CALL_JAVA_Arg2_RetArg(functionname, param1, param2) {
                var result = jsb.reflection.callStaticMethod(this.classPath, functionname, "(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;", param1, param2);
                return result;
            }
        };

        console.log("NativeAndrid constructor");
    }

    /**
     * jsb 调用函数
     */


    //使用严格模式


    _createClass(NativeAndrid, [{
        key: 'AndroidCallBack',


        /**
         * Android apk 交互相关函数
         * Java 函数调用 JavaScript 函数的封装
         *
         * 备注：回调函数必须绑定在 window 对象上，作为全局函数使用 
         */
        value: function AndroidCallBack() {
            /**
             * 视频奖励发放
             */
            window.RewardVideoADonReward = function (state) {
                console.log("RewardVideoADonReward state:", state);
                if (state == 1) {
                    //视频播放成功
                    NativeAndrid.getInstance()._onRewardSuccess();
                } else {
                    //视频播放失败
                    NativeAndrid.getInstance()._onRewardFail();
                }
            };
        }

        /*
        * 显示激励视频视频广告
        */

    }, {
        key: 'GstRewardVideoAD',
        value: function GstRewardVideoAD() {
            var _onSuccess = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : null;

            var _onFail = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;

            console.log("调用java GstRewardVideoAD");
            this._onRewardSuccess = _onSuccess;
            this._onRewardFail = _onFail;

            this.JsbMethod.CALL_JAVA_Arg0_RetVoid('GstRewardVideoAD');
        }

        /**
         * 返回当前实例
         */

    }], [{
        key: 'getInstance',
        value: function getInstance() {
            if (this.m_Instance == null) {
                this.m_Instance = new NativeAndrid();
            }
            return this.m_Instance;
        }
    }]);

    return NativeAndrid;
}();

/**
 * 本地ios调用
 */


var NativeIos = exports.NativeIos = function () {

    /**
     * 初始化
     */
    function NativeIos() {
        _classCallCheck(this, NativeIos);

        this.JsbMethod = {
            //()V 无参数 无返回值
            //(Ljava/lang/String;)V 参数为string 无返回值
            //()Ljava/lang/String;  无参数 返回string
            //(Ljava/lang/String;)Ljava/lang/String;  
            //org.cocos2dx.javascript/AppActivity
            classPath: "org/cocos2dx/javascript/AppActivity",

            //OC 调用无参数无返回值的函数
            CALL_OC_Arg0_RetVoid: function CALL_OC_Arg0_RetVoid(functionname) {
                jsb.reflection.callStaticMethod(this.classPath, functionname);
            },


            //OC 调用一个参数无返回值的函数
            CALL_OC_Arg1_RetVoid: function CALL_OC_Arg1_RetVoid(functionname, param1) {
                jsb.reflection.callStaticMethod(this.classPath, functionname, param1);
            },


            //OC 调用两个参数无返回值的函数
            CALL_OC_Arg2_RetVoid: function CALL_OC_Arg2_RetVoid(functionname, param1, param2) {
                jsb.reflection.callStaticMethod(this.classPath, functionname, param1, param2);
            },


            //OC 调用三个参数无返回值的函数
            CALL_OC_Arg3_RetVoid: function CALL_OC_Arg3_RetVoid(functionname, param1, param2, param3) {
                jsb.reflection.callStaticMethod(this.classPath, functionname, param1, param2, param3);
            },


            //OC 调用四个参数无返回值的函数
            CALL_OC_Arg4_RetVoid: function CALL_OC_Arg4_RetVoid(functionname, param1, param2, param3, param4) {
                jsb.reflection.callStaticMethod(this.classPath, functionname, param1, param2, param3, param4);
            },


            //OC 调用无参数有返回值的函数
            CALL_OC_Arg0_RetArg: function CALL_OC_Arg0_RetArg(functionname) {
                var result = jsb.reflection.callStaticMethod(this.classPath, functionname);
                return result;
            },


            //OC 调用一个参数有返回值的函数
            CALL_OC_Arg1_RetArg: function CALL_OC_Arg1_RetArg(functionname, param1) {
                var result = jsb.reflection.callStaticMethod(this.classPath, functionname, param1);
                return result;
            },


            //OC 调用两个参数有返回值的函数
            CALL_OC_Arg2_RetArg: function CALL_OC_Arg2_RetArg(functionname, param1, param2) {
                var result = jsb.reflection.callStaticMethod(this.classPath, functionname, param1, param2);
                return result;
            }
        };

        console.log("NativeIos constructor");
    }

    /**
     * jsb 调用函数
     */


    //使用严格模式


    _createClass(NativeIos, [{
        key: 'AndroidCallBack',


        /**
         * Android apk 交互相关函数
         * Java 函数调用 JavaScript 函数的封装
         *
         * 备注：回调函数必须绑定在 window 对象上，作为全局函数使用 
         */
        value: function AndroidCallBack() {
            /**
             * 视频奖励发放
             */
            window.RewardVideoADonReward = function (state) {
                console.log("RewardVideoADonReward state:", state);
                if (state == 1) {
                    //视频播放成功
                    NativeIos.getInstance()._onRewardSuccess();
                } else {
                    //视频播放失败
                    NativeIos.getInstance()._onRewardFail();
                }
            };
        }

        /*
        * 显示激励视频视频广告
        */

    }, {
        key: 'GstRewardVideoAD',
        value: function GstRewardVideoAD() {
            var _onSuccess = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : null;

            var _onFail = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;

            console.log("调用object-c GstRewardVideoAD");
            this._onRewardSuccess = _onSuccess;
            this._onRewardFail = _onFail;

            this.JsbMethod.CALL_OC_Arg0_RetVoid('GstRewardVideoAD');
        }

        /**
         * 返回当前实例
         */

    }], [{
        key: 'getInstance',
        value: function getInstance() {
            if (this.m_Instance == null) {
                this.m_Instance = new NativeIos();
            }
            return this.m_Instance;
        }
    }]);

    return NativeIos;
}();

/**
 * 统计服务
 */


var StatisticsServer = exports.StatisticsServer = function () {

    /**
     * 初始化
     */
    function StatisticsServer() {
        _classCallCheck(this, StatisticsServer);

        console.log("StatisticsServer constructor");
    }
    /**
     * 新增用户统计
     */


    //使用严格模式


    _createClass(StatisticsServer, [{
        key: 'NewUserCount',
        value: function NewUserCount() {
            if (this.m_Platfrom == PlatformType.Zjkj_WECHAT) {
                if (_BaseUtils.Utils.IsNull(_BaseConfig.BaseConfig.Global.Game_Query.game_id) || _BaseUtils.Utils.IsNull(_BaseConfig.BaseConfig.Global.Game_Query.tg_code)) {
                    _BaseUtils.Utils.CCLog("AuthorizeUserCount Query game_id or tg_code is null");

                    return;
                }
                var http = new _BaseUtils.Http();
                http.AddParam("pid", "10006");
                http.AddParam("game_id", _BaseConfig.BaseConfig.Global.Game_Query.game_id);
                http.AddParam("tg_code", _BaseConfig.BaseConfig.Global.Game_Query.tg_code);
                http.AddParam("uid", DataManager.getInstance().GetUserUUID());
                // _url, _cbSuccess, _cbFail
                var url = _BaseConfig.BaseConfig.Global.NetRoot + _BaseConfig.BaseConfig.Global.TgSDK_ServerUrl + "10006.php";

                http.SendRequest(url, function (data) {
                    _BaseUtils.Utils.CCLog(data);
                }, function (err) {
                    console.error(err);
                });
            } else {}
        }

        /**
         * 授权用户统计
         */

    }, {
        key: 'AuthorizeUserCount',
        value: function AuthorizeUserCount() {
            if (this.m_Platfrom == PlatformType.Zjkj_WECHAT) {
                if (_BaseUtils.Utils.IsNull(_BaseConfig.BaseConfig.Global.Game_Query.game_id) || _BaseUtils.Utils.IsNull(_BaseConfig.BaseConfig.Global.Game_Query.tg_code)) {
                    console.error("AuthorizeUserCount Query game_id or tg_code is null");
                    return;
                }

                var http = new _BaseUtils.Http();
                http.AddParam("pid", "10007");
                http.AddParam("game_id", _BaseConfig.BaseConfig.Global.Game_Query.game_id);
                http.AddParam("tg_code", _BaseConfig.BaseConfig.Global.Game_Query.tg_code);
                http.AddParam("uid", DataManager.getInstance().GetUserUUID());
                // _url, _cbSuccess, _cbFail
                var url = _BaseConfig.BaseConfig.Global.NetRoot + _BaseConfig.BaseConfig.Global.TgSDK_ServerUrl + "10007.php";

                http.SendRequest(url, function (data) {
                    _BaseUtils.Utils.CCLog(data);
                }, function (err) {
                    console.error(err);
                });
            } else {}
        }

        /**
         * 发送gamebox自定义事件
         * @param {object} _appdata
         */

    }, {
        key: 'SendGameBoxEvent',
        value: function SendGameBoxEvent(_appdata) {
            var _menuname = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;

            if (this.m_Platfrom == PlatformType.Zjkj_WECHAT) {
                AldServer.getInstance().SendGameBoxEvent(_appdata, _menuname);
            } else {}
        }

        /**
         * 发送界面自定义事件
         * @param {string} _menuname
         */

    }, {
        key: 'SendMenuEvent',
        value: function SendMenuEvent(_menuname) {
            if (this.m_Platfrom == PlatformType.Zjkj_WECHAT) {
                AldServer.getInstance().SendMenuEvent(_menuname);
            } else {}
        }

        /**
         * 发送皮肤自定义事件
         * @param {string} _skinname
         */

    }, {
        key: 'SendSkinEvent',
        value: function SendSkinEvent(_skinname) {
            if (this.m_Platfrom == PlatformType.Zjkj_WECHAT) {
                AldServer.getInstance().SendSkinEvent(_skinname);
            } else {}
        }

        /**
         * 发送 定向界面 自定义事件
         * @param {object} _appdata
         */

    }, {
        key: 'SendJumpEvent',
        value: function SendJumpEvent(_appdata) {
            if (this.m_Platfrom == PlatformType.Zjkj_WECHAT) {
                AldServer.getInstance().SendJumpEvent(_skinname);
            } else {}
        }

        /**
         * 关卡统计 关卡开始
         * @param {string} _stageId     关卡ID      该字段只能是 1 , 2 , 3 , 1.1 , 1.2 , 1.3 格式 最多支持 32 个字符 
         * @param {string} _stageName   关卡名字     最多支持 32 个字符
         * 
         */

    }, {
        key: 'Stage_OnStart',
        value: function Stage_OnStart() {
            var _stageId = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "1";

            var _stageName = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : "第一关";

            if (this.m_Platfrom == PlatformType.Zjkj_WECHAT) {
                AldServer.getInstance().Stage_OnStart(_stageId, _stageName);
            } else {}
        }

        /**
         * 关卡统计 关卡中使用道具
         * @param {string} _stageId     关卡ID      该字段只能是 1 , 2 , 3 , 1.1 , 1.2 , 1.3 格式 最多支持 32 个字符 
         * @param {string} _stageName   关卡名字     最多支持 32 个字符 
         * @param {string} _event       事件类型     payStart:发起支付 paySuccess:支付成功 payFail:支付失败 tools:使用道具 revive:复活 award:奖励
         * @param {string} _itemName    物品名字     
         * @param {string} _itemId      物品id     
         * @param {number} _itemCount   物品数量         
         * @param {string} _itemdesc    物品描述     
         * @param {number} _itemMoney   物品价格     
         * 
         */

    }, {
        key: 'Stage_OnRunning',
        value: function Stage_OnRunning() {
            var _stageId = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "1";

            var _stageName = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : "第一关";

            var _event = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : "tools";

            var _itemName = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : "物品名字";

            var _itemId = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : "110";

            var _itemCount = arguments.length > 5 && arguments[5] !== undefined ? arguments[5] : 1;

            var _itemdesc = arguments.length > 6 && arguments[6] !== undefined ? arguments[6] : "描述";

            var _itemMoney = arguments.length > 7 && arguments[7] !== undefined ? arguments[7] : 100;

            if (this.m_Platfrom == PlatformType.Zjkj_WECHAT) {
                AldServer.getInstance().Stage_OnRunning(_stageId, _stageName, _event, _itemName, _itemId, _itemCount, _itemdesc, _itemMoney);
            } else {}
        }

        /**
         * 关卡统计 关卡结束
         * @param {string} _stageId     关卡ID      该字段只能是 1 , 2 , 3 , 1.1 , 1.2 , 1.3 格式 最多支持 32 个字符 
         * @param {string} _stageName   关卡名字     最多支持 32 个字符 
         * @param {string} _event       事件类型     complete:成功 fail:失败 
         * @param {string} _stageDesc   原因描述     
         * 
         */

    }, {
        key: 'Stage_OnEnd',
        value: function Stage_OnEnd() {
            var _stageId = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "1";

            var _stageName = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : "第一关";

            var _event = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : "complete";

            var _stageDesc = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : "关卡完成";

            if (this.m_Platfrom == PlatformType.Zjkj_WECHAT) {
                AldServer.getInstance().Stage_OnEnd(_stageId, _stageName, _event, _stageDesc);
            } else {}
        }

        /**
         * 返回当前实例
         */

    }], [{
        key: 'getInstance',
        value: function getInstance() {
            if (this.m_Instance == null) {
                this.m_Instance = new StatisticsServer();
            }
            return this.m_Instance;
        }
    }]);

    return StatisticsServer;
}();

/**
 * 阿拉丁服务
 */


var AldServer = exports.AldServer = function () {

    /**
     * 初始化
     */
    function AldServer() {
        _classCallCheck(this, AldServer);

        console.log("TgSDKServer constructor");
    }

    /**
     * 发送gamebox阿拉丁自定义事件
     * @param {object} _appdata
     */


    //使用严格模式


    _createClass(AldServer, [{
        key: 'SendGameBoxEvent',
        value: function SendGameBoxEvent(_appdata) {
            var _menuname = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;

            if (cc.sys.platform == cc.sys.WECHAT_GAME) {
                _BaseUtils.Utils.CCLog('SendGameBoxEvent:', _appdata);
                // var data_name = data.name_skip?data.name_skip:_appdata.name;
                // 统计所有游戏
                wx.aldSendEvent('自研盒子v201905-点击统计', {
                    "自研游戏名称": _BaseConfig.BaseConfig.Global.Game_Name,
                    "推广游戏名称": _appdata.name_skip ? _appdata.name_skip : _appdata.name,
                    "位置统计": _menuname ? _menuname : _appdata.tjwz
                });

                // 统计当前游戏
                wx.aldSendEvent('自研盒子v201905-游戏统计', {
                    "贪吃蛇大激战": _appdata.name_skip ? _appdata.name_skip : _appdata.name,
                    "贪吃蛇大激战_位置": _menuname ? _menuname + '_' + _BaseConfig.BaseConfig.Global.Game_Name : _appdata.tjwz + '_' + _BaseConfig.BaseConfig.Global.Game_Name
                });
            }
        }

        /**
         * 发送界面阿拉丁自定义事件
         * @param {string} _menuname
         */

    }, {
        key: 'SendMenuEvent',
        value: function SendMenuEvent(_menuname) {
            if (cc.sys.platform == cc.sys.WECHAT_GAME) {
                // 统计所有游戏
                wx.aldSendEvent('界面统计', {
                    "自研游戏名称": _BaseConfig.BaseConfig.Global.Game_Name,
                    "界面名字": _menuname
                });
            }
        }

        /**
         * 发送皮肤阿拉丁自定义事件
         * @param {string} _skinname
         */

    }, {
        key: 'SendSkinEvent',
        value: function SendSkinEvent(_skinname) {

            if (cc.sys.platform == cc.sys.WECHAT_GAME) {
                // 统计所有游戏
                wx.aldSendEvent('皮肤统计', {
                    "自研游戏名称": _BaseConfig.BaseConfig.Global.Game_Name,
                    "皮肤名字": _skinname
                });
            }
        }

        /**
         * 发送 定向界面 阿拉丁自定义事件
         * @param {object} _appdata
         */

    }, {
        key: 'SendJumpEvent',
        value: function SendJumpEvent(_appdata) {
            if (cc.sys.platform == cc.sys.WECHAT_GAME) {
                _BaseUtils.Utils.CCLog('SendJumpEvent:', _appdata);
                wx.aldSendEvent('自研盒子v201905-游戏统计', {
                    "贪吃蛇大激战_定向跳转": _appdata.name_skip ? _appdata.name_skip : _appdata.name
                });
            }
        }

        /**
         * 关卡统计 关卡开始
         * @param {string} _stageId     关卡ID      该字段只能是 1 , 2 , 3 , 1.1 , 1.2 , 1.3 格式 最多支持 32 个字符 
         * @param {string} _stageName   关卡名字     最多支持 32 个字符
         * 
         */

    }, {
        key: 'Stage_OnStart',
        value: function Stage_OnStart() {
            var _stageId = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "1";

            var _stageName = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : "第一关";

            if (cc.sys.platform == cc.sys.WECHAT_GAME) {
                _BaseUtils.Utils.CCLog('Stage_OnStart _stageId:', _stageId, "_stageName:", _stageName);
                //关卡开始
                wx.aldStage.onStart({
                    stageId: _stageId, //关卡ID 该字段必传
                    stageName: _stageName, //关卡名称  该字段必传
                    userId: _BaseUtils.DataManage.getInstance().GetUserUUID() //用户ID 可选
                });
            }
        }

        /**
         * 关卡统计 关卡中使用道具
         * @param {string} _stageId     关卡ID      该字段只能是 1 , 2 , 3 , 1.1 , 1.2 , 1.3 格式 最多支持 32 个字符 
         * @param {string} _stageName   关卡名字     最多支持 32 个字符 
         * @param {string} _event       事件类型     payStart:发起支付 paySuccess:支付成功 payFail:支付失败 tools:使用道具 revive:复活 award:奖励
         * @param {string} _itemName    物品名字     
         * @param {string} _itemId      物品id     
         * @param {number} _itemCount   物品数量         
         * @param {string} _itemdesc    物品描述     
         * @param {number} _itemMoney   物品价格     
         * 
         */

    }, {
        key: 'Stage_OnRunning',
        value: function Stage_OnRunning() {
            var _stageId = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "1";

            var _stageName = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : "第一关";

            var _event = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : "tools";

            var _itemName = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : "物品名字";

            var _itemId = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : "110";

            var _itemCount = arguments.length > 5 && arguments[5] !== undefined ? arguments[5] : 1;

            var _itemdesc = arguments.length > 6 && arguments[6] !== undefined ? arguments[6] : "描述";

            var _itemMoney = arguments.length > 7 && arguments[7] !== undefined ? arguments[7] : 100;

            if (cc.sys.platform == cc.sys.WECHAT_GAME) {
                _BaseUtils.Utils.CCLog('Stage_OnRunning _stageId:', _stageId, "_stageName:", _stageName);
                //关卡中
                wx.aldStage.onRunning({
                    stageId: _stageId,
                    stageName: _stageName,
                    userId: _BaseUtils.DataManage.getInstance().GetUserUUID(),
                    event: _event,
                    params: {
                        itemName: _itemName,
                        itemId: _itemId,
                        itemCount: _itemCount,
                        desc: _itemdesc,
                        itemMoney: _itemMoney

                    }
                });
            }
        }

        /**
         * 关卡统计 关卡结束
         * @param {string} _stageId     关卡ID      该字段只能是 1 , 2 , 3 , 1.1 , 1.2 , 1.3 格式 最多支持 32 个字符 
         * @param {string} _stageName   关卡名字     最多支持 32 个字符 
         * @param {string} _event       事件类型     complete:成功 fail:失败 
         * @param {string} _stageDesc   原因描述     
         * 
         */

    }, {
        key: 'Stage_OnEnd',
        value: function Stage_OnEnd() {
            var _stageId = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "1";

            var _stageName = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : "第一关";

            var _event = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : "complete";

            var _stageDesc = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : "关卡完成";

            if (cc.sys.platform == cc.sys.WECHAT_GAME) {
                _BaseUtils.Utils.CCLog('Stage_OnEnd _stageId:', _stageId, "_stageName:", _stageName);
                //关卡完成
                wx.aldStage.onEnd({
                    stageId: _stageId, //关卡ID 该字段必传
                    stageName: _stageName, //关卡名称  该字段必传
                    userId: _BaseUtils.DataManage.getInstance().GetUserUUID(), //用户ID 可选
                    event: _event, //关卡完成  关卡进行中，用户触发的操作    该字段必传
                    params: {
                        desc: _stageDesc //描述
                    }
                });
            }
        }

        /**
         * 返回当前实例
         */

    }], [{
        key: 'getInstance',
        value: function getInstance() {
            if (this.m_Instance == null) {
                this.m_Instance = new AldServer();
            }
            return this.m_Instance;
        }
    }]);

    return AldServer;
}();

/**
 * 平台逻辑
 */


var BasePlatform = exports.BasePlatform = function () {

    /**
     * 初始化
     */
    function BasePlatform() {
        _classCallCheck(this, BasePlatform);

        _BaseUtils.Utils.CCLog("BasePlatform constructor");
        //设置平台
        this.m_Platfrom = PlatformType.Zjkj_Default;
        console.log('cc.sys.platform', cc.sys.platform);

        //在桌面浏览器调试
        if (cc.sys.platform == cc.sys.DESKTOP_BROWSER) {
            //设置平台
            this.m_Platfrom = PlatformType.Zjkj_Default;
        } else if (cc.sys.platform == cc.sys.WECHAT_GAME) {
            this.m_Platfrom = PlatformType.Zjkj_WECHAT;
        }

        //设备信息
        this.m_SystemInfo = null;
        //胶囊体信息
        this.m_CapsuleData = null;
        // getMenuButtonBoundingClientRect
    }

    /**
     * 监听显示函数
     */


    //使用严格模式


    _createClass(BasePlatform, [{
        key: 'OnShow',
        value: function OnShow() {
            if (this.m_Platfrom == PlatformType.Zjkj_WECHAT) {
                WeChat.getInstance().OnShow();
            } else if (this.m_Platfrom == PlatformType.Zjkj_Android_233) {
                //调用Android的回调绑定
                NativeAndrid.getInstance().AndroidCallBack();
            } else {}
        }

        /**
         * 监听隐藏函数
         */

    }, {
        key: 'OnHide',
        value: function OnHide() {
            if (this.m_Platfrom == PlatformType.Zjkj_WECHAT) {
                WeChat.getInstance().OnHide();
            } else {}
        }

        /**
         * 加快触发 JavaScriptCore 垃圾回收（Garbage Collection）
         * GC 时机是由 JavaScriptCore 来控制的，并不能保证调用后马上触发 GC。
         * 
         */

    }, {
        key: 'TriggerGC',
        value: function TriggerGC() {
            if (this.m_Platfrom == PlatformType.Zjkj_WECHAT) {
                WeChat.getInstance().TriggerGC();
            } else {}
        }

        /**
         * 加载分包 wx的分包加载其他平台不在处理直接返回
         * @param {funtion}} _callFun 
         */

    }, {
        key: 'LoadSubPackage',
        value: function LoadSubPackage(_subPackageName, _callFun) {
            if (this.m_Platfrom == PlatformType.Zjkj_WECHAT) {
                WeChat.getInstance().LoadSubpackage(_subPackageName, _callFun);
            } else {
                _callFun("非微信平台");
            }
        }

        /**
         * 获取微信右上角胶囊体位置
         */

    }, {
        key: 'GetCapsuleData',
        value: function GetCapsuleData() {
            if (this.m_Platfrom == PlatformType.Zjkj_WECHAT) {
                //如果胶囊体位置信息没有则重新获取
                if (!this.m_CapsuleData) {
                    this.m_CapsuleData = WeChat.getInstance().GetMenuButtonBoundingClientRect();
                }
                return this.m_CapsuleData;
            } else {
                return null;
            }
        }

        /**
         * 获取获取系统信息
         */

    }, {
        key: 'GetSystemInfo',
        value: function GetSystemInfo() {
            if (this.m_Platfrom == PlatformType.Zjkj_WECHAT) {
                //如果系统信息没有则重新获取
                if (!this.m_SystemInfo) {
                    this.m_SystemInfo = WeChat.getInstance().GetSystemInfoSync();
                }
                return this.m_SystemInfo;
            } else {
                return null;
            }
        }

        /**
         * 授权接口
         * 提前向用户发起授权请求。
         * 调用后会立刻弹窗询问用户是否同意授权小程序使用某项功能或获取用户的某些数据，
         * 但不会实际调用对应接口。如果用户之前已经同意授权，则不会出现弹窗，直接返回成功
         */

    }, {
        key: 'Authorize',
        value: function Authorize(_onSuccess, _onFail) {
            if (this.m_Platfrom == PlatformType.Zjkj_WECHAT) {
                WeChat.getInstance().Authorize(_onSuccess, _onFail);
            } else {
                _onSuccess("非微信平台");
            }
        }

        /**
         * 创建授权按钮
         */

    }, {
        key: 'CreateUserInfoButton',
        value: function CreateUserInfoButton(_onSuccess, _onFail) {
            if (this.m_Platfrom == PlatformType.Zjkj_WECHAT) {
                WeChat.getInstance().CreateUserInfoButton(_onSuccess, _onFail);
            } else {
                _onSuccess("非微信平台");
            }
        }

        /**
         * 获取用户信息
         */

    }, {
        key: 'GetUserInfo',
        value: function GetUserInfo(_onSuccess, _onFail) {
            if (this.m_Platfrom == PlatformType.Zjkj_WECHAT) {
                WeChat.getInstance().GetUserInfo(_onSuccess, _onFail);
            } else {
                _onFail("非微信平台");
            }
        }

        /**
         * 初始化分享
         * 
         */

    }, {
        key: 'InitShare',
        value: function InitShare() {
            if (this.m_Platfrom == PlatformType.Zjkj_WECHAT) {
                WeChat.getInstance().InitWxShare();
            } else {}
        }

        /**
         * 分享
         * 传入 _imageUrl
         */

    }, {
        key: 'ShareMessage',
        value: function ShareMessage() {
            var _title = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "";

            var _imageUrl = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;

            if (this.m_Platfrom == PlatformType.Zjkj_WECHAT) {
                var titletext = _title;
                var imageurl = _imageUrl;

                //没有指定分享语
                if (_BaseUtils.Utils.IsNull(titletext)) {

                    var rand = _BaseUtils.Utils.RandNum(1, 5);
                    if (rand == 1) {
                        titletext = _BaseConfig.BaseConfig.ShareTextData.ShareText1;
                    } else if (rand == 2) {
                        titletext = _BaseConfig.BaseConfig.ShareTextData.ShareText2;
                    } else if (rand == 3) {
                        titletext = _BaseConfig.BaseConfig.ShareTextData.ShareText3;
                    } else if (rand == 4) {
                        titletext = _BaseConfig.BaseConfig.ShareTextData.ShareText4;
                    } else if (rand == 5) {
                        titletext = _BaseConfig.BaseConfig.ShareTextData.ShareText5;
                    }
                }

                //没有指定分享图片
                if (_BaseUtils.Utils.IsNull(imageurl)) {
                    if (titletext == _BaseConfig.BaseConfig.ShareTextData.ShareText1) {
                        imageurl = _BaseConfig.BaseConfig.Global.NetRoot + _BaseConfig.BaseConfig.Global.NetRes + 'wx_share/' + _BaseConfig.BaseConfig.ShareImgData.ShareImg1;
                    } else if (titletext == _BaseConfig.BaseConfig.ShareTextData.ShareText2) {
                        imageurl = _BaseConfig.BaseConfig.Global.NetRoot + _BaseConfig.BaseConfig.Global.NetRes + 'wx_share/' + _BaseConfig.BaseConfig.ShareImgData.ShareImg1;
                    } else if (titletext == _BaseConfig.BaseConfig.ShareTextData.ShareText3) {
                        imageurl = _BaseConfig.BaseConfig.Global.NetRoot + _BaseConfig.BaseConfig.Global.NetRes + 'wx_share/' + _BaseConfig.BaseConfig.ShareImgData.ShareImg1;
                    } else if (titletext == _BaseConfig.BaseConfig.ShareTextData.ShareText4) {
                        imageurl = _BaseConfig.BaseConfig.Global.NetRoot + _BaseConfig.BaseConfig.Global.NetRes + 'wx_share/' + _BaseConfig.BaseConfig.ShareImgData.ShareImg2;
                    } else if (titletext == _BaseConfig.BaseConfig.ShareTextData.ShareText5) {
                        imageurl = _BaseConfig.BaseConfig.Global.NetRoot + _BaseConfig.BaseConfig.Global.NetRes + 'wx_share/' + _BaseConfig.BaseConfig.ShareImgData.ShareImg3;
                    }
                }

                WeChat.getInstance().ShareAppMessage(titletext, imageurl);
            } else {}
        }

        /**
         * 截图
         * 传入截图node _Rendernode
         * @param {cc.Node} _Rendernode
         *  根据node的宽高可视区域截图 当图片宽比 超出 5：4 会裁剪多出来的部分
         * web 平台不会根据node进行截屏
         */

    }, {
        key: 'RenderTexture',
        value: function RenderTexture() {
            var _Rendernode = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : null;

            if (this.m_Platfrom == PlatformType.Zjkj_WECHAT) {
                if (_Rendernode) {
                    //根据node的可视区域截图 当图片宽比 超出 5：4 会裁剪多出来的部分
                    //设计宽
                    var viewwidth = cc.visibleRect.width;
                    //设计高
                    var viewheight = cc.visibleRect.height;
                    //实际视图
                    var size = cc.view.getFrameSize();
                    var rect = _Rendernode.getBoundingBoxToWorld();
                    var image = WeChat.getInstance().RenderTexture(rect.xMin / viewwidth * canvas.width, (viewheight - rect.yMax) / viewheight * canvas.height, rect.width / viewwidth * canvas.width, rect.height / viewheight * canvas.height, rect.width / viewwidth * canvas.width, rect.height / viewheight * canvas.height);
                    return image;
                } else {
                    //默认全屏
                    return WeChat.getInstance().RenderTexture(0, 0, canvas.width, canvas.height, canvas.width, canvas.height);
                }
            } else {
                // let node = new cc.Node();
                // node.parent = cc.director.getScene();
                // let camera = node.addComponent(cc.Camera);

                // // 设置你想要的截图内容的 cullingMask
                // camera.cullingMask = 0xffffffff;

                // // 新建一个 RenderTexture，并且设置 camera 的 targetTexture 为新建的 RenderTexture，这样 camera 的内容将会渲染到新建的 RenderTexture 中。
                // let texture = new cc.RenderTexture();
                // let gl = cc.game._renderContext;
                // // 如果截图内容中不包含 Mask 组件，可以不用传递第三个参数
                // texture.initWithSize(cc.visibleRect.width, cc.visibleRect.height, gl.STENCIL_INDEX8);

                // camera.targetTexture = texture;

                // // 渲染一次摄像机，即更新一次内容到 RenderTexture 中
                // camera.render();

                // // 这样我们就能从 RenderTexture 中获取到数据了
                // let data = texture.readPixels();

                // // 接下来就可以对这些数据进行操作了
                // let canvas = document.createElement('canvas');
                // let ctx = canvas.getContext('2d');
                // canvas.width = texture.width;
                // canvas.height = texture.height;

                // let width = texture.width;
                // let height = texture.height;

                // let rowBytes = width * 4;
                // for (let row = 0; row < height; row++) {
                //     let srow = height - 1 - row;
                //     let imageData = ctx.createImageData(width, 1);
                //     let start = srow * width * 4;
                //     for (let i = 0; i < rowBytes; i++) {
                //         imageData.data[i] = data[start + i];
                //     }

                //     ctx.putImageData(imageData, 0, row);
                // }

                // let dataURL = canvas.toDataURL("image/jpeg");
                // let img = document.createElement("img");
                // img.src = dataURL;

                // // var img = new Image();
                // // img.src = dataURL;
                // // let testtexture = new cc.Texture2D();
                // // testtexture.initWithElement(img);
                // // texture.initWithElement(img);
                // // Utils.CCLog("testtexture",testtexture);

                // return img;
            }
        }

        /**
         * 上传用户数据到服务器
         * 
         * 
         */

    }, {
        key: 'UploadUserCloudData',
        value: function UploadUserCloudData() {
            if (this.m_Platfrom == PlatformType.Zjkj_WECHAT) {
                var limittimedata = _BaseUtils.Utils.CloneObj(_BaseConfig.BaseConfig.CloudData);
                limittimedata.UUID = _BaseUtils.DataManage.getInstance().GetUserUUID();
                limittimedata.Score = _BaseUtils.DataManage.getInstance().GetLimitTimeMaxScore();
                limittimedata.UpdateTime = cc.sys.now();

                var endlessdata = _BaseUtils.Utils.CloneObj(_BaseConfig.BaseConfig.CloudData);
                endlessdata.UUID = _BaseUtils.DataManage.getInstance().GetUserUUID();
                endlessdata.Score = _BaseUtils.DataManage.getInstance().GetEndlessMaxScore();
                endlessdata.UpdateTime = cc.sys.now();

                var goodtimedata = _BaseUtils.Utils.CloneObj(_BaseConfig.BaseConfig.CloudData);
                goodtimedata.UUID = _BaseUtils.DataManage.getInstance().GetUserUUID();
                goodtimedata.Score = _BaseUtils.DataManage.getInstance().GetGoodTimeMaxScore();
                goodtimedata.UpdateTime = cc.sys.now();

                var kvlist = new Array();

                kvlist.push({ key: _BaseConfig.BaseConfig.LimitTimeCloudDataKey, value: JSON.stringify(limittimedata) });
                kvlist.push({ key: _BaseConfig.BaseConfig.EndlessCloudDataKey, value: JSON.stringify(endlessdata) });
                kvlist.push({ key: _BaseConfig.BaseConfig.GoodTimeCloudDataKey, value: JSON.stringify(goodtimedata) });

                _BaseUtils.Utils.CCLog("kvlist", kvlist);
                WeChat.getInstance().UploadUserCloudData(kvlist);
            } else {
                _BaseUtils.Utils.CCLog('非微信平台');
            }
        }

        /**
         * 向子域发送消息
         * @param {BaseConfig.OpenDataMessageType} _opendataMessageType 
         * @param {JSON} _data 
         */

    }, {
        key: 'OpenDataContextPostMessage',
        value: function OpenDataContextPostMessage(_opendataMessageType) {
            var _data = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '';

            if (this.m_Platfrom == PlatformType.Zjkj_WECHAT) {
                _BaseConfig.BaseConfig.OpenDataMessageData.MessageType = _opendataMessageType;
                _BaseConfig.BaseConfig.OpenDataMessageData.Data = _data;

                //获取用户信息信息时要传入kvlist数组 其他消息不用处理
                if (_opendataMessageType == _BaseConfig.BaseConfig.OpenDataMessageType.GetCloudStorage) {
                    _BaseConfig.BaseConfig.OpenDataMessageData.KVDataList = [_BaseConfig.BaseConfig.LimitTimeCloudDataKey, _BaseConfig.BaseConfig.EndlessCloudDataKey, _BaseConfig.BaseConfig.GoodTimeCloudDataKey];
                } else if (_opendataMessageType == _BaseConfig.BaseConfig.OpenDataMessageType.ShowEndlessRank) {
                    _BaseConfig.BaseConfig.OpenDataMessageData.DataKey = _BaseConfig.BaseConfig.EndlessCloudDataKey;
                } else if (_opendataMessageType == _BaseConfig.BaseConfig.OpenDataMessageType.ShowGoodTimeRank) {
                    _BaseConfig.BaseConfig.OpenDataMessageData.DataKey = _BaseConfig.BaseConfig.GoodTimeCloudDataKey;
                } else if (_opendataMessageType == _BaseConfig.BaseConfig.OpenDataMessageType.ShowLimitTimeRank) {
                    _BaseConfig.BaseConfig.OpenDataMessageData.DataKey = _BaseConfig.BaseConfig.LimitTimeCloudDataKey;
                }

                WeChat.getInstance().OpenDataContextPostMessage(_BaseConfig.BaseConfig.OpenDataMessageData);
            } else {
                _BaseUtils.Utils.CCLog('非微信平台');
            }
        }

        /**
         * 初始化平台广告
         */

    }, {
        key: 'InitAD',
        value: function InitAD() {
            if (this.m_Platfrom == PlatformType.Zjkj_WECHAT) {} else {}
        }

        /**
         * 初始化banner 广告
         */

    }, {
        key: 'InitBannerAd',
        value: function InitBannerAd() {
            if (this.m_Platfrom == PlatformType.Zjkj_WECHAT) {
                var banneradid = _BaseConfig.BaseConfig.WeChatGlobal.BannerAdUnitId;
                var left = WeChat.getInstance().GetSystemInfoSync().screenWidth / 2 - 150;
                var top = 0;

                var width = 300; //WeChat.getInstance().GetSystemInfoSync().screenWidth;
                var height = 100; //WeChat.getInstance().GetSystemInfoSync().screenWidth;

                if (_BaseUtils.Utils.IsNull(banneradid)) {
                    _BaseUtils.Utils.CCLog("banner广告id为空");
                    return;
                }
                WeChat.getInstance().CreateBannerAd(banneradid, left, top, width, height);
            } else {}
        }

        /**
         * banner 广告 显示
         */

    }, {
        key: 'ShowBannerAd',
        value: function ShowBannerAd() {
            if (this.m_Platfrom == PlatformType.Zjkj_WECHAT) {
                WeChat.getInstance().ShowBannerAd();
            } else {}
        }

        /**
         * banner 广告 隐藏
         */

    }, {
        key: 'HideBannerAd',
        value: function HideBannerAd() {
            if (this.m_Platfrom == PlatformType.Zjkj_WECHAT) {
                WeChat.getInstance().HideBannerAd();
            } else {}
        }

        /**
         * 初始化视频广告
         * @param {function} _onSuccess    成功返回函数
         * @param {function} _onFail       失败返回函数
         * _onSuccess, _onFail
         */

    }, {
        key: 'InitRewardedVideoAd',
        value: function InitRewardedVideoAd(_onSuccess, _onFail) {
            if (this.m_Platfrom == PlatformType.Zjkj_WECHAT) {
                if (_BaseUtils.Utils.IsNull(_BaseConfig.BaseConfig.WeChatGlobal.RewardedVideoAdUnitId)) {
                    _onFail("RewardedVideoAdUnitId is null");
                    return;
                }

                WeChat.getInstance().CreateRewardedVideoAd(_BaseConfig.BaseConfig.WeChatGlobal.RewardedVideoAdUnitId, _onSuccess, _onFail);
            } else {}
        }

        /**
         * 显示视频广告
         * @param {function} _onSuccess    成功返回函数
         * @param {function} _onFail       失败返回函数
         */

    }, {
        key: 'ShowRewardedVideoAd',
        value: function ShowRewardedVideoAd(_onSuccess, _onFail) {
            if (this.m_Platfrom == PlatformType.Zjkj_WECHAT) {
                _BaseUtils.AudioManage.getInstance().PauseMusic();
                _BaseUtils.AudioManage.getInstance().StopAllSound();

                WeChat.getInstance().ShowRewardedVideoAd(function () {

                    _BaseUtils.AudioManage.getInstance().ResumeMusic();
                    if (_onSuccess) {
                        _onSuccess();
                    }
                }, function (err) {

                    _BaseUtils.AudioManage.getInstance().ResumeMusic();
                    if (_onFail) {
                        _onFail(err);
                    }
                });
            } else {
                _onSuccess();
            }
        }

        /**
         * 初始化插屏广告
         * @param {function} _onSuccess    成功返回函数
         * @param {function} _onFail       失败返回函数
         * _onSuccess, _onFail
         */

    }, {
        key: 'InitInterstitialAd',
        value: function InitInterstitialAd(_onSuccess, _onFail) {
            if (this.m_Platfrom == PlatformType.Zjkj_WECHAT) {
                if (_BaseUtils.Utils.IsNull(_BaseConfig.BaseConfig.WeChatGlobal.InterstitialAdUnitId)) {
                    _onFail("RewardedVideoAdUnitId is null");
                    return;
                }

                WeChat.getInstance().CreateInterstitialAd(_BaseConfig.BaseConfig.WeChatGlobal.InterstitialAdUnitId, _onSuccess, _onFail);
            } else {
                _onSuccess();
            }
        }

        /**
         * 显示插屏广告
         * @param {function} _onSuccess    成功返回函数
         * @param {function} _onFail       失败返回函数
         */

    }, {
        key: 'ShowInterstitialAd',
        value: function ShowInterstitialAd(_onSuccess, _onFail) {
            if (this.m_Platfrom == PlatformType.Zjkj_WECHAT) {
                WeChat.getInstance().ShowInterstitialAd(_onSuccess, _onFail);
            } else {
                _onFail();
            }
        }

        /**
         * 跳转到指定小程序
         * @param {object} _appdata 游戏数据
         * @param {string}  _menuName   界面名称
         * @param {function} _onSuccess 成功回调函数
         * @param {function} _onFail 失败回调函数
         * 
         */

    }, {
        key: 'JumpToProgram',
        value: function JumpToProgram(_appdata) {
            var _menuName = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;

            var _onSuccess = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : null;

            var _onFail = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : null;

            _BaseUtils.Utils.CCLog("JumpToProgram _appdata", _appdata);
            if (this.m_Platfrom == PlatformType.Zjkj_WECHAT) {
                var wxappid = _appdata.appid_skip ? _appdata.appid_skip : _appdata.appid;
                var wxpath = _appdata.appid_skip ? "?zjkj_cmd=box_info_page&info_appid=" + _appdata.appid : _appdata.path;

                var found = _BaseConfig.BaseConfig.Global.Game_Bind_App_List.find(function (element) {
                    if (wxappid == element) {
                        return element;
                    }
                });

                //已绑定
                if (!_BaseUtils.Utils.IsNull(found)) {
                    WeChat.getInstance().JumpToMiniProgram(wxappid, wxpath, _appdata.extData, "release", function () {
                        StatisticsServer.getInstance().SendGameBoxEvent(_appdata);
                        if (_onSuccess) {
                            _onSuccess();
                        }
                    }, function () {

                        if (_onFail) {
                            _onFail();
                        }
                    });
                } else {
                    //未绑定
                    var imgurl = _BaseConfig.BaseConfig.Global.NetRoot + _BaseConfig.BaseConfig.Global.BoxMenuNetRes + "ewm/ewm_def.jpg";
                    if (!_BaseUtils.Utils.IsNull(_appdata.ewm_img)) {
                        imgurl = _BaseConfig.BaseConfig.Global.NetRoot + _BaseConfig.BaseConfig.Global.BoxMenuNetRes + "ewm" + _appdata.ewm_img;
                    }
                    _BaseUtils.Utils.CCLog("PreviewImage", imgurl);
                    WeChat.getInstance().PreviewImage(imgurl);
                }
            } else {
                if (_onFail) {
                    _onFail();
                }
            }
        }

        /**
         * 返回当前实例
         */

    }], [{
        key: 'getInstance',
        value: function getInstance() {
            if (this.m_Instance == null) {
                this.m_Instance = new BasePlatform();
            }
            return this.m_Instance;
        }
    }]);

    return BasePlatform;
}();

//监听显示函数


BasePlatform.getInstance().OnShow();
//监听隐藏函数
BasePlatform.getInstance().OnHide();

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=BasePlatform.js.map
        