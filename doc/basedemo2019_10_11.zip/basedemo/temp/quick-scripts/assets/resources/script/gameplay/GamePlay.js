(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/resources/script/gameplay/GamePlay.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'a5702g7BKJB55XSJZfYh81U', 'GamePlay', __filename);
// resources/script/gameplay/GamePlay.js

'use strict';

var _BaseLayer = require('../base/BaseLayer');

var _BaseConfig = require('../base/BaseConfig');

var _BasePlatform = require('../base/BasePlatform');

var _BaseUtils = require('../base/BaseUtils');

cc.Class({
    extends: _BaseLayer.BaseLayer,

    properties: {},

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {},


    // update (dt) {},

    /**
     * 按钮点击事件
     * @param {cc.Touch} touch 
     * if (touch.target.name == 'StartGame') {
     * }
     */
    OnClick: function OnClick(touch) {
        //实现方法 示例
        console.log("BaseLayer click event:", touch);
        if (touch.target.name == 'Btn_Back') {
            //移除自己
            _BaseUtils.MenuManage.getInstance().RmoveMenu(_BaseConfig.BaseConfig.MenuRes.GamePlay);
            //显示主界面
            _BaseUtils.MenuManage.getInstance().ShowMenu(_BaseConfig.BaseConfig.MenuRes.MainMenu);
        }
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=GamePlay.js.map
        