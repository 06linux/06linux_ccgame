(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/resources/script/base/BaseUtils.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'a469dmActJPtI6YPhFOnRdc', 'BaseUtils', __filename);
// resources/script/base/BaseUtils.js

'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.Http = exports.NodePoolManage = exports.AudioManage = exports.DataManage = exports.MenuManage = exports.MenuType = exports.Utils = undefined;

var _class2, _temp;

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();
/**
*
*                 _oo0oo_
                 o8888888o
                 88" . "88
                 (| -_- |)
                 0\  =  /0
               ___/`—'\___
             .' \\|     |— '.
            / \\|||  :  |||— \
           / _||||| -:- |||||- \
          |   | \\\  -  —/ |   |
          | \_|  ''\—/''  |_/ |
          \  .-\__  '-'  ___/-. /
        ___'. .'  /—.—\  `. .'___
     ."" '<  `.___\_<|>_/___.' >' "".
    | | :  `- \`.;`\ _ /`;.`/ - ` : | |
    \  \ `_.   \_ __\ /__ _/   .-` /  /
=====`-.____`.___ \_____/___.-`___.-'=====
                  `=—='
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
             佛祖保佑    永无BUG
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
*
**/


var _BaseLayer = require('./BaseLayer');

var _BaseConfig = require('./BaseConfig');

var _BasePlatform = require('./BasePlatform');

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

/**
 * 工具静态类
 */
var Utils = exports.Utils = function () {
    function Utils() {
        _classCallCheck(this, Utils);
    }

    _createClass(Utils, null, [{
        key: 'CCLog',


        /**
         * 输出log
         */
        value: function CCLog() {
            if (_BaseConfig.BaseConfig.Debug) {
                for (var _len = arguments.length, _custome = Array(_len), _key2 = 0; _key2 < _len; _key2++) {
                    _custome[_key2] = arguments[_key2];
                }

                console.log.apply(console, _custome);
            }
        }

        /**
         * 计数输出log
         */


        //使用严格模式

    }, {
        key: 'CCLogCount',
        value: function CCLogCount() {
            if (_BaseConfig.BaseConfig.Debug) {
                for (var _len2 = arguments.length, _custome = Array(_len2), _key3 = 0; _key3 < _len2; _key3++) {
                    _custome[_key3] = arguments[_key3];
                }

                console.count.apply(console, _custome);
            }
        }

        /**
         * 计数输出log
         */

    }, {
        key: 'CCLogResetCount',
        value: function CCLogResetCount() {
            if (_BaseConfig.BaseConfig.Debug) {
                for (var _len3 = arguments.length, _custome = Array(_len3), _key4 = 0; _key4 < _len3; _key4++) {
                    _custome[_key4] = arguments[_key4];
                }

                console.countReset.apply(console, _custome);
            }
        }

        /**
         * 输出对象
         */

    }, {
        key: 'CCLogDir',
        value: function CCLogDir(_object) {
            if (_BaseConfig.BaseConfig.Debug) {
                console.dir(_object);
                // console.count.apply(console, _custome);
            }
        }

        /**
         * 输出跟踪
         */

    }, {
        key: 'CCLogTrace',
        value: function CCLogTrace() {
            if (_BaseConfig.BaseConfig.Debug) {
                for (var _len4 = arguments.length, _custome = Array(_len4), _key5 = 0; _key5 < _len4; _key5++) {
                    _custome[_key5] = arguments[_key5];
                }

                console.trace.apply(console, _custome);
                // console.count.apply(console, _custome);
            }
        }

        /**
         * 分组输出log
         */

    }, {
        key: 'CCLogGroup',
        value: function CCLogGroup() {
            if (_BaseConfig.BaseConfig.Debug) {
                for (var _len5 = arguments.length, _custome = Array(_len5), _key6 = 0; _key6 < _len5; _key6++) {
                    _custome[_key6] = arguments[_key6];
                }

                console.group.apply(console, _custome);
            }
        }

        /**
         * 分组结束输出log
         */

    }, {
        key: 'CCLogGroupEnd',
        value: function CCLogGroupEnd() {
            if (_BaseConfig.BaseConfig.Debug) {
                for (var _len6 = arguments.length, _custome = Array(_len6), _key7 = 0; _key7 < _len6; _key7++) {
                    _custome[_key7] = arguments[_key7];
                }

                console.groupEnd.apply(console, _custome);
            }
        }

        /**
         * 时间输出log
         */

    }, {
        key: 'CCLogTime',
        value: function CCLogTime() {
            if (_BaseConfig.BaseConfig.Debug) {
                for (var _len7 = arguments.length, _custome = Array(_len7), _key8 = 0; _key8 < _len7; _key8++) {
                    _custome[_key8] = arguments[_key8];
                }

                console.time.apply(console, _custome);
            }
        }

        /**
         * 时间结束输出log
         */

    }, {
        key: 'CCLogTimeEnd',
        value: function CCLogTimeEnd() {
            if (_BaseConfig.BaseConfig.Debug) {
                for (var _len8 = arguments.length, _custome = Array(_len8), _key9 = 0; _key9 < _len8; _key9++) {
                    _custome[_key9] = arguments[_key9];
                }

                console.timeEnd.apply(console, _custome);
            }
        }

        /**
         * 输出错误
         */

    }, {
        key: 'CCLogError',
        value: function CCLogError() {
            if (_BaseConfig.BaseConfig.Debug) {
                for (var _len9 = arguments.length, _custome = Array(_len9), _key10 = 0; _key10 < _len9; _key10++) {
                    _custome[_key10] = arguments[_key10];
                }

                console.error.apply(console, _custome);
                // console.count.apply(console, _custome);
            }
        }

        /**
         * 输出警告
         */

    }, {
        key: 'CCLogWarn',
        value: function CCLogWarn() {
            if (_BaseConfig.BaseConfig.Debug) {
                for (var _len10 = arguments.length, _custome = Array(_len10), _key11 = 0; _key11 < _len10; _key11++) {
                    _custome[_key11] = arguments[_key11];
                }

                console.warn.apply(console, _custome);
                // console.count.apply(console, _custome);
            }
        }
        /**
         * 清理输出log
         */

    }, {
        key: 'CCLogClear',
        value: function CCLogClear() {
            if (_BaseConfig.BaseConfig.Debug) {
                console.clear();
                // console.count.apply(console, _custome);
            }
        }

        /**
         * 返回一个随机数
         * @param {number} _min 
         * @param {number} _max 
         * 返回一个整数
         */

    }, {
        key: 'RandNum',
        value: function RandNum(_min, _max) {

            if (_max < _min) {
                return Math.round(_max) + Math.round(Math.random() * (_min - _max));
            } else if (_max === _min) {
                return Math.round(_min);
            } else {
                return Math.round(_min) + Math.round(Math.random() * (_max - _min));
            }
        }

        /**
         * 返回一个随机数
         * @param {Float} _min 
         * @param {Float} _max 
         * 返回一个浮点数
         */

    }, {
        key: 'RandFloat',
        value: function RandFloat(_min, _max) {

            if (_max < _min) {
                return _max + Math.random() * (_min - _max);
            } else if (_max === _min) {
                return _min;
            } else {
                return _min + Math.random() * (_max - _min);
            }
        }

        /**
         * 返回一个随机弧度
         * 范围(-π,+π)
         * 返回一个浮点数
         */

    }, {
        key: 'RandRadian',
        value: function RandRadian() {
            return Math.random() > 0.5 ? Math.random() % Math.PI : -Math.random() % Math.PI;
        }

        /**
         * 判读对象是否为空
         * @param {object} _arr 
         */

    }, {
        key: 'IsNull',
        value: function IsNull(_value) {

            if (_value === null || _value === "" || _value === "null" || _value === "Null" || _value === "NULL" || _value === undefined) {
                return true;
            } else {
                return false;
            }
        }

        /**
         * 深度拷贝对象
         * @param {object} obj 
         */

    }, {
        key: 'CloneObj',
        value: function CloneObj(obj) {
            var newObj = {};
            if (obj instanceof Array) {
                newObj = [];
            }
            for (var key in obj) {
                var val = obj[key];
                if (val === null) {
                    newObj[key] = null;
                } else {
                    newObj[key] = (typeof val === 'undefined' ? 'undefined' : _typeof(val)) === 'object' ? this.CloneObj(val) : val;
                }
            }
            return newObj;
        }

        /**
         * 返回一个唯一的uuid
         * 
         */

    }, {
        key: 'GetUUID',
        value: function GetUUID() {
            var d = new Date().getTime();
            var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
                var r = (d + Math.random() * 16) % 16 | 0;
                d = Math.floor(d / 16);
                return (c == 'x' ? r : r & 0x3 | 0x8).toString(16);
            });
            return uuid;
        }

        /**
         * 返回一个字符串对应字节的长度的片段
         * @param {string} _str 
         * @param {number} _bytes
         * 
         */

    }, {
        key: 'GetStringCutOut',
        value: function GetStringCutOut(_str) {
            var _bytes = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 10;

            var result = "";

            if (_str == null) {
                return result;
            }

            var len = 0;
            for (var i = 0; i < _str.length; i++) {

                if (_str.charCodeAt(i) > 127 || _str.charCodeAt(i) == 94) {
                    len += 2;
                } else {
                    len++;
                }

                if (len <= _bytes) {
                    result += _str.charAt(i);
                }
            }

            if (result.length < _str.length) {
                result += "...";
            }

            // console.log("GetStringTrim result",result);

            return result;
        }

        /**
         * 返回字符串根据 字符 分割数组
         * @param {string} _str 
         * @param {string} _key 
         */

    }, {
        key: 'GetStringToArray',
        value: function GetStringToArray(_arr) {
            var _key = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : ';';

            if (Utils.IsNull(_arr)) {
                return [];
            }

            return _arr.split(_key);
        }

        /**
         * 返回弧度对应长度的位置 
         * 默认为1长度
         * @param {Float} _eadian 
         */

    }, {
        key: 'RadianToVec2',
        value: function RadianToVec2(_eadian) {
            var _lenght = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 1;

            return cc.v2(Math.cos(_eadian) * _lenght, Math.sin(_eadian) * _lenght);
        }

        /**
         * 返回角度对应的弧度
         * @param {Float} _angle
         */

    }, {
        key: 'AngleToRadian',
        value: function AngleToRadian(_angle) {
            return _angle / 180 * Math.PI; // (_eadian/Math.PI)*180;
        }

        /**
         * 返回弧度对应的角度
         * @param {Float} _eadian 
         */

    }, {
        key: 'RadianToAngle',
        value: function RadianToAngle(_eadian) {
            return _eadian / Math.PI * 180;
        }

        /**
         * 返回两个向量的距离
         * @param {Float} _eadian 
         */

    }, {
        key: 'Vec2Distance',
        value: function Vec2Distance(_vec21, _vec22) {
            var out = cc.v2(0, 0);
            out.x = _vec21.x - _vec22.x;
            out.y = _vec21.y - _vec22.y;
            // let length =  Math.sqrt(_vec2.x * _vec2.x + _vec2.y * _vec2.y);
            return Math.sqrt(out.x * out.x + out.y * out.y);
        }

        /**
         * 返回二维向量的减法
         * @param {cc.Vec2} _vec21
         * @param {cc.Vec2} _vec22 
         * 
         */

    }, {
        key: 'Vec2Sub',
        value: function Vec2Sub(_vec21, _vec22) {
            var out = cc.v2(0, 0);
            out.x = _vec21.x - _vec22.x;
            out.y = _vec21.y - _vec22.y;
            return out;
        }

        /**
         * 返回二维向量的弧度
         * @param {cc.Vec2} _vec2 
         */

    }, {
        key: 'Vec2Radian',
        value: function Vec2Radian(_vec2) {
            return Math.atan2(_vec2.y, _vec2.x);
        }

        /**
         * 返回二维向量的长度
         * @param {cc.Vec2} _vec2 
         */

    }, {
        key: 'Vec2Lenght',
        value: function Vec2Lenght(_vec2) {
            return Math.sqrt(_vec2.x * _vec2.x + _vec2.y * _vec2.y);
        }

        /**
         * 返回二维向量归一化
         * @param {cc.Vec2} _vec2 
         */

    }, {
        key: 'Vec2Normalize',
        value: function Vec2Normalize(_vec2) {
            var out = cc.v2(0, 0);
            var magSqr = _vec2.x * _vec2.x + _vec2.y * _vec2.y;
            if (magSqr === 1.0) return _vec2;

            if (magSqr === 0.0) {
                return _vec2;
            }

            var invsqrt = 1.0 / Math.sqrt(magSqr);
            out.x = _vec2.x * invsqrt;
            out.y = _vec2.y * invsqrt;

            return out;
        }

        /**
         * 返回二维向量的缩放
         * @param {cc.Vec2} _vec2 
         * @param {Number} _lenght 
         * 
         */

    }, {
        key: 'Vec2Mul',
        value: function Vec2Mul(_vec2, _lenght) {
            var out = cc.v2(0, 0);
            out.x = _vec2.x * _lenght;
            out.y = _vec2.y * _lenght;
            return out;
        }

        /**
         * 将毫秒数转换成时间格式 2019:05:30:10:12:10
         * @param {number} _time
         */

    }, {
        key: 'GetTimeFormat',
        value: function GetTimeFormat(_time) {
            var now = new Date(_time),
                y = now.getFullYear(),
                m = now.getMonth() + 1,
                d = now.getDate();
            return y + "-" + (m < 10 ? "0" + m : m) + "-" + (d < 10 ? "0" + d : d) + " " + now.toTimeString().substr(0, 8);
        }

        /**
         * 将秒数转换成时间格式 10:50 秒
         * @param {number} _time 
         */

    }, {
        key: 'GetTimeMinutesSeconds',
        value: function GetTimeMinutesSeconds(_time) {
            var minutes = Math.floor(_time / 60);
            var seconds = _time - minutes * 60;
            return (minutes < 10 ? "0" + minutes : minutes) + ":" + (seconds < 10 ? "0" + seconds : seconds);
        }

        /**
         * 将毫秒数转换成时间格式  分钟
         * @param {number} _time 
         */

    }, {
        key: 'GetTimeMinutes',
        value: function GetTimeMinutes(_time) {
            return Math.ceil(_time / 60);
        }

        /**
         * 将毫秒数转换成时间格式  天
         * @param {number} _time 
         */

    }, {
        key: 'GetTimeDay',
        value: function GetTimeDay(_time) {
            return Math.ceil(_time / 1000 / 60 / 60 / 24);
        }

        /**
         * 将毫秒数转换成时间格式  小时
         * @param {number} _time 
         */

    }, {
        key: 'GetTimeHour',
        value: function GetTimeHour(_time) {
            return Math.ceil(_time / 1000 / 60 / 60);
        }

        /**
         * 数字字符串相加
         * @param {String} _strA
         * @param {String} _strB
         * 
         */

    }, {
        key: 'StringCalculateSum',
        value: function StringCalculateSum(_strA, _strB) {

            //先判断是否是字符串
            if (typeof _strA !== 'string') {
                _strA = _strA + '';
            }

            if (typeof _strB !== 'string') {
                _strB = _strB + '';
            }

            var raList = _strA.split(''),
                rbList = _strB.split(''),
                result = '',
                count = 0;
            // Utils.CCLog('StringCalculateAddition  raList', raList, 'rbList', rbList);

            while (raList.length || rbList.length || count) {
                // Utils.CCLogCount('StringCalculateSum whiel')
                count += ~~raList.pop() + ~~rbList.pop();
                result = count % 10 + result;
                count = count > 9;
            }
            // Utils.CCLog('StringCalculateSum  raList', raList, 'rbList', rbList, 'result', result);

            return result;
        }

        /**
         * 数字字符串相减
         * @param {String} _strA 被减数
         * @param {String} _strB 减数
         * 
         */

    }, {
        key: 'StringCalculateSub',
        value: function StringCalculateSub(_strA, _strB) {

            //先判断是否是字符串
            if (typeof _strA !== 'string') {
                _strA = _strA + '';
            }

            if (typeof _strB !== 'string') {
                _strB = _strB + '';
            }
            var raList = _strA.split(''),
                rbList = _strB.split(''),
                result = '',
                count = 0,
                desc = 0;

            if (parseInt(_strA) < parseInt(_strB)) {
                // Utils.CCLog('_strA < _strB');
                var temp = raList;
                raList = rbList;
                rbList = temp;
                desc = -1;
            } else if (_strA == _strB) {
                return 0;
            }

            Utils.CCLog('StringCalculateAddition  raList', raList, 'rbList', rbList);

            while (raList.length || rbList.length || count) {
                Utils.CCLogCount('StringCalculateSub whiel');
                var ad = ~~raList.pop() - ~~rbList.pop() - count;
                Utils.CCLog('ad', ad, 'count', count);
                result = (ad < 0 ? 10 + ad : ad) + result;
                count = ad < 0;
            }

            var relist = result.split('');

            for (var index = 0; index < relist.length; index++) {
                var element = relist[index];
                if (element != 0) {
                    relist.splice(0, index);
                    break;
                }

                if (index == relist.length - 1) {
                    relist.splice(0, relist.length - 1);
                    break;
                }
            }

            if (desc == -1) {
                relist.splice(0, 0, '-');
            }
            Utils.CCLog('StringCalculateSub  raList', raList, 'rbList', rbList, 'result', result, 'relist.join', relist.join(''));

            return relist.join('');
        }

        /**
         * 返回换算后的字符串
         * @param {String} _strA 
         * 
         */

    }, {
        key: 'StringGetConversionUnit',
        value: function StringGetConversionUnit(_strA) {

            //先判断是否是字符串
            if (typeof _strA !== 'string') {
                _strA = _strA + '';
            }

            var unitSymbols = ['', 'K', 'B', 'M', 'T', 'P', 'E', 'Z', 'Y', 'S', 'L', 'X', 'D'],
                ra = _strA.replace(/(^|\s)\d+/g, function (m) {
                return m.replace(/(?=(?!\b)(\d{3})+$)/g, ',');
            }),
                result = '',
                desc = 0;

            var splitArray = ra.split(',');
            if (splitArray.length > unitSymbols.length) {
                splitArray.splice(splitArray.length - unitSymbols.length, unitSymbols.length - 1);
                desc = unitSymbols[unitSymbols.length - 1];
            } else {
                desc = unitSymbols[splitArray.length - 1];
                splitArray.splice(1, splitArray.length - 1);
            }

            result = splitArray.join('') + desc;

            // raList.splice(raList.length - unitindex * 3, raList.length - 1);
            // Utils.CCLog('StringGetConversionUnit ra', ra, 'splitArray', splitArray, 'desc', desc);
            return result;
        }
    }]);

    return Utils;
}();

var MenuType = exports.MenuType = (_temp = _class2 = function MenuType() {
    _classCallCheck(this, MenuType);
}, _class2.TransitionType = {
    None: 1,
    FadeIn: 2,
    FadeOut: 3,
    PopUp: 4,
    LeftIn: 5,
    LeftOut: 6,
    RightIn: 7,
    RightOut: 8

}, _temp);

/**
 * 界面管理类
 */

var MenuManage = exports.MenuManage = function () {

    /**
     * 初始化
     */
    function MenuManage() {
        _classCallCheck(this, MenuManage);

        console.log("MenuManage constructor");
        this.m_Menus = new Map();
        this.m_MainCamera = null;
        this.m_GamePlayCamera = null;
    }

    /**
     * 界面默认绑定的根节点
     */


    //使用严格模式


    _createClass(MenuManage, [{
        key: 'GetMenuRoot',
        value: function GetMenuRoot() {
            var node = cc.find("Canvas");
            if (node) {
                return node;
            }
            return null;
        }

        /**
         * 预加载场景
         * @param {string} _sceneName 场景名字
         * @param {Function} _onSuccess 回调成功函数
         * 
         */

    }, {
        key: 'PreLoadScene',
        value: function PreLoadScene(_sceneName, _onSuccess) {

            cc.director.preloadScene(_sceneName, function () {
                if (_onSuccess) {
                    _onSuccess();
                }
            });
        }

        /**
         * 切换场景后前一个场景会将所有界面销毁
         * @param {string} _sceneName 场景名字
         * @param {Function} _onSuccess 回调成功函数
         */

    }, {
        key: 'SwitchScene',
        value: function SwitchScene(_sceneName, _onSuccess) {
            var _this = this;

            cc.director.loadScene(_sceneName, function (data) {

                //清除掉以前的界面
                _this.m_Menus = new Map();
                if (_onSuccess) {
                    _onSuccess();
                }
            });
        }

        /**
         * 显示界面
         * @param {string} _urlName 界面路径
         * @param {object} _customeData 初始化传入的数据
         * @param {MenuType.TransitionType} _transitionType 过度动画
         * @param {cc.Node} _parent 父节点
         */

    }, {
        key: 'ShowMenu',
        value: function ShowMenu(_urlName) {
            var _customeData = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;

            var _this2 = this;

            var _transitionType = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : null;

            var _parent = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : null;

            // console.log("ShowMenu m_Menus", this.m_Menus, "GetMenuRoot:", this.GetMenuRoot())

            //先判断是否有已显示这个界面
            if (this.m_Menus.has(_urlName)) {
                console.log("ShowMenu menu is show");
                return;
            } else {
                console.log("ShowMenu show ");

                //界面数据
                var menudata = {
                    node: null
                    // type: _type != null ? _type : MenuType.Type.Normal,//类型没有传值则使用默认值
                };

                this.m_Menus.set(_urlName, menudata);

                //显示遮挡
                var MenuBg = cc.instantiate(this.GetMenuRoot().getChildByName("MenuBg"));
                // console.log("MenuBg", MenuBg);
                MenuBg.parent = _parent != null ? _parent : this.GetMenuRoot();

                this.LoadMenu(_urlName).then(function (assets) {
                    var objmenu = cc.instantiate(assets); //instantiate(assets);
                    objmenu.parent = _parent != null ? _parent : _this2.GetMenuRoot();
                    //记录遮挡
                    objmenu.__MenuBg__ = MenuBg;

                    //初始化参数
                    objmenu.getComponent(_BaseLayer.BaseLayer).Init(_customeData);

                    //过度动画类型
                    _this2.TransitionMenu(_transitionType != null ? _transitionType : MenuType.TransitionType.None, objmenu, function () {
                        menudata.node = objmenu;
                        console.log("menudata", menudata);
                    });
                }, function (err) {
                    //加载错误直接将数据删除
                    //销毁bg遮挡
                    MenuBg.destroy();

                    console.log(err);
                    _this2.m_Menus.delete(_urlName);
                });

                // console.log("m_Menus", this.m_Menus);
            }
        }

        /**
         * 移除界面
         * @param {string} _urlName     界面路径
         * @param {object} _customeData 释放传入的数据
         * @param {MenuType.TransitionType} _transitionType 过度动画类型
         */

    }, {
        key: 'RmoveMenu',
        value: function RmoveMenu(_urlName) {
            var _this3 = this;

            var _customeData = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;

            var _transitionType = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : MenuType.TransitionType.None;

            var objMenu = this.m_Menus.get(_urlName);
            if (objMenu) {

                //判断是否加载完界面
                if (Utils.IsNull(objMenu.node)) {
                    console.log("menu loading");
                    return;
                } else {
                    //释放函数
                    objMenu.node.getComponent(_BaseLayer.BaseLayer).Free(_customeData);

                    //过度动画类型
                    this.TransitionMenu(_transitionType, objMenu.node, function () {
                        console.log("TransitionMenu");
                        //销毁bg遮挡
                        if (objMenu.node.__MenuBg__) {
                            objMenu.node.__MenuBg__.destroy();
                        }
                        //销毁界面node
                        objMenu.node.destroy();

                        _this3.m_Menus.delete(_urlName);
                    });
                }
            }
        }
        /**
         * 加载界面
         * @param {string} _urlName 界面路径
         */

    }, {
        key: 'LoadMenu',
        value: function LoadMenu(_urlName) {
            return new Promise(function (resolve, reject) {
                cc.loader.loadRes(_urlName, cc.prefab, function (err, assets) {
                    if (err) {
                        reject(err);
                        return;
                    }
                    resolve(assets);
                });
            });
        }

        /**
         * 界面过度动画
         * @param {MenuType.TransitionType} _transitionType 过度动画类型
         * @param {cc.Node} _objMenu    界面node
         * @param {Function} _callFun   回调函数
         * 
         */

    }, {
        key: 'TransitionMenu',
        value: function TransitionMenu(_transitionType, _objMenu, _callFun) {
            if (!!_objMenu) {
                switch (_transitionType) {
                    case MenuType.TransitionType.None:
                        {
                            _callFun();
                        }
                        break;
                    case MenuType.TransitionType.FadeIn:
                        {
                            _objMenu.opacity = 0;
                            var action = cc.fadeIn(1.0);
                            var finished = cc.callFunc(_callFun);
                            _objMenu.runAction(cc.sequence(action, finished));
                        }
                        break;
                    case MenuType.TransitionType.FadeOut:
                        {
                            _objMenu.opacity = 255;
                            var action = cc.fadeOut(1.0);
                            var finished = cc.callFunc(_callFun);
                            _objMenu.runAction(cc.sequence(action, finished));
                        }
                        break;
                    case MenuType.TransitionType.PopUp:
                        {
                            _objMenu.scaleX = 0.1;
                            _objMenu.scaleY = 0.1;
                            var action = cc.scaleTo(0.3, 1);
                            var finished = cc.callFunc(_callFun);
                            _objMenu.runAction(cc.sequence(action, finished));
                        }
                        break;
                    case MenuType.TransitionType.LeftIn:
                        {
                            var descignsize = cc.view.getDesignResolutionSize();
                            _objMenu.x = -descignsize.width;
                            _objMenu.y = 0;

                            var action = cc.moveTo(0.3, cc.v2(0, 0));
                            var finished = cc.callFunc(_callFun);
                            _objMenu.runAction(cc.sequence(action, finished));
                        }
                        break;
                    case MenuType.TransitionType.LeftOut:
                        {
                            var _descignsize = cc.view.getDesignResolutionSize();
                            // _objMenu.x = -descignsize.width/2;
                            // _objMenu.y = 0;

                            var action = cc.moveTo(0.3, cc.v2(-_descignsize.width, 0));
                            var finished = cc.callFunc(_callFun);
                            _objMenu.runAction(cc.sequence(action, finished));
                        }
                        break;
                    case MenuType.TransitionType.RightIn:
                        {
                            var _descignsize2 = cc.view.getDesignResolutionSize();
                            _objMenu.x = _descignsize2.width;
                            _objMenu.y = 0;

                            var action = cc.moveTo(0.3, cc.v2(0, 0));
                            var finished = cc.callFunc(_callFun);
                            _objMenu.runAction(cc.sequence(action, finished));
                        }
                        break;
                    case MenuType.TransitionType.RightOut:
                        {
                            var _descignsize3 = cc.view.getDesignResolutionSize();
                            // _objMenu.x = descignsize.width;
                            // _objMenu.y = 0;

                            var action = cc.moveTo(0.3, cc.v2(_descignsize3.width, 0));
                            var finished = cc.callFunc(_callFun);
                            _objMenu.runAction(cc.sequence(action, finished));
                        }
                        break;
                    default:
                        break;
                }
            }
        }

        /**
         * 返回对应的界面
         * @param {string} _urlName 界面路径
         */

    }, {
        key: 'GetMenu',
        value: function GetMenu(_urlName) {
            //查找界面是否加载了
            var objMenu = this.m_Menus.get(_urlName);
            if (objMenu) {
                //资源是否加载成功了
                if (objMenu.node) {
                    return objMenu.node.getComponent(_BaseLayer.BaseLayer);
                } else {
                    return null;
                }
            }

            return null;
        }

        /**
         * 获取主摄像机
         */

    }, {
        key: 'GetMainCamera',
        value: function GetMainCamera() {
            if (this.m_MainCamera) {
                return this.m_MainCamera;
            } else {
                this.m_MainCamera = cc.find('Canvas/Main Camera');
                return this.m_MainCamera;
            }
        }

        /**
         * 获取界面摄像机
         */

    }, {
        key: 'GetGamePlay_Camera',
        value: function GetGamePlay_Camera() {
            if (this.m_GamePlayCamera) {
                return this.m_GamePlayCamera;
            } else {
                this.m_GamePlayCamera = cc.find('Canvas/GamePlay Camera');
                return this.m_GamePlayCamera;
            }
        }

        /**
         * 返回当前实例
         */

    }], [{
        key: 'getInstance',
        value: function getInstance() {
            if (this.m_Instance == null) {
                this.m_Instance = new MenuManage();
            }
            return this.m_Instance;
        }
    }]);

    return MenuManage;
}();

/**
 * 数据管理类
 */


var DataManage = exports.DataManage = function () {

    /**
     * 初始化
     */
    function DataManage() {
        _classCallCheck(this, DataManage);

        Utils.CCLog("DataManage constructor");
        this.m_JsonData = new Map();
    }

    /**
     * 加载远程json文件
     * @param {function} _callFun 
     * @param {string} _netUrl 
     * @param {...any} _jsonFile 
     */


    //使用严格模式


    _createClass(DataManage, [{
        key: 'LoadNetJson',
        value: function LoadNetJson(_callFun, _netUrl) {
            var _this4 = this;

            for (var _len11 = arguments.length, _jsonFile = Array(_len11 > 2 ? _len11 - 2 : 0), _key12 = 2; _key12 < _len11; _key12++) {
                _jsonFile[_key12 - 2] = arguments[_key12];
            }

            Utils.CCLog('LoadNetJson', _jsonFile);
            var fileCount = _jsonFile.length;
            var arrLoadSuccess = new Array();

            var _loop = function _loop(i) {
                var fileName = _jsonFile[i];
                if (fileName != '') {

                    var objJson = _this4.m_JsonData.get(fileName);
                    if (objJson) {
                        arrLoadSuccess.push(fileName);
                        if (arrLoadSuccess.length == fileCount) {
                            _callFun("success", arrLoadSuccess.length);
                        } else {
                            _callFun("loading " + fileName, arrLoadSuccess.length);
                        }
                        return 'continue';
                    }

                    var xmlHttp = new XMLHttpRequest(); // 网络访问句柄  
                    // 设置处理响应的回调函数
                    xmlHttp.onreadystatechange = function () {
                        if (xmlHttp.readyState == 4 && xmlHttp.status >= 200 && xmlHttp.status < 400) {
                            var objJson = JSON.parse(xmlHttp.responseText);
                            // Log("objJson",objJson);
                            // Utils.CCLog('LoadNetJson fileName', fileName, 'xmlHttp', xmlHttp);
                            this.m_JsonData.set(fileName, objJson);
                            arrLoadSuccess.push(fileName);
                            if (arrLoadSuccess.length == fileCount) {
                                _callFun("success", arrLoadSuccess.length);
                            } else {
                                _callFun("loading " + fileName, arrLoadSuccess.length);
                            }
                            return;
                        }
                    }.bind(_this4);

                    xmlHttp.open("GET", _netUrl + fileName, true);
                    xmlHttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                    xmlHttp.send();

                    // cc.loader.load(_netUrl+fileName,  (err, res) =>{
                    //     if(err)
                    //     {
                    //         _callFun("error", arrLoadSuccess.length);
                    //         return;
                    //     }
                    //     this.m_JsonData.set(fileName, res);
                    //     arrLoadSuccess.push(fileName);
                    //     if(arrLoadSuccess.length == fileCount)
                    //     {
                    //         _callFun("success", arrLoadSuccess.length);
                    //     }
                    //     else
                    //     {
                    //         _callFun("loading " + fileName, arrLoadSuccess.length);
                    //     }
                    // });
                }
            };

            for (var i = 0; i < fileCount; i++) {
                var _ret = _loop(i);

                if (_ret === 'continue') continue;
            }
        }

        /**
         * 加载远程json文件
         * @param {function} _callFun 
         * @param {string} _netUrl 
         * @param {...any} _jsonFile 
         */

    }, {
        key: 'LoadNetJsonArray',
        value: function LoadNetJsonArray(_callFun, _netUrl, _jsonFileArray) {
            var _this5 = this;

            Utils.CCLog('LoadNetJson', _jsonFileArray);
            var fileCount = _jsonFileArray.length;
            var arrLoadSuccess = new Array();

            var _loop2 = function _loop2(i) {
                var fileName = _jsonFileArray[i];
                if (fileName != '') {

                    var objJson = _this5.m_JsonData.get(fileName);
                    if (objJson) {
                        arrLoadSuccess.push(fileName);
                        if (arrLoadSuccess.length == fileCount) {
                            _callFun("success", arrLoadSuccess.length);
                        } else {
                            _callFun("loading " + fileName, arrLoadSuccess.length);
                        }
                        return 'continue';
                    }

                    var xmlHttp = new XMLHttpRequest(); // 网络访问句柄  
                    // 设置处理响应的回调函数
                    xmlHttp.onreadystatechange = function () {
                        if (xmlHttp.readyState == 4 && xmlHttp.status >= 200 && xmlHttp.status < 400) {
                            var objJson = JSON.parse(xmlHttp.responseText);
                            // Log("objJson",objJson);
                            // Utils.CCLog('LoadNetJson fileName', fileName, 'xmlHttp', xmlHttp);
                            this.m_JsonData.set(fileName, objJson);
                            arrLoadSuccess.push(fileName);
                            if (arrLoadSuccess.length == fileCount) {
                                _callFun("success", arrLoadSuccess.length);
                            } else {
                                _callFun("loading " + fileName, arrLoadSuccess.length);
                            }
                            return;
                        }
                    }.bind(_this5);

                    xmlHttp.open("GET", _netUrl + fileName, true);
                    xmlHttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                    xmlHttp.send();

                    // cc.loader.load(_netUrl+fileName,  (err, res) =>{
                    //     if(err)
                    //     {
                    //         _callFun("error", arrLoadSuccess.length);
                    //         return;
                    //     }
                    //     this.m_JsonData.set(fileName, res);
                    //     arrLoadSuccess.push(fileName);
                    //     if(arrLoadSuccess.length == fileCount)
                    //     {
                    //         _callFun("success", arrLoadSuccess.length);
                    //     }
                    //     else
                    //     {
                    //         _callFun("loading " + fileName, arrLoadSuccess.length);
                    //     }
                    // });
                }
            };

            for (var i = 0; i < fileCount; i++) {
                var _ret2 = _loop2(i);

                if (_ret2 === 'continue') continue;
            }
        }

        /**
         * 返回对应json的数据
         * @param {string} _keyName 
         */

    }, {
        key: 'GetJson',
        value: function GetJson(_keyName) {
            return this.m_JsonData.get(_keyName);
        }

        /**
         * 返回对应 id 某一行的数据
         * @param {string} _keyName 
         * @param {string} _value 
         * 
         */

    }, {
        key: 'GetJsonVaule',
        value: function GetJsonVaule(_keyName, _id) {

            var json = this.m_JsonData.get(_keyName);
            for (var index = 0; index < json.length; index++) {
                var data = json[index];
                if (data.ID == _id) {
                    return data;
                }
            }

            return null;
        }

        /**
         * 加载游戏关卡配置
         * 注意： 
         *      1.只加载当前关卡和未完关卡 一定数量的配置表
         * 
         */

    }, {
        key: 'LoadGameLevelConfig',
        value: function LoadGameLevelConfig(_levelJson, _levelNum, _callFun) {

            var startlevel = DataManage.getInstance().GetCurrLevel(),
                endlevel = startlevel + _levelNum > _levelJson.length ? _levelJson.length : startlevel + _levelNum,
                mapjsonarr = [];
            for (var index = startlevel - 1; index < endlevel; index++) {
                var levedata = _levelJson[index];
                Utils.CCLog('LoadGameLevelConfig levedata', levedata);
                mapjsonarr.push(levedata.MapID + '.json');
            }

            Utils.CCLog('LoadGameLevelConfig mapjsonarr', mapjsonarr);

            DataManage.getInstance().LoadNetJsonArray(function (res) {
                if (res == 'success') {
                    _callFun();
                }
            }, _BaseConfig.BaseConfig.Global.NetRoot + _BaseConfig.BaseConfig.Global.NetRes + 'json/', mapjsonarr);
        }

        /**
         * 加载游戏配置
         */

    }, {
        key: 'LoadGameConfig',
        value: function LoadGameConfig(_callFun) {

            this.LoadNetJson(function (res) {
                console.log('LoadGameConfig LoadNetJson res', res);
                if (res == 'success') {
                    _callFun();
                }
            }, _BaseConfig.BaseConfig.Global.NetRoot + _BaseConfig.BaseConfig.Global.NetRes + 'json/', _BaseConfig.BaseConfig.GlobalJson.Game_Level_Json, _BaseConfig.BaseConfig.GlobalJson.Game_Skin_Json);
        }

        /**
         * 玩家数据初始化
         */

    }, {
        key: 'InitUserData',
        value: function InitUserData() {
            Utils.CCLog('InitUserData');

            var userdata = this.GetUserDataLocalStorage();
            Utils.CCLog('userdata', userdata);

            //如果存档存在则更具替换参数
            if (userdata) {

                //玩家姓名
                if (!Utils.IsNull(userdata.Name)) {
                    _BaseConfig.BaseConfig.UserData.Name = userdata.Name;
                }

                //玩家头像
                if (!Utils.IsNull(userdata.UserHandIcon)) {
                    _BaseConfig.BaseConfig.UserData.UserHandIcon = userdata.UserHandIcon;
                }

                //当前关卡
                if (!Utils.IsNull(userdata.CurLevel)) {
                    _BaseConfig.BaseConfig.UserData.CurLevel = userdata.CurLevel;
                }

                //当前皮肤
                if (!Utils.IsNull(userdata.SkinId)) {
                    _BaseConfig.BaseConfig.UserData.SkinId = userdata.SkinId;
                }

                //皮肤背包
                if (!Utils.IsNull(userdata.SkinBig)) {
                    _BaseConfig.BaseConfig.UserData.SkinBig = userdata.SkinBig;
                }
            } else {//没有存档证明是第一次玩游戏
            }

            this.SaveUserDataLocalStorage();
        }

        /**
         * 读取存档
         */

    }, {
        key: 'GetUserDataLocalStorage',
        value: function GetUserDataLocalStorage() {

            var data = cc.sys.localStorage.getItem(_BaseConfig.BaseConfig.UserDataKey);
            if (data) {
                return JSON.parse(data);
            }
            return null;
        }

        /**
         * 存取存档
         */

    }, {
        key: 'SaveUserDataLocalStorage',
        value: function SaveUserDataLocalStorage() {
            //微信平台 同步调用存储接口出现偶现bug
            if (cc.sys.platform == cc.sys.WECHAT_GAME) {
                try {
                    wx.setStorageSync(_BaseConfig.BaseConfig.UserDataKey, JSON.stringify(_BaseConfig.BaseConfig.UserData));
                } catch (e) {
                    Utils.CCLog("wx.setStorageSync", e);
                }
            } else {
                cc.sys.localStorage.setItem(_BaseConfig.BaseConfig.UserDataKey, JSON.stringify(_BaseConfig.BaseConfig.UserData));
            }
        }

        /**
         * 返回用户uuid
         */

    }, {
        key: 'GetUserUUID',
        value: function GetUserUUID() {
            //如果没有uuid
            if (Utils.IsNull(_BaseConfig.BaseConfig.UserUUID)) {
                //读取内存
                var uuiddata = cc.sys.localStorage.getItem(_BaseConfig.BaseConfig.UserUUIDKey);
                if (uuiddata) {
                    Utils.CCLog("uuiddata", uuiddata);
                    _BaseConfig.BaseConfig.UserUUID = JSON.parse(uuiddata);
                } else {
                    _BaseConfig.BaseConfig.UserUUID = Utils.GetUUID();
                    //微信平台 同步调用存储接口出现偶现bug
                    if (cc.sys.platform == cc.sys.WECHAT_GAME) {
                        try {
                            wx.setStorageSync(_BaseConfig.BaseConfig.UserUUIDKey, JSON.stringify(_BaseConfig.BaseConfig.UserUUID));
                        } catch (e) {}
                    } else {
                        cc.sys.localStorage.setItem(_BaseConfig.BaseConfig.UserUUIDKey, JSON.stringify(_BaseConfig.BaseConfig.UserUUID));
                    }
                }
                Utils.CCLog("UserUUID is null", _BaseConfig.BaseConfig.UserUUID);
            }
            Utils.CCLog("GetUserUUID", _BaseConfig.BaseConfig.UserUUID);
            return _BaseConfig.BaseConfig.UserUUID;
        }

        /**
         * 设置用户的名字
         * @param {string} _username
         */

    }, {
        key: 'SetUserName',
        value: function SetUserName(_username) {
            _BaseConfig.BaseConfig.UserData.Name = _username;
            this.SaveUserDataLocalStorage();
        }

        /**
         * 返回用户的名字
         */

    }, {
        key: 'GetUserName',
        value: function GetUserName() {
            return _BaseConfig.BaseConfig.UserData.Name;
        }

        /**
         * 设置用户的头像
         * @param {string} _handIconUrl
         */

    }, {
        key: 'SetUserHandIcon',
        value: function SetUserHandIcon(_handIconUrl) {
            _BaseConfig.BaseConfig.UserData.UserHandIcon = _handIconUrl;
            this.SaveUserDataLocalStorage();
        }

        /**
         * 返回用户的头像
         * 默认http://101.37.33.113/h5/ccc_snake_v2/res_1001/img_base/img_head_deful.png
         */

    }, {
        key: 'GetUserHandIcon',
        value: function GetUserHandIcon() {
            //先判断有没有头像地址
            if (Utils.IsNull(_BaseConfig.BaseConfig.UserData.UserHandIcon)) {
                _BaseConfig.BaseConfig.UserData.UserHandIcon = _BaseConfig.BaseConfig.Global.NetRoot + _BaseConfig.BaseConfig.Global.NetRes + 'img_base/img_head_deful.png';
            }

            return _BaseConfig.BaseConfig.UserData.UserHandIcon;
        }

        /**
         * 增加用户金币
         * @param {number} _goldnum
         */

    }, {
        key: 'AddUserGold',
        value: function AddUserGold(_goldnum) {
            _BaseConfig.BaseConfig.UserData.Gold += _goldnum;
            this.SaveUserDataLocalStorage();
        }

        /**
         * 减少用户金币
         * @param {number} _goldnum
         */

    }, {
        key: 'DelUserGold',
        value: function DelUserGold(_goldnum) {
            Utils.CCLog('DelUserGold is _goldnum', _goldnum, 'BaseConfig.UserData.Gold', _BaseConfig.BaseConfig.UserData.Gold);
            if (_BaseConfig.BaseConfig.UserData.Gold >= _goldnum) {
                _BaseConfig.BaseConfig.UserData.Gold -= _goldnum;
                this.SaveUserDataLocalStorage();
                return true;
            } else {
                Utils.CCLog('gold is less');
                return false;
            }
        }

        /**
         * 返回用户的金币
         */

    }, {
        key: 'GetUserGold',
        value: function GetUserGold() {
            return _BaseConfig.BaseConfig.UserData.Gold;
        }

        /**
         * 设置当前关卡数
         * @param {Number} _levelNum
         */

    }, {
        key: 'SetCurrLevel',
        value: function SetCurrLevel(_levelNum) {
            _BaseConfig.BaseConfig.UserData.CurLevel = _levelNum;
            this.SaveUserDataLocalStorage();
        }

        /**
         * 返回当前关卡数
         */

    }, {
        key: 'GetCurrLevel',
        value: function GetCurrLevel() {
            return _BaseConfig.BaseConfig.UserData.CurLevel;
        }

        /**
         * 设置装备的皮肤id
         * @param {Number} _skinID
         */

    }, {
        key: 'SetEquipSkinId',
        value: function SetEquipSkinId(_skinID) {
            _BaseConfig.BaseConfig.UserData.SkinId = _skinID;
            this.SaveUserDataLocalStorage();
        }

        /**
         * 返回装备的皮肤id
         */

    }, {
        key: 'GetEquipSkinId',
        value: function GetEquipSkinId() {
            return _BaseConfig.BaseConfig.UserData.SkinId;
        }

        /**
         * 设置背景音乐开关
         * @param {Boolean} _ismusic
         */

    }, {
        key: 'SetStepMusic',
        value: function SetStepMusic(_ismusic) {
            _BaseConfig.BaseConfig.UserData.Step_IsMusic = _ismusic;
            //打开音乐
            // if (BaseConfig.UserData.Step_IsMusic) {
            // } //关闭音乐
            // else {
            //     BaseConfig
            // }
            Utils.CCLog('SetStepMusic _ismusic', _ismusic);
            this.SaveUserDataLocalStorage();
        }

        /**
         * 得到设置背景音乐开关
         */

    }, {
        key: 'GetStepMusic',
        value: function GetStepMusic() {
            Utils.CCLog('GetStepMusic', _BaseConfig.BaseConfig.UserData.Step_IsMusic);
            return _BaseConfig.BaseConfig.UserData.Step_IsMusic;
        }

        /**
         * 设置音效开关
         * @param {Boolean} _issound
         */

    }, {
        key: 'SetStepSound',
        value: function SetStepSound(_issound) {
            _BaseConfig.BaseConfig.UserData.Step_IsSound = _issound;
            //打开音乐
            // if (BaseConfig.UserData.Step_IsSound) {
            // } //关闭音乐
            // else {
            // }
            // Utils.CCLog('SetStepSound _issound', _issound)
            this.SaveUserDataLocalStorage();
        }

        /**
         * 得到设置音效开关
         */

    }, {
        key: 'GetStepSound',
        value: function GetStepSound() {
            // Utils.CCLog('GetStepSound', BaseConfig.UserData.Step_IsSound);
            return _BaseConfig.BaseConfig.UserData.Step_IsSound;
        }

        /**
         * 设置教学标记
         */

    }, {
        key: 'SetUserTeaching',
        value: function SetUserTeaching() {
            _BaseConfig.BaseConfig.UserData.Teaching = true;
            this.SaveUserDataLocalStorage();
        }

        /**
         * 获取教学标记
         */

    }, {
        key: 'GetUserTeaching',
        value: function GetUserTeaching() {
            return _BaseConfig.BaseConfig.UserData.Teaching;
        }

        /**
         * 清除存档
         * 
         */

    }, {
        key: 'ClearUserData',
        value: function ClearUserData() {

            _BaseConfig.BaseConfig.UserData.Name = "";
            _BaseConfig.BaseConfig.UserData.UserHandIcon = "";
            _BaseConfig.BaseConfig.UserData.MaxScore = 0;
            _BaseConfig.BaseConfig.UserData.HaveSkinChipNum = 0;
            _BaseConfig.BaseConfig.UserData.HaveSkin = [];

            this.SaveUserDataLocalStorage();
        }

        /**
         * 返回当前实例
         */

    }], [{
        key: 'getInstance',
        value: function getInstance() {
            if (this.m_Instance == null) {
                this.m_Instance = new DataManage();
            }
            return this.m_Instance;
        }
    }]);

    return DataManage;
}();

var AudioManage = exports.AudioManage = function () {

    /**
     * 初始化
     */
    function AudioManage() {
        _classCallCheck(this, AudioManage);

        Utils.CCLog("DataManage constructor");
        this.m_AudioCilps = new Map();
        this.m_BgMusicID = 0;
        this.m_SoundID = 0;
    }

    /**
     * 初始化音乐
     * @param {Function} _callFun 
     */

    //使用严格模式


    _createClass(AudioManage, [{
        key: 'InitGameAudio',
        value: function InitGameAudio(_callFun) {

            //加载音乐
            var musicarray = [],
                loadresnum = 0;
            for (var key in _BaseConfig.BaseConfig.GameResMusics) {
                //往数组中放值
                musicarray.push(_BaseConfig.BaseConfig.GameResMusics[key]);
            }
            // Utils.CCLog('musicarray', musicarray);

            for (var index = 0; index < musicarray.length; index++) {

                this.LoadResAudioCilp(musicarray[index], function () {
                    loadresnum++;
                    //资源加载完毕
                    if (musicarray.length == loadresnum) {
                        if (_callFun) {
                            _callFun();
                        }
                    }
                });
            }
        }

        /**
         * 网络远程预加载音效
         * @param {string} _musicname 
         * @param {Function} _callFun 
         */

    }, {
        key: 'LoadNetAudioCilp',
        value: function LoadNetAudioCilp(_musicname) {
            var _this6 = this;

            var _callFun = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;

            var audiourl = _BaseConfig.BaseConfig.Global.NetRoot + _BaseConfig.BaseConfig.Global.NetRes + 'music/' + _musicname;
            cc.loader.load(audiourl, function (err, audio) {
                if (err) {
                    console.error(err);
                    return;
                }
                _this6.m_AudioCilps.set(_musicname, audio);
                if (_callFun) {
                    _callFun(audio);
                }
            });
        }

        /**
         * 加载本地音乐
         * @param {string} _musicname
         * @param {Function} _callFun 
         */

    }, {
        key: 'LoadResAudioCilp',
        value: function LoadResAudioCilp(_musicname) {
            var _this7 = this;

            var _callFun = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;

            var audiourl = "data/subpackage/music/" + _musicname;
            cc.loader.loadRes(audiourl, function (err, audio) {
                if (err) {
                    console.error(err);
                    return;
                }

                _this7.m_AudioCilps.set(_musicname, audio);
                if (_callFun) {
                    _callFun(audio);
                }
            });
        }

        /**
         * 播放背景音乐
         * @param {string} _musicname 
         */

    }, {
        key: 'PlayMusic',
        value: function PlayMusic(_musicname) {
            if (!DataManage.getInstance().GetStepMusic()) {
                return;
            }

            var audio = this.m_AudioCilps.get(_musicname);
            if (audio) {
                this.StopMusic();
                this.m_BgMusicID = cc.audioEngine.playMusic(audio, true);
            } else {
                Utils.CCLog('audio resources not load _musicname', _musicname);
            }
        }

        /**
         * 播放音效
         * @param {string} _soundname 
         */

    }, {
        key: 'PlaySound',
        value: function PlaySound(_soundname) {

            if (!DataManage.getInstance().GetStepSound()) {
                return;
            }

            var audio = this.m_AudioCilps.get(_soundname);
            if (audio) {
                this.m_SoundID = cc.audioEngine.playEffect(audio, false);
            } else {
                Utils.CCLog('audio resources not load _soundname', _soundname);
            }
        }

        /**
         * 停止背景音乐
         */

    }, {
        key: 'StopMusic',
        value: function StopMusic() {
            cc.audioEngine.stopMusic();
        }

        /**
         * 暂停背景音乐
         */

    }, {
        key: 'PauseMusic',
        value: function PauseMusic() {
            cc.audioEngine.pauseMusic();
        }

        /**
         * 恢复背景音乐
         */

    }, {
        key: 'ResumeMusic',
        value: function ResumeMusic() {
            cc.audioEngine.resumeMusic();
        }

        /**
         * 停止音效
         */

    }, {
        key: 'StopSound',
        value: function StopSound() {
            cc.audioEngine.stopEffect(this.m_SoundID);
        }

        /**
         * 停止音效
         */

    }, {
        key: 'StopAllSound',
        value: function StopAllSound() {
            cc.audioEngine.stopAllEffects();
        }

        /**
         * 暂停音效
         */

    }, {
        key: 'PauseEffect',
        value: function PauseEffect() {
            cc.audioEngine.pauseEffect(this.m_SoundID);
        }

        /**
         * 暂停音效
         */

    }, {
        key: 'PauseAllEffect',
        value: function PauseAllEffect() {
            cc.audioEngine.pauseAllEffects();
        }

        /**
         * 恢复音效
         */

    }, {
        key: 'ResumeEffect',
        value: function ResumeEffect() {
            cc.audioEngine.resumeEffect(this.m_SoundID);
        }

        /**
         * 恢复音效
         */

    }, {
        key: 'ResumeAllEffect',
        value: function ResumeAllEffect() {
            cc.audioEngine.resumeAllEffects();
        }

        /**
         * 返回当前实例
         */

    }], [{
        key: 'getInstance',
        value: function getInstance() {
            if (this.m_Instance == null) {
                this.m_Instance = new AudioManage();
            }
            return this.m_Instance;
        }
    }]);

    return AudioManage;
}();

/**
 * Npc对象池 管理类
 */


var NodePoolManage = exports.NodePoolManage = function () {

    /**
     * 初始化
     */
    function NodePoolManage() {
        _classCallCheck(this, NodePoolManage);

        Utils.CCLog("NodePoolManage constructor");
        this.m_NodePool = new Map();
    }

    /**
     * 创建对象池
     * @param {string} _key 对象池名字
     * @param {cc.node} _node 要创建的对象
     * @param {number} _count 创建的数量
     */

    //使用严格模式


    _createClass(NodePoolManage, [{
        key: 'CreateNoodePool',
        value: function CreateNoodePool(_key, _node, _count) {
            Utils.CCLog("CreateNpcNoodePool", _count);

            //先判断是否有该对象池
            var objpooldata = this.m_NodePool.get(_key);
            //如果不存在就新建一个对象池
            if (!objpooldata) {
                objpooldata = {
                    nodepool: new cc.NodePool(Npc),
                    node: _node
                };
                this.m_NodePool.set(_key, objpooldata);
            }

            for (var index = 0; index < _count; index++) {
                var objnode = cc.instantiate(objpooldata.node);
                objpooldata.nodepool.put(objnode);
            }
        }

        /**
         * 获取一个node
         * @param {string} _key 对象池名字
         * @param {cc.NODE} _parent
         */

    }, {
        key: 'GetNodeToNoodePool',
        value: function GetNodeToNoodePool(_key, _parent) {
            var objNode = null;
            //先判断是否有该对象池
            var objpooldata = this.m_NodePool.get(_key);
            //如果不存在
            if (!objpooldata) {
                Utils.CCLog(_key + "__nodepool_not_create");
                return objNode;
            }

            // 通过 size 接口判断对象池中是否有空闲的对象
            if (objpooldata.nodepool.size()) {
                objNode = objpooldata.nodepool.get();
            } else {
                //生成一个新的对象
                objNode = cc.instantiate(objpooldata.node);
            }

            objNode.parent = _parent; // 将生成的敌人加入节点树
            return objNode;
        }

        /**
         * 将单独的node归还对象池
         * @param {string} _key 对象池名字
         * @param {cc.Node} _npcNode 
         */

    }, {
        key: 'PutNodeToNoodePool',
        value: function PutNodeToNoodePool(_key, _node) {

            //先判断是否有该对象池
            var objpooldata = this.m_NodePool.get(_key);
            //如果不存在
            if (!objpooldata) {
                Utils.CCLog(_key + "__nodepool_not_create");
                return;
            }
            //将node放回节点
            objpooldata.nodepool.put(_node);
        }

        /**
         * 清除对应的对象池
         * @param {string} _key 对象池名字
         */

    }, {
        key: 'ClearNoodePool',
        value: function ClearNoodePool(_key) {

            //先判断是否有该对象池
            var objpooldata = this.m_NodePool.get(_key);
            //如果不存在
            if (!objpooldata) {
                Utils.CCLog(_key + "__nodepool_not_create");
                return;
            }
            //调用clear清除对象池
            objpooldata.nodepool.clear();
            //将对象在map删除
            this.m_NodePool.delete(_key);
        }

        /**
         * 返回当前实例
         */

    }], [{
        key: 'getInstance',
        value: function getInstance() {
            if (this.m_Instance == null) {
                this.m_Instance = new NodePoolManage();
            }
            return this.m_Instance;
        }
    }]);

    return NodePoolManage;
}();

/**
 * http请求
 */


var Http = exports.Http = function () {

    /**
     * 初始化
     */
    function Http() {
        _classCallCheck(this, Http);

        console.log("Http constructor");
        this.m_data = new Map(); // 请求的参数数据
        this.m_ReqType = "POST"; // 请求类型， 默认为 POST ，可以手动设置成 GET 方式请求
    }

    /**
     * 增加一个提交参数
     * @param {string} _key 
     * @param {string} _value 
     */


    //使用严格模式


    _createClass(Http, [{
        key: 'AddParam',
        value: function AddParam(_key, _value) {
            this.m_data.set(_key, _value);
        }

        /**
         * 发送一个请求
         * @param {string} _url  设置请求响应的URL, 例如： http://xxxx/xxx.php
         * 
         * @param {function} _cbSuccess 请求成功回调函数，函数格式：success(data)
         * @param {function} _cbFail 请求失败回调函数 ,函数格式： fail(_info)
         * 
         */

    }, {
        key: 'SendRequest',
        value: function SendRequest(_url, _cbSuccess, _cbFail) {
            var _this8 = this;

            var _timeOutNum = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : 0;

            // 发送请求数据转换为字符串， 格式：pid=10003&appid=cycckhlb&appChannel=weixin
            var postData = "";
            this.m_data.forEach(function (value, key, mapObj) {
                if (postData != "") {
                    postData += '&&';
                }
                postData += key + '=' + value;
            });

            //微信平台直接调用微信的网络请求接口
            if (cc.sys.platform == cc.sys.WECHAT_GAME) {
                if ("GET" == this.m_ReqType) {
                    wx.request({
                        url: _url,
                        data: postData,
                        header: {
                            'Content-Type': 'application/x-www-form-urlencoded'
                        },
                        method: "GET",
                        success: function success(res) {
                            Utils.CCLog("request success", res);
                            if (_cbSuccess) {
                                _cbSuccess(res.data);
                            }
                        },
                        fail: function fail(err) {
                            Utils.CCLog("request fail", err);
                            if (err.errMsg.search(/timeout/g)) {
                                _timeOutNum--;
                                Utils.CCLog("超时次数", _timeOutNum);
                                if (_timeOutNum <= 0) {
                                    if (_cbFail) {
                                        _cbFail("请求超时次数已达上限");
                                    }
                                } else {
                                    _this8.BaesHttpSendRequest(_url, _cbSuccess, _cbFail, _timeOutNum);
                                }
                            } else {
                                if (_cbFail) {
                                    _cbFail(err);
                                }
                            }
                        },
                        complete: function complete(data) {
                            Utils.CCLog("request complete", data);
                        }
                    });
                } else {
                    wx.request({
                        url: _url, //仅为示例，并非真实的接口地址
                        data: postData,
                        header: {
                            'Content-Type': 'application/x-www-form-urlencoded' // 默认值
                        },
                        method: "POST",
                        success: function success(res) {
                            Utils.CCLog("request success", res);
                            if (_cbSuccess) {
                                _cbSuccess(res.data);
                            }
                        },
                        fail: function fail(err) {
                            Utils.CCLog("request fail", err);
                            if (err.errMsg.search(/timeout/g)) {
                                _timeOutNum--;
                                Utils.CCLog("超时次数", _timeOutNum);
                                if (_timeOutNum <= 0) {
                                    if (_cbFail) {
                                        _cbFail("请求超时次数已达上限");
                                    }
                                } else {
                                    Utils.CCLog("request fail", _this8);
                                    _this8.BaesHttpSendRequest(_url, _cbSuccess, _cbFail, _timeOutNum);
                                }
                            } else {
                                if (_cbFail) {
                                    _cbFail(err);
                                }
                            }
                        },
                        complete: function complete(data) {
                            Utils.CCLog("request complete", data);
                        }
                    });
                }
            } else {
                var xmlHttp = new XMLHttpRequest(); // 网络访问句柄  
                // 设置处理响应的回调函数
                xmlHttp.onreadystatechange = function () {
                    if (xmlHttp.readyState == 4 && xmlHttp.status >= 200 && xmlHttp.status < 400) {
                        if (_cbSuccess) {
                            _cbSuccess(JSON.parse(xmlHttp.responseText)); // 返回请求结果
                            return;
                        }
                    }
                };

                xmlHttp.ontimeout = function () {
                    console.error('BaesHttpSendRequest Timeout!!');
                    _timeOutNum--;
                    if (_timeOutNum <= 0) {
                        if (_cbFail) {
                            _cbFail("请求超时次数已达上限");
                        }
                    } else {
                        Utils.CCLog("request fail", _this8);
                        _this8.BaesHttpSendRequest(_url, _cbSuccess, _cbFail, _timeOutNum);
                    }
                };

                // Utils.CCLog("BaesHttp.SendRequest postData="+postData);
                if ("GET" == this.m_ReqType) {

                    xmlHttp.open("GET", _url + "?" + postData, true);
                    xmlHttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                    xmlHttp.send();
                } else if ("DELETE" == this.m_ReqType) {
                    xmlHttp.open("DELETE", _url, true);
                    xmlHttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                    xmlHttp.send(postData);
                } else {
                    xmlHttp.open("POST", _url, true); // 设置以POST方式发送请求，并打开连接
                    xmlHttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                    // xmlHttp.send("pid=10003&appid=cycckhlb&appChannel=weixin");
                    xmlHttp.send(postData);
                }
            }
        }
    }]);

    return Http;
}();

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=BaseUtils.js.map
        